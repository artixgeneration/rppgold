import { execSync } from 'child_process';

// Sample client data with different investment plans
const sampleClients = [
  {
    // Tier 1 Investment - Lower range
    user: {
      username: "rahul_sharma",
      password: "password123",
      email: "rahul.sharma@example.com",
      fullName: "Rahul Sharma",
      role: "customer",
      branch: "Delhi Central",
      phoneNumber: "9876543210",
      dateOfBirth: "1985-05-15",
      address: "123 Rajouri Garden",
      city: "New Delhi",
      state: "Delhi",
      pincode: "110027",
      aadharNumber: "1234-5678-9101",
      panNumber: "ABCDE1234F",
      nomineeName: "Preeti Sharma",
      nomineeRelationship: "Spouse",
      nomineeContact: "9876543211",
      bankName: "HDFC Bank",
      accountNumber: "12345678901",
      ifscCode: "HDFC0001234",
      isActive: true
    },
    investment: {
      branchId: 2, // Delhi Central
      type: "rpp_gold_tier1",
      amount: 50000,
      dailyReturn: 0.75,
      workingDays: 267,
      daysCompleted: 10,
      startDate: new Date().toISOString().split('T')[0],
      status: "active",
      certificateNumber: "RPGT1-DEL-001",
      transactionDetails: {
        paymentMethod: "Online Transfer",
        transactionId: "HDFC87654321",
        date: new Date().toISOString().split('T')[0]
      }
    }
  },
  {
    // Tier 1 Investment - Higher range
    user: {
      username: "ananya_patel",
      password: "password123",
      email: "ananya.patel@example.com",
      fullName: "Ananya Patel",
      role: "customer",
      branch: "Bangalore Tech",
      phoneNumber: "9876543220",
      dateOfBirth: "1990-07-22",
      address: "456 Indiranagar",
      city: "Bangalore",
      state: "Karnataka",
      pincode: "560038",
      aadharNumber: "2345-6789-1012",
      panNumber: "BCDEF2345G",
      nomineeName: "Rajiv Patel",
      nomineeRelationship: "Father",
      nomineeContact: "9876543221",
      bankName: "ICICI Bank",
      accountNumber: "23456789012",
      ifscCode: "ICIC0002345",
      isActive: true
    },
    investment: {
      branchId: 3, // Bangalore Tech
      type: "rpp_gold_tier1",
      amount: 150000,
      dailyReturn: 0.75,
      workingDays: 267,
      daysCompleted: 5,
      startDate: new Date().toISOString().split('T')[0],
      status: "active",
      certificateNumber: "RPGT1-BLR-001",
      transactionDetails: {
        paymentMethod: "Cash",
        transactionId: "CASH-BLR-12345",
        date: new Date().toISOString().split('T')[0]
      }
    }
  },
  {
    // Tier 2 Investment
    user: {
      username: "vikram_singh",
      password: "password123",
      email: "vikram.singh@example.com",
      fullName: "Vikram Singh",
      role: "customer",
      branch: "Chennai Coast",
      phoneNumber: "9876543230",
      dateOfBirth: "1982-03-10",
      address: "789 Adyar",
      city: "Chennai",
      state: "Tamil Nadu",
      pincode: "600020",
      aadharNumber: "3456-7891-0123",
      panNumber: "CDEFG3456H",
      nomineeName: "Meena Singh",
      nomineeRelationship: "Spouse",
      nomineeContact: "9876543231",
      bankName: "SBI",
      accountNumber: "34567890123",
      ifscCode: "SBIN0003456",
      isActive: true
    },
    investment: {
      branchId: 4, // Chennai Coast
      type: "rpp_gold_tier2",
      amount: 400000,
      dailyReturn: 1.0,
      workingDays: 200,
      daysCompleted: 15,
      startDate: new Date().toISOString().split('T')[0],
      status: "active",
      certificateNumber: "RPGT2-CHN-001",
      referredById: 1, // Admin as referrer
      transactionDetails: {
        paymentMethod: "Online Transfer",
        transactionId: "SBI98765432",
        date: new Date().toISOString().split('T')[0]
      }
    }
  },
  {
    // Another Tier 2 Investment - With referral
    user: {
      username: "priyanka_reddy",
      password: "password123",
      email: "priyanka.reddy@example.com",
      fullName: "Priyanka Reddy",
      role: "customer",
      branch: "Kolkata Central",
      phoneNumber: "9876543240",
      dateOfBirth: "1988-11-15",
      address: "567 Salt Lake",
      city: "Kolkata",
      state: "West Bengal",
      pincode: "700106",
      aadharNumber: "4567-8910-1234",
      panNumber: "DEFGH4567I",
      nomineeName: "Suresh Reddy",
      nomineeRelationship: "Brother",
      nomineeContact: "9876543241",
      bankName: "Axis Bank",
      accountNumber: "45678901234",
      ifscCode: "UTIB0004567",
      isActive: true
    },
    investment: {
      branchId: 5, // Kolkata Central
      type: "rpp_gold_tier2",
      amount: 300000,
      dailyReturn: 1.0,
      workingDays: 200,
      daysCompleted: 20,
      startDate: new Date().toISOString().split('T')[0],
      status: "active",
      certificateNumber: "RPGT2-KOL-001",
      referredById: 3, // Referred by Rahul (will be created first)
      transactionDetails: {
        paymentMethod: "Online Transfer",
        transactionId: "AXIS12345678",
        date: new Date().toISOString().split('T')[0]
      }
    }
  },
  {
    // Tier 3 Investment - High value
    user: {
      username: "arjun_mehta",
      password: "password123",
      email: "arjun.mehta@example.com",
      fullName: "Arjun Mehta",
      role: "customer",
      branch: "Visakhapatnam HQ",
      phoneNumber: "9876543250",
      dateOfBirth: "1975-08-20",
      address: "890 Harbour Road",
      city: "Visakhapatnam",
      state: "Andhra Pradesh",
      pincode: "530001",
      aadharNumber: "5678-9101-2345",
      panNumber: "EFGHI5678J",
      nomineeName: "Kiran Mehta",
      nomineeRelationship: "Son",
      nomineeContact: "9876543251",
      bankName: "HDFC Bank",
      accountNumber: "56789012345",
      ifscCode: "HDFC0005678",
      isActive: true
    },
    investment: {
      branchId: 1, // Visakhapatnam HQ
      type: "rpp_gold_tier3",
      amount: 750000,
      dailyReturn: 1.5,
      workingDays: 132,
      daysCompleted: 25,
      startDate: new Date().toISOString().split('T')[0],
      status: "active",
      certificateNumber: "RPGT3-VSK-001",
      referredById: 5, // Referred by Vikram Singh
      transactionDetails: {
        paymentMethod: "Online Transfer",
        transactionId: "HDFC12345678",
        date: new Date().toISOString().split('T')[0]
      }
    }
  }
];

// Main execution
console.log('Creating sample clients with their investment plans...');

try {
  // First, authenticate to get a session
  const loginResult = execSync(`
    curl -c cookies.txt -s -X POST http://localhost:5000/api/login \
    -H "Content-Type: application/json" \
    -d '{"username":"admin","password":"admin123"}' | cat
  `).toString();
  
  console.log('Admin authentication successful');
  
  sampleClients.forEach((client, index) => {
    try {
      console.log(`Creating client ${index + 1}: ${client.user.fullName}`);
      
      const createUserCommand = `
        curl -b cookies.txt -s -X POST http://localhost:5000/api/admin-register \
        -H "Content-Type: application/json" \
        -d '${JSON.stringify({ user: client.user, investment: client.investment })}'
      `;
      
      const result = execSync(createUserCommand).toString();
      console.log(`Created client ${client.user.fullName} with investment plan ${client.investment.type}`);
    } catch (error) {
      console.error(`Error creating client ${client.user.fullName}:`, error.message);
    }
  });
  
  console.log('Sample clients generation complete!');
} catch (error) {
  console.error('Error:', error.message);
}