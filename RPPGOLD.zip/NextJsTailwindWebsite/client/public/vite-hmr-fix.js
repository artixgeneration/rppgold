// Fix the WebSocket connection issue in Vite HMR
(function() {
  // Wait for the Vite client to be available
  const checkInterval = setInterval(() => {
    if (window.__vite_plugin_react_preamble_installed__) {
      clearInterval(checkInterval);
      
      // Override WebSocket creation in Vite
      const originalWebSocket = window.WebSocket;
      window.WebSocket = function(url, protocols) {
        if (url && url.startsWith('wss://localhost:undefined')) {
          // Get the correct protocol and host
          const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
          const host = window.location.host;
          // Replace the invalid URL with the correct one
          url = `${protocol}//${host}`;
          console.log('[HMR Fix] Corrected WebSocket URL:', url);
        }
        return new originalWebSocket(url, protocols);
      };
      
      console.log('[HMR Fix] WebSocket connection patched');
    }
  }, 100);
  
  // Timeout after 10 seconds
  setTimeout(() => clearInterval(checkInterval), 10000);
})();