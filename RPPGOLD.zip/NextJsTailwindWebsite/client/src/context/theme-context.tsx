import { createContext, useState, useEffect, useContext, ReactNode } from "react";

type Theme = "light" | "dark" | "system";

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<Theme>("system");
  const [isClient, setIsClient] = useState(false);

  // This effect runs only once on mount to set isClient to true
  useEffect(() => {
    setIsClient(true);
  }, []);

  // This effect runs once the component has mounted to initialize theme from localStorage
  useEffect(() => {
    if (isClient) {
      try {
        const savedTheme = localStorage.getItem("theme") as Theme;
        if (savedTheme) {
          setTheme(savedTheme);
        }
      } catch (e) {
        console.error("Error accessing localStorage:", e);
      }
    }
  }, [isClient]);

  // This effect applies the theme to the document
  useEffect(() => {
    if (!isClient) return;
    
    try {
      const root = window.document.documentElement;
      
      if (theme === "system") {
        const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches
          ? "dark"
          : "light";
        
        root.classList.remove("light", "dark");
        root.classList.add(systemTheme);
      } else {
        root.classList.remove("light", "dark");
        root.classList.add(theme);
      }
      
      localStorage.setItem("theme", theme);
    } catch (e) {
      console.error("Error applying theme:", e);
    }
  }, [theme, isClient]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
}
