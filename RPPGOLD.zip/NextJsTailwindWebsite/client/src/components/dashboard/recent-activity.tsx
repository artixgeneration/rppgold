import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Calendar, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

export interface Activity {
  id: number;
  user: {
    name: string;
    imageUrl: string;
    initials?: string;
  };
  description: string;
  date: string;
  time: string;
  badgeText: string;
  badgeColor: "green" | "blue" | "yellow" | "red";
}

interface RecentActivityProps {
  activities: Activity[];
}

export default function RecentActivity({ activities }: RecentActivityProps) {
  const getBadgeColor = (color: Activity["badgeColor"]) => {
    switch (color) {
      case "green":
        return "bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100";
      case "blue":
        return "bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100";
      case "yellow":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100";
      case "red":
        return "bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-100";
    }
  };

  return (
    <div>
      <h2 className="text-lg font-medium text-gray-900 dark:text-white">Recent Activity</h2>
      <Card className="mt-3 bg-white dark:bg-gray-800 shadow overflow-hidden">
        <ul role="list" className="divide-y divide-gray-200 dark:divide-gray-700">
          {activities.length === 0 ? (
            <li className="px-4 py-5 sm:px-6">
              <div className="text-center text-gray-500 dark:text-gray-400">
                No recent activities
              </div>
            </li>
          ) : (
            activities.map((activity) => (
              <li key={activity.id}>
                <div className="block hover:bg-gray-50 dark:hover:bg-gray-700">
                  <div className="px-4 py-4 sm:px-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="flex-shrink-0">
                          <Avatar>
                            <AvatarImage src={activity.user.imageUrl} alt={activity.user.name} />
                            <AvatarFallback>{activity.user.initials || activity.user.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-primary-600 dark:text-primary-400">
                            {activity.user.name}
                          </div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            {activity.description}
                          </div>
                        </div>
                      </div>
                      <div className="ml-2 flex-shrink-0 flex">
                        <span
                          className={cn(
                            "px-2 inline-flex text-xs leading-5 font-semibold rounded-full",
                            getBadgeColor(activity.badgeColor)
                          )}
                        >
                          {activity.badgeText}
                        </span>
                      </div>
                    </div>
                    <div className="mt-2 sm:flex sm:justify-between">
                      <div className="sm:flex">
                        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                          <Calendar className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400 dark:text-gray-500" />
                          <p>{activity.date}</p>
                        </div>
                      </div>
                      <div className="mt-2 flex items-center text-sm text-gray-500 dark:text-gray-400 sm:mt-0">
                        <Clock className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400 dark:text-gray-500" />
                        <p>{activity.time}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
            ))
          )}
        </ul>
      </Card>
    </div>
  );
}
