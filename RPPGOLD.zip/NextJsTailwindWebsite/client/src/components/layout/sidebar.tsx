import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { 
  Home, 
  Users, 
  BarChart, 
  MessageSquare, 
  Settings, 
  Sliders, 
  GitBranch,
  Bell,
  Cog
} from "lucide-react";
import RoleBasedMenu from "./role-based-menu";

interface SidebarProps {
  sidebarOpen: boolean;
  currentPath: string;
}

export default function Sidebar({ sidebarOpen, currentPath }: SidebarProps) {
  const { user } = useAuth();

  const isActive = (path: string) => {
    return currentPath === path;
  };

  const menuItems = [
    {
      name: "Dashboard",
      href: "/",
      icon: Home,
      active: isActive("/"),
    },
    {
      name: "Users",
      href: "/users",
      icon: Users,
      active: isActive("/users"),
    },
    {
      name: "Investments",
      href: "/investments",
      icon: BarChart,
      active: isActive("/investments"),
    },
    {
      name: "Branches",
      href: "/branches",
      icon: GitBranch,
      active: isActive("/branches"),
    },
    {
      name: "Chat",
      href: "/chat",
      icon: MessageSquare,
      active: isActive("/chat"),
    },
    {
      name: "Notifications",
      href: "/notifications",
      icon: Bell,
      active: isActive("/notifications"),
    },
    {
      name: "Configuration",
      href: "/configuration",
      icon: Cog,
      active: isActive("/configuration"),
    },
    {
      name: "Settings",
      href: "/settings",
      icon: Settings,
      active: isActive("/settings"),
    },
  ];

  return (
    <div
      className={cn(
        "hidden lg:flex lg:flex-shrink-0 transition-all duration-300",
        sidebarOpen ? "lg:w-64" : "lg:w-0"
      )}
    >
      <div className="flex flex-col w-64">
        <div className="flex flex-col flex-grow pt-5 pb-4 overflow-y-auto bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700">
          <div className="flex items-center flex-shrink-0 px-4">
            <h1 className="text-xl font-bold text-primary-600 dark:text-primary-400">RPP GOLD</h1>
          </div>
          <div className="mt-5 flex-grow flex flex-col">
            <nav className="flex-1 px-2 space-y-1">
              {menuItems.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className={cn(
                    "group flex items-center px-2 py-2 text-sm font-medium rounded-md",
                    item.active
                      ? "bg-primary-100 text-primary-700 dark:bg-gray-700 dark:text-white"
                      : "text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
                  )}
                >
                  <item.icon
                    className={cn(
                      "mr-3 flex-shrink-0 h-5 w-5",
                      item.active
                        ? "text-primary-600 dark:text-white"
                        : "text-gray-500 dark:text-gray-400"
                    )}
                  />
                  {item.name}
                </Link>
              ))}
              
              {/* Role-specific menu items */}
              <RoleBasedMenu currentPath={currentPath} />
            </nav>
          </div>
        </div>
      </div>
    </div>
  );
}
