import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { Sliders, GitBranch } from "lucide-react";

interface RoleBasedMenuProps {
  currentPath: string;
  onClick?: () => void;
}

export default function RoleBasedMenu({ currentPath, onClick }: RoleBasedMenuProps) {
  const { isAdmin, isModerator, isDeveloper } = useAuth();
  
  const isActive = (path: string) => {
    return currentPath === path;
  };
  
  if (!isAdmin && !isModerator && !isDeveloper) {
    return null;
  }
  
  return (
    <div className="pt-2 mt-2 border-t border-gray-200 dark:border-gray-700">
      <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
        {isAdmin ? "Admin Controls" : isModerator ? "Moderator Controls" : "Developer Controls"}
      </h3>
      <div className="mt-1 space-y-1">
        {(isAdmin || isModerator) && (
          <Link
            href="/configuration"
            className={cn(
              "group flex items-center px-2 py-2 text-sm font-medium rounded-md",
              isActive("/configuration")
                ? "bg-primary-100 text-primary-700 dark:bg-gray-700 dark:text-white"
                : "text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
            )}
            onClick={onClick}
          >
            <Sliders
              className={cn(
                "mr-3 flex-shrink-0 h-5 w-5",
                isActive("/configuration")
                  ? "text-primary-600 dark:text-white"
                  : "text-gray-500 dark:text-gray-400"
              )}
            />
            Configuration
          </Link>
        )}
        
        {isAdmin && (
          <Link
            href="/branches"
            className={cn(
              "group flex items-center px-2 py-2 text-sm font-medium rounded-md",
              isActive("/branches")
                ? "bg-primary-100 text-primary-700 dark:bg-gray-700 dark:text-white"
                : "text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
            )}
            onClick={onClick}
          >
            <GitBranch
              className={cn(
                "mr-3 flex-shrink-0 h-5 w-5",
                isActive("/branches")
                  ? "text-primary-600 dark:text-white"
                  : "text-gray-500 dark:text-gray-400"
              )}
            />
            Branches
          </Link>
        )}
      </div>
    </div>
  );
}
