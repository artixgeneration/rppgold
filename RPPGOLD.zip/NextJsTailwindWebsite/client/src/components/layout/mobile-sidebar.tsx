import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { 
  Home, 
  Users, 
  BarChart, 
  MessageSquare, 
  Settings, 
  X,
  User
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import RoleBasedMenu from "./role-based-menu";

interface MobileSidebarProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  currentPath: string;
}

export default function MobileSidebar({ 
  sidebarOpen, 
  setSidebarOpen,
  currentPath
}: MobileSidebarProps) {
  const { user } = useAuth();

  const isActive = (path: string) => {
    return currentPath === path;
  };

  const menuItems = [
    {
      name: "Dashboard",
      href: "/",
      icon: Home,
      active: isActive("/"),
    },
    {
      name: "Users",
      href: "/users",
      icon: Users,
      active: isActive("/users"),
    },
    {
      name: "Investments",
      href: "/investments",
      icon: BarChart,
      active: isActive("/investments"),
    },
    {
      name: "Chat",
      href: "/chat",
      icon: MessageSquare,
      active: isActive("/chat"),
    },
    {
      name: "Settings",
      href: "/settings",
      icon: Settings,
      active: isActive("/settings"),
    },
  ];

  const getInitials = (name: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  return (
    <>
      {/* Mobile menu backdrop */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 z-40 bg-gray-600 bg-opacity-75 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Mobile menu */}
      <div 
        className={cn(
          "fixed inset-0 flex z-40 lg:hidden transform transition-transform duration-300 ease-in-out",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="relative flex-1 flex flex-col max-w-xs w-full bg-white dark:bg-gray-800">
          <div className="absolute top-0 right-0 -mr-12 pt-2">
            <button 
              onClick={() => setSidebarOpen(false)} 
              className="ml-1 flex items-center justify-center h-10 w-10 rounded-full focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
            >
              <span className="sr-only">Close sidebar</span>
              <X className="h-6 w-6 text-white" />
            </button>
          </div>
          <div className="flex-1 h-0 pt-5 pb-4 overflow-y-auto">
            <div className="flex-shrink-0 flex items-center px-4">
              <h1 className="text-xl font-bold text-primary-600 dark:text-primary-400">RPP GOLD</h1>
            </div>
            <nav className="mt-5 px-2 space-y-1">
              {menuItems.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className={cn(
                    "group flex items-center px-2 py-2 text-base font-medium rounded-md",
                    item.active
                      ? "bg-primary-100 text-primary-700 dark:bg-gray-700 dark:text-white"
                      : "text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
                  )}
                  onClick={() => setSidebarOpen(false)}
                >
                  <item.icon
                    className={cn(
                      "mr-3 flex-shrink-0 h-6 w-6",
                      item.active
                        ? "text-primary-600 dark:text-white"
                        : "text-gray-500 dark:text-gray-400"
                    )}
                  />
                  {item.name}
                </Link>
              ))}
              
              {/* Role-specific menu items */}
              <RoleBasedMenu currentPath={currentPath} onClick={() => setSidebarOpen(false)} />
            </nav>
          </div>
          <div className="flex-shrink-0 flex border-t border-gray-200 dark:border-gray-700 p-4">
            <Link href="/profile" onClick={() => setSidebarOpen(false)} className="flex-shrink-0 group block w-full">
              <div className="flex items-center">
                <div>
                  <Avatar>
                    <AvatarImage 
                      src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
                      alt={user?.fullName || user?.username || "User"}
                    />
                    <AvatarFallback>{getInitials(user?.fullName || user?.username || "")}</AvatarFallback>
                  </Avatar>
                </div>
                <div className="ml-3">
                  <p className="text-base font-medium text-gray-700 dark:text-gray-300">
                    {user?.fullName || user?.username}
                  </p>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                    {user?.role.charAt(0).toUpperCase() + user?.role.slice(1)}
                  </p>
                </div>
              </div>
            </Link>
          </div>
        </div>
        <div className="flex-shrink-0 w-14" aria-hidden="true">
          {/* Dummy element to force sidebar to shrink to fit close icon */}
        </div>
      </div>

      {/* Bottom mobile navigation */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 px-2 py-2 flex justify-around z-30">
        <Link
          href="/"
          className={cn(
            "flex flex-col items-center justify-center w-full py-1 rounded-md",
            isActive("/") ? "text-primary-600 dark:text-primary-400" : "text-gray-500 dark:text-gray-400"
          )}
        >
          <Home className="h-6 w-6" />
          <span className="text-xs mt-1">Home</span>
        </Link>
        <Link
          href="/users"
          className={cn(
            "flex flex-col items-center justify-center w-full py-1 rounded-md",
            isActive("/users") ? "text-primary-600 dark:text-primary-400" : "text-gray-500 dark:text-gray-400"
          )}
        >
          <Users className="h-6 w-6" />
          <span className="text-xs mt-1">Users</span>
        </Link>
        <Link
          href="/chat"
          className={cn(
            "flex flex-col items-center justify-center w-full py-1 rounded-md",
            isActive("/chat") ? "text-primary-600 dark:text-primary-400" : "text-gray-500 dark:text-gray-400"
          )}
        >
          <MessageSquare className="h-6 w-6" />
          <span className="text-xs mt-1">Chat</span>
        </Link>
        <Link
          href="/profile"
          className={cn(
            "flex flex-col items-center justify-center w-full py-1 rounded-md",
            isActive("/profile") ? "text-primary-600 dark:text-primary-400" : "text-gray-500 dark:text-gray-400"
          )}
        >
          <User className="h-6 w-6" />
          <span className="text-xs mt-1">Profile</span>
        </Link>
        <button
          onClick={() => setSidebarOpen(true)}
          className="flex flex-col items-center justify-center w-full py-1 rounded-md text-gray-500 dark:text-gray-400"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-6 w-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 6h16M4 12h16M4 18h16"
            />
          </svg>
          <span className="text-xs mt-1">Menu</span>
        </button>
      </div>
    </>
  );
}
