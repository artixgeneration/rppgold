import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { Send, X } from "lucide-react";
import { ChatMessage, User } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface ChatWindowProps {
  isOpen: boolean;
  onClose: () => void;
  recipient: User | null;
  fullWidth?: boolean;
}

export default function ChatWindow({ isOpen, onClose, recipient, fullWidth = false }: ChatWindowProps) {
  const { user } = useAuth();
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Connect to WebSocket
  useEffect(() => {
    if (!isOpen || !user || !recipient) return;

    let reconnectAttempts = 0;
    const maxReconnectAttempts = 5;
    const reconnectDelay = 3000; // 3 seconds
    let reconnectTimeout: NodeJS.Timeout | null = null;
    
    function handleReconnect() {
      if (reconnectAttempts < maxReconnectAttempts) {
        reconnectAttempts++;
        console.log(`Attempting to reconnect (${reconnectAttempts}/${maxReconnectAttempts})...`);
        
        // Show toast on first reconnection attempt
        if (reconnectAttempts === 1) {
          toast({
            title: "Connection Lost",
            description: "Attempting to reconnect to chat server...",
          });
        }
        
        // Clear any existing timeout
        if (reconnectTimeout) clearTimeout(reconnectTimeout);
        
        // Set a new timeout
        reconnectTimeout = setTimeout(() => {
          if (isOpen && user && recipient) {
            connectWebSocket();
          }
        }, reconnectDelay);
      } else {
        console.error("Max reconnection attempts reached");
        toast({
          title: "Connection Failed",
          description: "Unable to connect to chat server after multiple attempts. Please refresh the page.",
          variant: "destructive",
        });
      }
    }
    
    const connectWebSocket = () => {
      // Use the current window location for the WebSocket connection
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const host = window.location.host;
      const wsUrl = `${protocol}//${host}/ws`;
      console.log("Connecting to WebSocket at:", wsUrl);
      
      // Create WebSocket connection with error handling
      let newSocket: WebSocket;
      try {
        newSocket = new WebSocket(wsUrl);
      } catch (err) {
        console.error("Error creating WebSocket:", err);
        handleReconnect();
        return;
      }

      // Handle successful connection
      newSocket.onopen = () => {
        console.log("WebSocket connected successfully");
        reconnectAttempts = 0; // Reset reconnect attempts on successful connection
        
        // Register user with the server
        if (user) {
          newSocket.send(JSON.stringify({
            type: 'system',
            data: { userId: user.id }
          }));
        }
      };

      newSocket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'chat') {
            const chatMessage = data.data as ChatMessage;
            // Only show messages between the current user and recipient
            if ((chatMessage.senderId === user.id && chatMessage.receiverId === recipient.id) ||
                (chatMessage.receiverId === user.id && chatMessage.senderId === recipient.id)) {
              setMessages((prev) => [...prev, chatMessage]);
            }
          }
        } catch (err) {
          console.error("Error parsing WebSocket message:", err);
        }
      };

      newSocket.onerror = (error) => {
        console.error("WebSocket error:", error);
        handleReconnect();
      };
      
      newSocket.onclose = (event) => {
        console.log("WebSocket closed, code:", event.code, "reason:", event.reason);
        
        // Don't attempt to reconnect if the socket was closed cleanly (code 1000)
        if (event.code !== 1000) {
          handleReconnect();
        }
      };

      setSocket(newSocket);
    };

    // Load previous messages
    const loadMessages = async () => {
      try {
        const res = await apiRequest("GET", `/api/messages?recipient=${recipient.id}`, undefined);
        const data = await res.json();
        setMessages(data);
      } catch (err) {
        console.error("Error loading messages:", err);
        toast({
          title: "Error",
          description: "Failed to load previous messages",
          variant: "destructive",
        });
      }
    };
    
    // Start the connection process
    connectWebSocket();
    loadMessages();

    return () => {
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.close(1000, "Chat closed by user");
      }
      
      if (reconnectTimeout) {
        clearTimeout(reconnectTimeout);
      }
    };
  }, [isOpen, user, recipient, toast]);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = () => {
    if (!message.trim() || !socket || !user || !recipient) return;

    if (socket.readyState === WebSocket.OPEN) {
      const chatMessage: ChatMessage = {
        senderId: user.id,
        receiverId: recipient.id,
        content: message,
        isRead: false,
        createdAt: new Date(),
      };

      socket.send(JSON.stringify({
        type: 'chat',
        data: chatMessage
      }));

      setMessage("");
    } else {
      toast({
        title: "Connection Error",
        description: "Chat connection is not available. Please refresh the page.",
        variant: "destructive",
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  if (!isOpen || !recipient) return null;

  const formatTime = (date: Date | string | undefined) => {
    if (!date) return "";
    const d = new Date(date);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <Card 
      className={cn(
        "flex flex-col bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden",
        fullWidth ? "h-full w-full" : "fixed right-4 bottom-4 w-80 h-96 z-50"
      )}
    >
      <CardHeader className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center">
          <Avatar className="h-8 w-8 mr-2">
            <AvatarImage 
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
              alt={recipient.fullName || recipient.username} 
            />
            <AvatarFallback>
              {(recipient.fullName || recipient.username || "U").charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <h3 className="text-lg font-medium text-gray-900 dark:text-white">
            {recipient.fullName || recipient.username}
          </h3>
        </div>
        {!fullWidth && (
          <Button variant="ghost" size="icon" onClick={onClose} className="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300">
            <span className="sr-only">Close chat</span>
            <X className="h-5 w-5" />
          </Button>
        )}
      </CardHeader>
      
      <CardContent className="flex-1 p-4 overflow-y-auto">
        <div className="space-y-4">
          {/* System message */}
          <div className="flex justify-center">
            <span className="inline-block px-3 py-1 text-xs text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 rounded-full">
              {new Date().toLocaleDateString()}
            </span>
          </div>
          
          {messages.map((msg, index) => (
            <div
              key={index}
              className={cn(
                "flex items-end",
                msg.senderId === user?.id ? "justify-end" : ""
              )}
            >
              {msg.senderId !== user?.id && (
                <div className="flex-shrink-0 mr-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage 
                      src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                      alt={recipient.fullName || recipient.username} 
                    />
                    <AvatarFallback>
                      {(recipient.fullName || recipient.username || "U").charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </div>
              )}
              
              <div
                className={cn(
                  "max-w-xs mx-2 p-3 rounded-lg",
                  msg.senderId === user?.id
                    ? "bg-primary-100 dark:bg-primary-700 text-gray-900 dark:text-white"
                    : "bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white"
                )}
              >
                <p className="text-sm">{msg.content}</p>
              </div>
              
              <span className="text-xs text-gray-500 dark:text-gray-400 leading-none">
                {formatTime(msg.createdAt)}
              </span>
            </div>
          ))}
          
          <div ref={messagesEndRef} />
        </div>
      </CardContent>
      
      <CardFooter className="p-4 border-t border-gray-200 dark:border-gray-700">
        <div className="flex w-full">
          <Input
            type="text"
            className="block w-full bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md py-2 px-3 text-sm placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500"
            placeholder="Type your message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyPress}
          />
          <Button 
            className="ml-3 inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
            onClick={sendMessage}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}