import React, { useState, useEffect } from 'react';
import { Loader2, Check, X, AlertTriangle, FileText } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';

export type DocumentValidationStatus = 'loading' | 'validating' | 'valid' | 'invalid' | 'pending';
export type DocumentType = 'aadhar' | 'pan' | 'other';

interface DocumentPreviewProps {
  file: File | null;
  documentType: DocumentType;
  onValidationComplete?: (isValid: boolean) => void;
}

export function DocumentPreview({ file, documentType, onValidationComplete }: DocumentPreviewProps) {
  const [preview, setPreview] = useState<string | null>(null);
  const [validationStatus, setValidationStatus] = useState<DocumentValidationStatus>('loading');
  const [validationProgress, setValidationProgress] = useState(0);
  const [validationMessages, setValidationMessages] = useState<string[]>([]);

  // Create a preview of the uploaded document
  useEffect(() => {
    if (!file) {
      setPreview(null);
      setValidationStatus('loading');
      return;
    }

    // Reset validation status when file changes
    setValidationStatus('loading');
    setValidationProgress(0);
    setValidationMessages([]);
    
    // Create object URL for preview
    const objectUrl = URL.createObjectURL(file);
    setPreview(objectUrl);
    
    // Start validation process
    validateDocument();

    // Clean up object URL on unmount
    return () => URL.revokeObjectURL(objectUrl);
  }, [file]);

  const validateDocument = async () => {
    if (!file) return;

    setValidationStatus('validating');
    
    // Simulate validation progress
    const interval = setInterval(() => {
      setValidationProgress((prev) => {
        if (prev >= 90) {
          clearInterval(interval);
          return prev;
        }
        return prev + 10;
      });
    }, 300);

    // Simulate document validation
    try {
      // In a real implementation, you would run actual validation on the server
      // or use a client-side image processing library to validate the document
      await new Promise((resolve) => setTimeout(resolve, 2000));
      
      // Perform document-specific validation
      let isValid = true;
      const messages: string[] = [];
      
      // Check file type
      if (!['image/jpeg', 'image/png', 'application/pdf'].includes(file.type)) {
        messages.push('File format not supported. Please upload JPG, PNG, or PDF.');
        isValid = false;
      }
      
      // Check file size
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        messages.push('File size exceeds 5MB limit.');
        isValid = false;
      }
      
      // Document-specific validation
      if (documentType === 'aadhar') {
        // Check filename contains "aadhar" or "aadhaar" (simplified check)
        if (!file.name.toLowerCase().includes('aadhar') && !file.name.toLowerCase().includes('aadhaar')) {
          messages.push('Filename should include "Aadhar" for better organization (not a validation error).');
        }
      } else if (documentType === 'pan') {
        // Check filename contains "pan" (simplified check)
        if (!file.name.toLowerCase().includes('pan')) {
          messages.push('Filename should include "PAN" for better organization (not a validation error).');
        }
      }
      
      // In a real implementation, for images, you would:
      // 1. Check image resolution (should be readable)
      // 2. Check for image clarity (not blurry)
      // 3. For Aadhar: detect Aadhar card visual elements
      // 4. For PAN: detect PAN card visual elements
      
      // Simulate some validation result
      if (isValid) {
        messages.push('Document appears to be valid and readable.');
      }
      
      // Set final validation status
      clearInterval(interval);
      setValidationProgress(100);
      setValidationStatus(isValid ? 'valid' : 'invalid');
      setValidationMessages(messages);
      
      // Call the callback if provided
      if (onValidationComplete) {
        onValidationComplete(isValid);
      }
    } catch (error) {
      clearInterval(interval);
      setValidationStatus('invalid');
      setValidationMessages(['Error validating document. Please try again.']);
      console.error('Document validation error:', error);
      
      if (onValidationComplete) {
        onValidationComplete(false);
      }
    }
  };

  // Render different UI based on file type
  const renderPreview = () => {
    if (!file || !preview) {
      return (
        <div className="flex items-center justify-center h-40 bg-gray-100 rounded-md">
          <Skeleton className="h-full w-full rounded-md" />
        </div>
      );
    }

    if (file.type === 'application/pdf') {
      return (
        <div className="flex flex-col items-center justify-center h-40 bg-gray-100 rounded-md">
          <FileText className="h-16 w-16 text-gray-400" />
          <p className="text-sm text-gray-500 mt-2">{file.name}</p>
        </div>
      );
    }

    // For images
    return (
      <div className="h-60 overflow-hidden rounded-md bg-gray-100 flex items-center justify-center">
        <img 
          src={preview} 
          alt="Document preview" 
          className="object-contain max-h-full max-w-full"
          onError={() => {
            setValidationStatus('invalid');
            setValidationMessages(['Failed to load image preview. The file may be corrupted.']);
          }}
        />
      </div>
    );
  };

  const getStatusBadge = () => {
    switch (validationStatus) {
      case 'loading':
        return <Badge variant="outline" className="bg-gray-100 text-gray-800">Loading</Badge>;
      case 'validating':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800">Validating</Badge>;
      case 'valid':
        return <Badge variant="outline" className="bg-green-100 text-green-800">Valid</Badge>;
      case 'invalid':
        return <Badge variant="outline" className="bg-red-100 text-red-800">Invalid</Badge>;
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800">Pending Review</Badge>;
      default:
        return null;
    }
  };

  return (
    <Card className="overflow-hidden border-0 shadow-md">
      <CardContent className="p-4 space-y-4">
        {renderPreview()}
        
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-medium">
              {documentType === 'aadhar' ? 'Aadhar Card' : 
               documentType === 'pan' ? 'PAN Card' : 'Document'} Validation
            </h4>
            {getStatusBadge()}
          </div>
          
          {validationStatus === 'validating' && (
            <div className="space-y-1">
              <Progress value={validationProgress} className="h-2" />
              <p className="text-xs text-muted-foreground flex items-center">
                <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                Validating document...
              </p>
            </div>
          )}
          
          {validationMessages.length > 0 && (
            <div className="mt-2 space-y-1">
              {validationMessages.map((message, index) => (
                <p key={index} className="text-xs flex items-start">
                  {validationStatus === 'valid' ? (
                    <Check className="h-3 w-3 text-green-500 mr-1 flex-shrink-0 mt-0.5" />
                  ) : validationStatus === 'invalid' ? (
                    <X className="h-3 w-3 text-red-500 mr-1 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="h-3 w-3 text-yellow-500 mr-1 flex-shrink-0 mt-0.5" />
                  )}
                  <span className={`${
                    validationStatus === 'valid' ? 'text-green-700' : 
                    validationStatus === 'invalid' ? 'text-red-700' : 'text-yellow-700'
                  }`}>
                    {message}
                  </span>
                </p>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}