import React, { useState } from 'react';
import { Upload, X, FileText, AlertTriangle, Info } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { DocumentPreview, DocumentType } from './document-preview';

interface DocumentUploadProps {
  documentType: DocumentType;
  title: string;
  description?: string;
  onUpload: (file: File) => void;
  isUploading?: boolean;
  accept?: string;
  maxSize?: number; // in MB
  existingDocumentUrl?: string | null;
  isVerified?: boolean;
}

export function DocumentUpload({
  documentType,
  title,
  description,
  onUpload,
  isUploading = false,
  accept = '.jpg,.jpeg,.png,.pdf',
  maxSize = 5,
  existingDocumentUrl,
  isVerified
}: DocumentUploadProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isValid, setIsValid] = useState<boolean | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (files: FileList | null) => {
    if (!files || files.length === 0) {
      setSelectedFile(null);
      setIsValid(null);
      return;
    }

    const file = files[0];
    
    // Basic validation
    if (!file.type.match(/(image\/jpeg|image\/png|application\/pdf)/)) {
      setError('Invalid file type. Please upload JPG, PNG, or PDF.');
      return;
    }
    
    if (file.size > maxSize * 1024 * 1024) {
      setError(`File size exceeds ${maxSize}MB limit.`);
      return;
    }
    
    setError(null);
    setSelectedFile(file);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileChange(e.dataTransfer.files);
  };

  const handleValidationComplete = (isValid: boolean) => {
    setIsValid(isValid);
  };

  const handleUpload = () => {
    if (selectedFile && isValid) {
      onUpload(selectedFile);
    }
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
    setIsValid(null);
    setError(null);
  };

  // Render existing document preview if available
  const renderExistingDocument = () => {
    if (!existingDocumentUrl) return null;

    const isPdf = existingDocumentUrl.toLowerCase().endsWith('.pdf');

    return (
      <div className="mt-2 bg-gray-50 rounded-md p-3 border">
        <h4 className="text-sm font-medium mb-2 flex items-center">
          <FileText className="h-4 w-4 mr-1" />
          Existing Document {isVerified && <span className="ml-1 text-green-600">(Verified)</span>}
        </h4>
        
        {isPdf ? (
          <div className="flex items-center space-x-2">
            <div className="bg-gray-100 p-2 rounded flex items-center justify-center">
              <FileText className="h-8 w-8 text-gray-400" />
            </div>
            <div className="text-sm">
              <p className="font-medium">PDF Document</p>
              <a 
                href={existingDocumentUrl} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-blue-600 hover:underline text-xs"
              >
                View Document
              </a>
            </div>
          </div>
        ) : (
          <div className="aspect-video max-h-48 overflow-hidden rounded bg-gray-100 flex items-center justify-center">
            <img src={existingDocumentUrl} alt="Existing document" className="object-contain max-h-full" />
          </div>
        )}
        
        {isVerified && (
          <Alert className="mt-2 bg-green-50 border-green-200 text-green-800">
            <AlertDescription className="text-xs">
              This document has been verified by an administrator.
            </AlertDescription>
          </Alert>
        )}
      </div>
    );
  };
  
  return (
    <div className="space-y-4">
      {renderExistingDocument()}
    
      <div 
        className={`border-2 border-dashed rounded-lg p-4 transition-colors ${
          isDragging ? 'border-primary bg-primary/5' : 'border-gray-200 hover:border-gray-300'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {!selectedFile ? (
          <div className="flex flex-col items-center justify-center py-4">
            <Upload className="h-10 w-10 text-gray-400 mb-2" />
            <h3 className="text-lg font-semibold">{title}</h3>
            {description && <p className="text-sm text-gray-500 text-center">{description}</p>}
            
            <div className="mt-4 w-full max-w-xs">
              <Label htmlFor={`${documentType}-upload`} className="sr-only">
                Choose a file
              </Label>
              <Input
                id={`${documentType}-upload`}
                type="file"
                accept={accept}
                onChange={(e) => handleFileChange(e.target.files)}
                className="cursor-pointer"
              />
              <p className="text-xs text-gray-500 mt-2">
                JPG, PNG or PDF (max. {maxSize}MB)
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex justify-between items-start">
              <h3 className="text-lg font-semibold">{title}</h3>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0" 
                onClick={handleRemoveFile}
              >
                <X className="h-4 w-4" />
                <span className="sr-only">Remove file</span>
              </Button>
            </div>
            
            <DocumentPreview 
              file={selectedFile} 
              documentType={documentType}
              onValidationComplete={handleValidationComplete}
            />
            
            <div className="flex justify-end space-x-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleRemoveFile}
              >
                Cancel
              </Button>
              <Button 
                variant="default" 
                size="sm" 
                onClick={handleUpload}
                disabled={isUploading || isValid === false || isValid === null}
              >
                {isUploading ? 'Uploading...' : 'Upload'}
              </Button>
            </div>
          </div>
        )}
      </div>
      
      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            {error}
          </AlertDescription>
        </Alert>
      )}
      
      <div className="text-xs text-gray-500 flex items-start mt-2">
        <Info className="h-3 w-3 mr-1 mt-0.5 flex-shrink-0" />
        <span>
          Please ensure the document is clearly visible and all text is readable. 
          For Aadhar cards, make sure the Aadhar number and personal details are 
          visible. For PAN cards, ensure the PAN number and name are clearly visible.
        </span>
      </div>
    </div>
  );
}