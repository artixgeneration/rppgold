import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/dashboard-layout";
import { useAuth } from "@/hooks/use-auth";
import ChatWindow from "@/components/chat/chat-window";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { User } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";

export default function ChatPage() {
  const { user } = useAuth();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  
  const { data: users, isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
    queryFn: getQueryFn({ on401: "throw" }),
  });
  
  // Filter users based on role (admin chats with customers, customers chat with admins)
  const isAdmin = user?.role === "admin" || user?.role === "moderator";
  const filteredUsers = users?.filter(u => 
    isAdmin 
      ? u.role === "customer" 
      : (u.role === "admin" || u.role === "moderator")
  );

  useEffect(() => {
    // Set the first available user as selected by default
    if (filteredUsers && filteredUsers.length > 0 && !selectedUser) {
      setSelectedUser(filteredUsers[0]);
    }
  }, [filteredUsers, selectedUser]);

  const getInitials = (name: string | undefined | null) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  return (
    <DashboardLayout title="Chat">
      <div className="mt-4 h-[calc(100vh-12rem)]">
        <Tabs defaultValue="chat" className="h-full flex flex-col">
          <TabsList className="mx-auto mb-4">
            <TabsTrigger value="chat">Chat</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>
          
          <TabsContent value="chat" className="flex-grow">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 h-full">
              {/* Users list */}
              <Card className="md:col-span-1 border border-gray-200 dark:border-gray-700">
                <CardHeader className="px-4 py-3">
                  <CardTitle className="text-lg">Contacts</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="h-[calc(100vh-16rem)]">
                    <div className="px-2">
                      {isLoading ? (
                        Array(5).fill(0).map((_, i) => (
                          <div key={i} className="flex items-center gap-3 p-3 rounded-md mb-1">
                            <Skeleton className="h-10 w-10 rounded-full" />
                            <div className="space-y-1">
                              <Skeleton className="h-4 w-24" />
                              <Skeleton className="h-3 w-16" />
                            </div>
                          </div>
                        ))
                      ) : filteredUsers && filteredUsers.length > 0 ? (
                        filteredUsers.map((chatUser) => (
                          <div
                            key={chatUser.id}
                            className={`
                              flex items-center gap-3 p-3 rounded-md cursor-pointer
                              ${selectedUser?.id === chatUser.id
                                ? "bg-primary-100 dark:bg-gray-700"
                                : "hover:bg-gray-100 dark:hover:bg-gray-800"}
                            `}
                            onClick={() => setSelectedUser(chatUser)}
                          >
                            <Avatar>
                              <AvatarImage 
                                src={`https://i.pravatar.cc/150?u=${chatUser.id}`} 
                                alt={chatUser.fullName || chatUser.username} 
                              />
                              <AvatarFallback>
                                {getInitials(chatUser.fullName || chatUser.username)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">
                                {chatUser.fullName || chatUser.username}
                              </div>
                              <Badge variant="outline" className="mt-1 text-xs">
                                {chatUser.role}
                              </Badge>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="p-4 text-center text-gray-500 dark:text-gray-400">
                          No contacts available
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Chat window */}
              <div className="md:col-span-3 h-full">
                {selectedUser ? (
                  <ChatWindow 
                    isOpen={true} 
                    onClose={() => setSelectedUser(null)} 
                    recipient={selectedUser} 
                    fullWidth={true} 
                  />
                ) : (
                  <Card className="h-full flex items-center justify-center border border-gray-200 dark:border-gray-700">
                    <CardContent className="text-center text-gray-500 dark:text-gray-400">
                      <div className="mb-2">
                        👈 Select a contact to start chatting
                      </div>
                      <p className="text-sm">
                        Send and receive messages in real-time
                      </p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="history" className="flex-grow">
            <Card className="h-full border border-gray-200 dark:border-gray-700">
              <CardHeader>
                <CardTitle>Message History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center text-gray-500 dark:text-gray-400">
                  Message history will be shown here
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
