import { useState, useRef } from "react";
import DashboardLayout from "@/components/layout/dashboard-layout";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Badge } from "@/components/ui/badge";
import { FileText, Pencil, Upload, Check, X, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function ProfilePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [kycType, setKycType] = useState<'aadhar' | 'pan' | null>(null);
  const [kycNumber, setKycNumber] = useState('');
  const [showDocumentDialog, setShowDocumentDialog] = useState(false);
  const [documentUrl, setDocumentUrl] = useState<string | null>(null);
  const [uploadSuccess, setUploadSuccess] = useState<boolean | null>(null);
  const [viewingDocument, setViewingDocument] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();

  // KYC document upload mutation
  const uploadKycMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await apiRequest('POST', `/api/users/kyc/${kycType}`, formData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      setUploadSuccess(true);
      toast({
        title: 'Document uploaded successfully',
        description: `Your ${kycType === 'aadhar' ? 'Aadhar Card' : 'PAN Card'} has been uploaded for verification.`,
      });
    },
    onError: (error: Error) => {
      setUploadSuccess(false);
      toast({
        title: 'Upload failed',
        description: error.message,
        variant: 'destructive',
      });
    }
  });

  if (!user) {
    return (
      <DashboardLayout title="Your Profile">
        <div className="mt-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Skeleton className="h-16 w-16 rounded-full" />
                <div className="ml-5">
                  <Skeleton className="h-6 w-36" />
                  <Skeleton className="h-4 w-20 mt-1" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  const getInitials = (name: string | undefined | null) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  const handleEditProfile = () => {
    setIsEditing(true);
    toast({
      title: "Edit mode",
      description: "Profile editing is not implemented in this demo",
    });
  };

  const startKycUpload = (type: 'aadhar' | 'pan') => {
    setKycType(type);
    setShowDocumentDialog(true);
    setUploadSuccess(null);
    setKycNumber('');
  };

  const handleDocumentUpload = () => {
    if (!fileInputRef.current?.files?.length) {
      toast({
        title: 'No file selected',
        description: 'Please select a file to upload',
        variant: 'destructive',
      });
      return;
    }

    if (!kycNumber.trim()) {
      toast({
        title: 'Number required',
        description: `Please enter your ${kycType === 'aadhar' ? 'Aadhar' : 'PAN'} number`,
        variant: 'destructive',
      });
      return;
    }

    const formData = new FormData();
    formData.append('document', fileInputRef.current.files[0]);
    formData.append('number', kycNumber);
    
    uploadKycMutation.mutate(formData);
  };

  const closeDialog = () => {
    setShowDocumentDialog(false);
    setKycType(null);
    setUploadSuccess(null);
    setTimeout(() => {
      setDocumentUrl(null);
    }, 300);
  };

  const viewDocument = (docType: 'aadhar' | 'pan') => {
    const userId = user.id;
    setViewingDocument(`/uploads/${docType}/${userId}.jpg`);
  };

  return (
    <DashboardLayout title="Your Profile">
      <div className="mt-6">
        <Card>
          <CardHeader className="px-4 py-5 sm:px-6">
            <div className="flex items-center">
              <Avatar className="h-16 w-16">
                <AvatarImage
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
                  alt={user.fullName || user.username}
                />
                <AvatarFallback>
                  {getInitials(user.fullName || user.username)}
                </AvatarFallback>
              </Avatar>
              <div className="ml-5">
                <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-white">
                  {user.fullName || user.username}
                </h3>
                <p className="mt-1 max-w-2xl text-sm text-gray-500 dark:text-gray-400">
                  <Badge variant="outline" className="bg-primary-100 text-primary-800 dark:bg-primary-800 dark:text-primary-100">
                    {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                  </Badge>
                </p>
              </div>
              <div className="ml-auto">
                <Button variant="outline" size="sm" onClick={handleEditProfile}>
                  <Pencil className="mr-2 h-4 w-4" />
                  Edit
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="border-t border-gray-200 dark:border-gray-700">
            <dl className="sm:divide-y sm:divide-gray-200 sm:dark:divide-gray-700">
              <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5">
                <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Full name
                </dt>
                <dd className="mt-1 text-sm text-gray-900 dark:text-white sm:mt-0 sm:col-span-2">
                  {user.fullName || "Not provided"}
                </dd>
              </div>
              <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5">
                <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Username
                </dt>
                <dd className="mt-1 text-sm text-gray-900 dark:text-white sm:mt-0 sm:col-span-2">
                  {user.username}
                </dd>
              </div>
              <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5">
                <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Email address
                </dt>
                <dd className="mt-1 text-sm text-gray-900 dark:text-white sm:mt-0 sm:col-span-2">
                  {user.email || "Not provided"}
                </dd>
              </div>
              <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5">
                <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Phone number
                </dt>
                <dd className="mt-1 text-sm text-gray-900 dark:text-white sm:mt-0 sm:col-span-2">
                  {user.phoneNumber || "Not provided"}
                </dd>
              </div>
              <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5">
                <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Branch
                </dt>
                <dd className="mt-1 text-sm text-gray-900 dark:text-white sm:mt-0 sm:col-span-2">
                  {user.branch || "Not assigned"}
                </dd>
              </div>
              <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5">
                <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  ID Documents
                </dt>
                <dd className="mt-1 text-sm text-gray-900 dark:text-white sm:mt-0 sm:col-span-2">
                  <ul className="border border-gray-200 dark:border-gray-600 rounded-md divide-y divide-gray-200 dark:divide-gray-600">
                    {user.aadharNumber ? (
                      <li className="pl-3 pr-4 py-3 flex items-center justify-between text-sm">
                        <div className="w-0 flex-1 flex items-center">
                          <FileText className="flex-shrink-0 h-5 w-5 text-gray-400 dark:text-gray-500" />
                          <span className="ml-2 flex-1 w-0 truncate">
                            Aadhar Card: {user.aadharNumber}
                            {user.aadharVerified ? (
                              <Badge variant="outline" className="ml-2 bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100">
                                <Check className="mr-1 h-3 w-3" /> Verified
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="ml-2 bg-amber-100 text-amber-800 dark:bg-amber-800 dark:text-amber-100">
                                Pending Verification
                              </Badge>
                            )}
                          </span>
                        </div>
                        <div className="ml-4 flex-shrink-0 flex space-x-2">
                          <Button variant="link" size="sm" onClick={() => viewDocument('aadhar')}>
                            View
                          </Button>
                        </div>
                      </li>
                    ) : (
                      <li className="pl-3 pr-4 py-3 flex items-center justify-between text-sm">
                        <div className="w-0 flex-1 flex items-center">
                          <FileText className="flex-shrink-0 h-5 w-5 text-gray-400 dark:text-gray-500" />
                          <span className="ml-2 flex-1 w-0 truncate text-gray-500 dark:text-gray-400">
                            Aadhar Card: Not provided
                          </span>
                        </div>
                        <div className="ml-4 flex-shrink-0">
                          <Button variant="outline" size="sm" onClick={() => startKycUpload('aadhar')}>
                            <Upload className="mr-2 h-4 w-4" />
                            Upload
                          </Button>
                        </div>
                      </li>
                    )}
                    {user.panNumber ? (
                      <li className="pl-3 pr-4 py-3 flex items-center justify-between text-sm">
                        <div className="w-0 flex-1 flex items-center">
                          <FileText className="flex-shrink-0 h-5 w-5 text-gray-400 dark:text-gray-500" />
                          <span className="ml-2 flex-1 w-0 truncate">
                            PAN Card: {user.panNumber}
                            {user.panVerified ? (
                              <Badge variant="outline" className="ml-2 bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100">
                                <Check className="mr-1 h-3 w-3" /> Verified
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="ml-2 bg-amber-100 text-amber-800 dark:bg-amber-800 dark:text-amber-100">
                                Pending Verification
                              </Badge>
                            )}
                          </span>
                        </div>
                        <div className="ml-4 flex-shrink-0 flex space-x-2">
                          <Button variant="link" size="sm" onClick={() => viewDocument('pan')}>
                            View
                          </Button>
                        </div>
                      </li>
                    ) : (
                      <li className="pl-3 pr-4 py-3 flex items-center justify-between text-sm">
                        <div className="w-0 flex-1 flex items-center">
                          <FileText className="flex-shrink-0 h-5 w-5 text-gray-400 dark:text-gray-500" />
                          <span className="ml-2 flex-1 w-0 truncate text-gray-500 dark:text-gray-400">
                            PAN Card: Not provided
                          </span>
                        </div>
                        <div className="ml-4 flex-shrink-0">
                          <Button variant="outline" size="sm" onClick={() => startKycUpload('pan')}>
                            <Upload className="mr-2 h-4 w-4" />
                            Upload
                          </Button>
                        </div>
                      </li>
                    )}
                  </ul>
                </dd>
              </div>
            </dl>
          </CardContent>
        </Card>
      </div>

      {/* Document upload dialog */}
      <Dialog open={showDocumentDialog} onOpenChange={closeDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              Upload {kycType === 'aadhar' ? 'Aadhar Card' : 'PAN Card'}
            </DialogTitle>
            <DialogDescription>
              Please upload a clear image of your {kycType === 'aadhar' ? 'Aadhar Card' : 'PAN Card'} for verification.
              Acceptable formats: JPG, PNG, PDF.
            </DialogDescription>
          </DialogHeader>

          {uploadSuccess === true ? (
            <div className="p-6">
              <Alert className="bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-900">
                <Check className="h-5 w-5 text-green-600 dark:text-green-400" />
                <AlertTitle className="text-green-800 dark:text-green-400">Document uploaded successfully</AlertTitle>
                <AlertDescription className="text-green-700 dark:text-green-500">
                  Your document has been uploaded and is pending verification by our team.
                </AlertDescription>
              </Alert>
              <div className="mt-4 flex justify-end">
                <Button onClick={closeDialog}>Close</Button>
              </div>
            </div>
          ) : uploadSuccess === false ? (
            <div className="p-6">
              <Alert className="bg-red-50 border-red-200 dark:bg-red-900/20 dark:border-red-900">
                <X className="h-5 w-5 text-red-600 dark:text-red-400" />
                <AlertTitle className="text-red-800 dark:text-red-400">Upload failed</AlertTitle>
                <AlertDescription className="text-red-700 dark:text-red-500">
                  There was an error uploading your document. Please try again.
                </AlertDescription>
              </Alert>
              <div className="mt-4 flex justify-end space-x-2">
                <Button variant="outline" onClick={closeDialog}>Cancel</Button>
                <Button onClick={() => setUploadSuccess(null)}>Try Again</Button>
              </div>
            </div>
          ) : (
            <div className="grid gap-4 p-4">
              <div className="grid gap-2">
                <label htmlFor="kyc-number" className="text-sm font-medium">
                  {kycType === 'aadhar' ? 'Aadhar Number' : 'PAN Number'}
                </label>
                <input 
                  id="kyc-number"
                  type="text" 
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  placeholder={kycType === 'aadhar' ? 'Enter 12-digit Aadhar number' : 'Enter 10-digit PAN number'} 
                  value={kycNumber}
                  onChange={(e) => setKycNumber(e.target.value)}
                />
              </div>
              <div className="grid gap-2">
                <label htmlFor="kyc-document" className="text-sm font-medium">
                  Document
                </label>
                <input 
                  ref={fileInputRef}
                  id="kyc-document" 
                  type="file" 
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  accept=".jpg,.jpeg,.png,.pdf"
                />
              </div>

              <div className="flex justify-end space-x-2 mt-4">
                <Button variant="outline" onClick={closeDialog}>
                  Cancel
                </Button>
                <Button onClick={handleDocumentUpload} disabled={uploadKycMutation.isPending}>
                  {uploadKycMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Upload className="mr-2 h-4 w-4" />
                      Upload
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Document viewer dialog */}
      <Dialog open={!!viewingDocument} onOpenChange={() => setViewingDocument(null)}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {viewingDocument?.includes('aadhar') ? 'Aadhar Card' : 'PAN Card'} Document
            </DialogTitle>
          </DialogHeader>
          <div className="flex justify-center">
            {viewingDocument && (
              <img 
                src={viewingDocument} 
                alt={viewingDocument.includes('aadhar') ? 'Aadhar Card' : 'PAN Card'} 
                className="max-h-[70vh] object-contain"
                onError={(e) => {
                  e.currentTarget.onerror = null;
                  e.currentTarget.src = "";
                  toast({
                    title: "Error loading document",
                    description: "The document could not be loaded. It may not exist or might have been deleted.",
                    variant: "destructive",
                  });
                }}
              />
            )}
          </div>
          <div className="flex justify-end">
            <Button onClick={() => setViewingDocument(null)}>Close</Button>
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
