import React, { useState } from 'react';
import DashboardLayout from '@/components/layout/dashboard-layout';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { insertBranchSchema, type Branch } from '@shared/schema';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { BuildingIcon, EditIcon, CheckCircleIcon, XCircleIcon } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/use-auth';

// Extended schema with validation
const branchFormSchema = insertBranchSchema.extend({
  name: z.string().min(3, 'Branch name must be at least 3 characters'),
  code: z.string().min(2, 'Branch code must be at least 2 characters'),
  address: z.string().min(5, 'Address must be at least 5 characters'),
  city: z.string().min(2, 'City must be at least 2 characters'),
  state: z.string().min(2, 'State must be at least 2 characters'),
  pincode: z.string().min(5, 'Pincode must be at least 5 characters'),
  phone: z.string().optional(),
  email: z.string().email('Please enter a valid email').optional(),
  managerName: z.string().optional(),
  isActive: z.boolean().default(true),
});

export default function BranchesPage() {
  const { toast } = useToast();
  const { isAdmin, isModerator } = useAuth();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedBranch, setSelectedBranch] = useState<Branch | null>(null);
  
  // Query to fetch branches
  const {
    data: branches,
    isLoading,
    error,
  } = useQuery<Branch[]>({
    queryKey: ['/api/branches'],
    queryFn: async () => {
      const res = await fetch('/api/branches');
      if (!res.ok) throw new Error('Failed to fetch branches');
      return res.json();
    },
  });
  
  // Add Branch Form
  const addBranchForm = useForm<z.infer<typeof branchFormSchema>>({
    resolver: zodResolver(branchFormSchema),
    defaultValues: {
      name: '',
      code: '',
      address: '',
      city: '',
      state: '',
      pincode: '',
      phone: '',
      email: '',
      managerName: '',
      isActive: true
    },
  });
  
  // Edit Branch Form
  const editBranchForm = useForm<z.infer<typeof branchFormSchema>>({
    resolver: zodResolver(branchFormSchema),
    defaultValues: {
      name: '',
      code: '',
      address: '',
      city: '',
      state: '',
      pincode: '',
      phone: '',
      email: '',
      managerName: '',
      isActive: true
    },
  });
  
  // Add Branch Mutation
  const addBranchMutation = useMutation({
    mutationFn: async (branch: z.infer<typeof branchFormSchema>) => {
      const response = await apiRequest('POST', '/api/branches', branch);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/branches'] });
      setIsAddDialogOpen(false);
      addBranchForm.reset();
      toast({
        title: 'Branch Added',
        description: 'The branch has been added successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to add branch',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  // Update Branch Mutation
  const updateBranchMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: z.infer<typeof branchFormSchema> }) => {
      const response = await apiRequest('PATCH', `/api/branches/${id}`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/branches'] });
      setIsEditDialogOpen(false);
      setSelectedBranch(null);
      toast({
        title: 'Branch Updated',
        description: 'The branch has been updated successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to update branch',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  // Handle Add Branch Form Submission
  function onAddBranchSubmit(values: z.infer<typeof branchFormSchema>) {
    addBranchMutation.mutate(values);
  }
  
  // Handle Edit Branch Form Submission
  function onEditBranchSubmit(values: z.infer<typeof branchFormSchema>) {
    if (selectedBranch) {
      updateBranchMutation.mutate({ id: selectedBranch.id, data: values });
    }
  }
  
  // Open Edit Dialog and Set Form Values
  function handleEditBranch(branch: Branch) {
    setSelectedBranch(branch);
    editBranchForm.reset({
      name: branch.name,
      code: branch.code,
      address: branch.address,
      city: branch.city,
      state: branch.state,
      pincode: branch.pincode,
      phone: branch.phone || '',
      email: branch.email || '',
      managerName: branch.managerName || '',
      isActive: branch.isActive,
    });
    setIsEditDialogOpen(true);
  }
  
  if (isLoading) {
    return (
      <DashboardLayout title="Branches">
        <div className="flex items-center justify-center h-64">
          <p>Loading branches...</p>
        </div>
      </DashboardLayout>
    );
  }
  
  if (error) {
    return (
      <DashboardLayout title="Branches">
        <div className="flex items-center justify-center h-64">
          <p className="text-red-500">Error: {(error as Error).message}</p>
        </div>
      </DashboardLayout>
    );
  }
  
  return (
    <DashboardLayout title="Branches">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Manage Branches</h2>
          {(isAdmin || isModerator) && (
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>Add New Branch</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Branch</DialogTitle>
                </DialogHeader>
                <Form {...addBranchForm}>
                  <form onSubmit={addBranchForm.handleSubmit(onAddBranchSubmit)} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={addBranchForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Branch Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={addBranchForm.control}
                        name="code"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Branch Code</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormField
                      control={addBranchForm.control}
                      name="address"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Address</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={addBranchForm.control}
                        name="city"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>City</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={addBranchForm.control}
                        name="state"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>State</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={addBranchForm.control}
                        name="pincode"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Pincode</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={addBranchForm.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={addBranchForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input {...field} type="email" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={addBranchForm.control}
                        name="managerName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Manager Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <DialogFooter>
                      <Button type="submit" disabled={addBranchMutation.isPending}>
                        {addBranchMutation.isPending ? 'Saving...' : 'Save Branch'}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          )}
        </div>
        
        {branches && branches.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {branches.map((branch) => (
              <Card key={branch.id}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-lg font-medium">
                    <div className="flex items-center">
                      <BuildingIcon className="mr-2 h-5 w-5" />
                      <span>{branch.name}</span>
                    </div>
                  </CardTitle>
                  <Badge 
                    variant={branch.isActive ? "default" : "destructive"}
                  >
                    {branch.isActive ? "Active" : "Inactive"}
                  </Badge>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-2">
                    <div className="text-sm font-semibold">Code: {branch.code}</div>
                    <div className="text-sm text-muted-foreground">{branch.address}</div>
                    <div className="text-sm text-muted-foreground">
                      {branch.city}, {branch.state}, {branch.pincode}
                    </div>
                    {branch.phone && (
                      <div className="text-sm text-muted-foreground">Phone: {branch.phone}</div>
                    )}
                    {branch.email && (
                      <div className="text-sm text-muted-foreground">Email: {branch.email}</div>
                    )}
                    {branch.managerName && (
                      <div className="text-sm text-muted-foreground">Manager: {branch.managerName}</div>
                    )}
                    {(isAdmin || isModerator) && (
                      <div className="mt-4">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full"
                          onClick={() => handleEditBranch(branch)}
                        >
                          <EditIcon className="h-4 w-4 mr-2" />
                          Edit Branch
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-64 bg-gray-50 rounded-lg">
            <BuildingIcon className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900">No Branches Found</h3>
            <p className="text-sm text-gray-500 mt-2">
              {isAdmin || isModerator 
                ? "Get started by adding a new branch" 
                : "No branches are currently available"}
            </p>
          </div>
        )}
      </div>
      
      {/* Edit Dialog */}
      {selectedBranch && (
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Branch: {selectedBranch.name}</DialogTitle>
            </DialogHeader>
            <Form {...editBranchForm}>
              <form onSubmit={editBranchForm.handleSubmit(onEditBranchSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editBranchForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Branch Name</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={editBranchForm.control}
                    name="code"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Branch Code</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={editBranchForm.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editBranchForm.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={editBranchForm.control}
                    name="state"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>State</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editBranchForm.control}
                    name="pincode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Pincode</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={editBranchForm.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editBranchForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input {...field} type="email" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={editBranchForm.control}
                    name="managerName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Manager Name</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={editBranchForm.control}
                  name="isActive"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                      <FormControl>
                        <div 
                          className={`cursor-pointer p-2 rounded-full ${field.value ? 'bg-green-100' : 'bg-red-100'}`}
                          onClick={() => field.onChange(!field.value)}
                        >
                          {field.value ? (
                            <CheckCircleIcon className="h-6 w-6 text-green-600" />
                          ) : (
                            <XCircleIcon className="h-6 w-6 text-red-600" />
                          )}
                        </div>
                      </FormControl>
                      <FormLabel className="cursor-pointer">
                        Branch is {field.value ? 'active' : 'inactive'}
                      </FormLabel>
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button type="submit" disabled={updateBranchMutation.isPending}>
                    {updateBranchMutation.isPending ? 'Updating...' : 'Update Branch'}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      )}
    </DashboardLayout>
  );
}