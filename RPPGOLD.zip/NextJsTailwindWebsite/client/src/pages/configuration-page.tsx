import React, { useState } from 'react';
import DashboardLayout from '@/components/layout/dashboard-layout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { DocumentUpload } from '@/components/document/document-upload';
import { CalendarIcon, FileText, Settings, Shield, Mail, FileCheck, Database, Zap, Upload } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

export default function ConfigurationPage() {
  const { toast } = useToast();
  const { isAdmin, isModerator } = useAuth();
  const [activeTab, setActiveTab] = useState('general');
  
  const [generalSettings, setGeneralSettings] = useState({
    companyName: 'Rainbow Prime Properties',
    supportEmail: 'support@rpp-gold.com',
    contactPhone: '+91 9876543210',
    companyAddress: '123 Financial District, Mumbai, India 400001',
    websiteUrl: 'https://rpp-gold.com',
    enableReferrals: true,
    enableNotifications: true,
    payoutInterval: '15', // days
    systemMaintenanceMode: false,
  });
  
  const [kycSettings, setKycSettings] = useState({
    requireAadharVerification: true,
    requirePanVerification: true,
    allowPdfDocuments: true,
    allowImageDocuments: true,
    maximumFileSize: 5, // MB
    enableAutoDetection: true,
    autoDenyInvalidDocuments: false,
    adminVerificationRequired: true,
  });
  
  const [emailSettings, setEmailSettings] = useState({
    enableEmails: true,
    adminEmail: 'admin@rpp-gold.com',
    notificationEmail: 'notifications@rpp-gold.com',
    welcomeEmailSubject: 'Welcome to RPP GOLD Investment Platform',
    welcomeEmailTemplate: 'Dear {name},\n\nWelcome to RPP GOLD Investment Platform. We are excited to have you on board!\n\nYour investment journey starts now.\n\nRegards,\nRPP GOLD Team',
    payoutEmailSubject: 'Your RPP GOLD Investment Payout',
    payoutEmailTemplate: 'Dear {name},\n\nYour investment payout of {amount} has been processed successfully.\n\nRegards,\nRPP GOLD Team',
  });
  
  const [rpgoldSettings, setRpgoldSettings] = useState({
    tier1MinAmount: 24999,
    tier1MaxAmount: 150000,
    tier1DailyReturn: 0.75,
    tier1WorkingDays: 267,
    
    tier2MinAmount: 300000,
    tier2MaxAmount: 500000,
    tier2DailyReturn: 1.0,
    tier2WorkingDays: 200,
    
    tier3MinAmount: 600000,
    tier3MaxAmount: Number.MAX_SAFE_INTEGER,
    tier3DailyReturn: 1.5,
    tier3WorkingDays: 132,
    
    level1Commission: 10,
    level2Commission: 7,
    level3Commission: 5,
    level4Commission: 4,
    level5Commission: 3,
  });
  
  const [backupSettings, setBackupSettings] = useState({
    enableAutomaticBackups: true,
    backupInterval: 'daily',
    backupRetentionDays: 30,
    includeDocuments: true,
    includeTransactionHistory: true,
  });
  
  // System health monitoring
  const [systemHealth, setSystemHealth] = useState({
    databaseStatus: 'healthy',
    serverStatus: 'healthy',
    diskSpace: 76,
    memoryUsage: 42,
    cpuUsage: 28,
    activeUsers: 187,
    lastBackup: '2023-09-15 04:30 AM',
  });
  
  const [aadharTemplateFile, setAadharTemplateFile] = useState<File | null>(null);
  const [panTemplateFile, setPanTemplateFile] = useState<File | null>(null);
  
  // Simulated mutation for updating settings
  const updateSettingsMutation = useMutation({
    mutationFn: async (data: Record<string, any>) => {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500));
      
      // In a real implementation, you would send to the API
      // return apiRequest('POST', '/api/settings', data);
      return data;
    },
    onSuccess: () => {
      toast({
        title: 'Settings updated',
        description: 'Your configuration changes have been saved successfully.',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to update settings',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const uploadTemplateMutation = useMutation({
    mutationFn: async ({ file, type }: { file: File, type: string }) => {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000));
      
      // In a real implementation, you would upload to the server
      // const formData = new FormData();
      // formData.append('file', file);
      // return apiRequest('POST', `/api/templates/${type}`, formData);
      return { success: true, filePath: URL.createObjectURL(file) };
    },
    onSuccess: () => {
      toast({
        title: 'Template uploaded',
        description: 'Your template file has been uploaded successfully.',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to upload template',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  // Handle saving settings based on active tab
  const handleSaveSettings = () => {
    let dataToSave;
    
    switch (activeTab) {
      case 'general':
        dataToSave = { general: generalSettings };
        break;
      case 'kyc':
        dataToSave = { kyc: kycSettings };
        break;
      case 'email':
        dataToSave = { email: emailSettings };
        break;
      case 'rpgold':
        dataToSave = { rpgold: rpgoldSettings };
        break;
      case 'backup':
        dataToSave = { backup: backupSettings };
        break;
      default:
        return;
    }
    
    updateSettingsMutation.mutate(dataToSave);
  };
  
  const handleUploadAadharTemplate = (file: File) => {
    uploadTemplateMutation.mutate({ file, type: 'aadhar' });
  };
  
  const handleUploadPanTemplate = (file: File) => {
    uploadTemplateMutation.mutate({ file, type: 'pan' });
  };
  
  if (!isAdmin) {
    return (
      <DashboardLayout title="Configuration">
        <div className="container mx-auto py-10">
          <Card>
            <CardHeader>
              <CardTitle>Access Denied</CardTitle>
              <CardDescription>
                You need administrator permissions to access the configuration page.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p>Please contact an administrator if you believe you should have access to this page.</p>
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    );
  }
  
  return (
    <DashboardLayout title="System Configuration">
      <div className="container mx-auto py-10">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">System Configuration</h1>
            <p className="text-muted-foreground">
              Configure system settings, KYC requirements, and RPP GOLD business parameters.
            </p>
          </div>
          <Button 
            onClick={handleSaveSettings}
            disabled={updateSettingsMutation.isPending}
          >
            {updateSettingsMutation.isPending ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
        
        <Tabs defaultValue="general" onValueChange={setActiveTab} value={activeTab}>
          <TabsList className="grid grid-cols-6 mb-8">
            <TabsTrigger value="general" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              <span>General</span>
            </TabsTrigger>
            <TabsTrigger value="kyc" className="flex items-center gap-2">
              <FileCheck className="h-4 w-4" />
              <span>KYC</span>
            </TabsTrigger>
            <TabsTrigger value="email" className="flex items-center gap-2">
              <Mail className="h-4 w-4" />
              <span>Email</span>
            </TabsTrigger>
            <TabsTrigger value="rpgold" className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              <span>RPP GOLD</span>
            </TabsTrigger>
            <TabsTrigger value="templates" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              <span>Templates</span>
            </TabsTrigger>
            <TabsTrigger value="backup" className="flex items-center gap-2">
              <Database className="h-4 w-4" />
              <span>Backup</span>
            </TabsTrigger>
          </TabsList>
          
          {/* General Settings Tab */}
          <TabsContent value="general">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Company Information</CardTitle>
                  <CardDescription>
                    Basic company details used throughout the application.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="companyName">Company Name</Label>
                    <Input 
                      id="companyName"
                      value={generalSettings.companyName}
                      onChange={(e) => setGeneralSettings({ ...generalSettings, companyName: e.target.value })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="supportEmail">Support Email</Label>
                    <Input 
                      id="supportEmail"
                      type="email"
                      value={generalSettings.supportEmail}
                      onChange={(e) => setGeneralSettings({ ...generalSettings, supportEmail: e.target.value })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="contactPhone">Contact Phone</Label>
                    <Input 
                      id="contactPhone"
                      value={generalSettings.contactPhone}
                      onChange={(e) => setGeneralSettings({ ...generalSettings, contactPhone: e.target.value })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="companyAddress">Company Address</Label>
                    <Textarea 
                      id="companyAddress"
                      value={generalSettings.companyAddress}
                      onChange={(e) => setGeneralSettings({ ...generalSettings, companyAddress: e.target.value })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="websiteUrl">Website URL</Label>
                    <Input 
                      id="websiteUrl"
                      value={generalSettings.websiteUrl}
                      onChange={(e) => setGeneralSettings({ ...generalSettings, websiteUrl: e.target.value })}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>System Settings</CardTitle>
                  <CardDescription>
                    Configure system behavior and features.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="enableReferrals">Enable Referrals</Label>
                      <p className="text-sm text-muted-foreground">
                        Allow users to refer others and earn commissions.
                      </p>
                    </div>
                    <Switch 
                      id="enableReferrals" 
                      checked={generalSettings.enableReferrals}
                      onCheckedChange={(checked) => setGeneralSettings({ ...generalSettings, enableReferrals: checked })}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="enableNotifications">Enable Notifications</Label>
                      <p className="text-sm text-muted-foreground">
                        Send email and in-app notifications to users.
                      </p>
                    </div>
                    <Switch 
                      id="enableNotifications" 
                      checked={generalSettings.enableNotifications}
                      onCheckedChange={(checked) => setGeneralSettings({ ...generalSettings, enableNotifications: checked })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="payoutInterval">Payout Interval (days)</Label>
                    <Input 
                      id="payoutInterval"
                      type="number"
                      value={generalSettings.payoutInterval}
                      onChange={(e) => setGeneralSettings({ ...generalSettings, payoutInterval: e.target.value })}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="systemMaintenanceMode" className="text-orange-500 font-medium">System Maintenance Mode</Label>
                      <p className="text-sm text-muted-foreground">
                        Temporarily disable user access for maintenance.
                      </p>
                    </div>
                    <Switch 
                      id="systemMaintenanceMode" 
                      checked={generalSettings.systemMaintenanceMode}
                      onCheckedChange={(checked) => setGeneralSettings({ ...generalSettings, systemMaintenanceMode: checked })}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>System Health</CardTitle>
                  <CardDescription>
                    Current system status and health metrics.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <Label>Database Status</Label>
                        <span className={`text-sm font-medium ${
                          systemHealth.databaseStatus === 'healthy' ? 'text-green-500' : 'text-red-500'
                        }`}>
                          {systemHealth.databaseStatus === 'healthy' ? 'Healthy' : 'Issues Detected'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <Label>Server Status</Label>
                        <span className={`text-sm font-medium ${
                          systemHealth.serverStatus === 'healthy' ? 'text-green-500' : 'text-red-500'
                        }`}>
                          {systemHealth.serverStatus === 'healthy' ? 'Healthy' : 'Issues Detected'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <Label>Active Users</Label>
                        <span className="text-sm font-medium">{systemHealth.activeUsers}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <Label>Last Backup</Label>
                        <span className="text-sm font-medium">{systemHealth.lastBackup}</span>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm font-medium">
                          <span>Disk Space</span>
                          <span>{systemHealth.diskSpace}%</span>
                        </div>
                        <Progress value={systemHealth.diskSpace} className="h-2" />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm font-medium">
                          <span>Memory Usage</span>
                          <span>{systemHealth.memoryUsage}%</span>
                        </div>
                        <Progress value={systemHealth.memoryUsage} className="h-2" />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm font-medium">
                          <span>CPU Usage</span>
                          <span>{systemHealth.cpuUsage}%</span>
                        </div>
                        <Progress value={systemHealth.cpuUsage} className="h-2" />
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <Button variant="outline" size="sm" className="w-full">
                        Refresh Status
                      </Button>
                      <Button variant="outline" size="sm" className="w-full">
                        Run Database Check
                      </Button>
                      <Button variant="outline" size="sm" className="w-full">
                        Clear Cache
                      </Button>
                      <Button variant="outline" size="sm" className="w-full">
                        View System Logs
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* KYC Settings Tab */}
          <TabsContent value="kyc">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Document Requirements</CardTitle>
                  <CardDescription>
                    Configure which documents are required and how they are validated.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="requireAadharVerification">Require Aadhar Verification</Label>
                      <p className="text-sm text-muted-foreground">
                        Users must have a verified Aadhar card.
                      </p>
                    </div>
                    <Switch 
                      id="requireAadharVerification" 
                      checked={kycSettings.requireAadharVerification}
                      onCheckedChange={(checked) => setKycSettings({ ...kycSettings, requireAadharVerification: checked })}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="requirePanVerification">Require PAN Verification</Label>
                      <p className="text-sm text-muted-foreground">
                        Users must have a verified PAN card.
                      </p>
                    </div>
                    <Switch 
                      id="requirePanVerification" 
                      checked={kycSettings.requirePanVerification}
                      onCheckedChange={(checked) => setKycSettings({ ...kycSettings, requirePanVerification: checked })}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="allowPdfDocuments">Allow PDF Documents</Label>
                      <p className="text-sm text-muted-foreground">
                        Allow users to upload PDFs for KYC verification.
                      </p>
                    </div>
                    <Switch 
                      id="allowPdfDocuments" 
                      checked={kycSettings.allowPdfDocuments}
                      onCheckedChange={(checked) => setKycSettings({ ...kycSettings, allowPdfDocuments: checked })}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="allowImageDocuments">Allow Image Documents</Label>
                      <p className="text-sm text-muted-foreground">
                        Allow users to upload images (JPG, PNG) for KYC verification.
                      </p>
                    </div>
                    <Switch 
                      id="allowImageDocuments" 
                      checked={kycSettings.allowImageDocuments}
                      onCheckedChange={(checked) => setKycSettings({ ...kycSettings, allowImageDocuments: checked })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="maximumFileSize">Maximum File Size (MB)</Label>
                    <Input 
                      id="maximumFileSize"
                      type="number"
                      min="1"
                      max="20"
                      value={kycSettings.maximumFileSize}
                      onChange={(e) => setKycSettings({ ...kycSettings, maximumFileSize: parseInt(e.target.value) })}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Verification Process</CardTitle>
                  <CardDescription>
                    Configure how documents are validated and processed.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="enableAutoDetection">Enable Auto-Detection</Label>
                      <p className="text-sm text-muted-foreground">
                        Use AI to automatically detect document validity.
                      </p>
                    </div>
                    <Switch 
                      id="enableAutoDetection" 
                      checked={kycSettings.enableAutoDetection}
                      onCheckedChange={(checked) => setKycSettings({ ...kycSettings, enableAutoDetection: checked })}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="autoDenyInvalidDocuments">Auto-Deny Invalid Documents</Label>
                      <p className="text-sm text-muted-foreground">
                        Automatically reject documents that fail validation.
                      </p>
                    </div>
                    <Switch 
                      id="autoDenyInvalidDocuments" 
                      checked={kycSettings.autoDenyInvalidDocuments}
                      onCheckedChange={(checked) => setKycSettings({ ...kycSettings, autoDenyInvalidDocuments: checked })}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="adminVerificationRequired">Admin Verification Required</Label>
                      <p className="text-sm text-muted-foreground">
                        Require admin approval for all documents even if auto-validated.
                      </p>
                    </div>
                    <Switch 
                      id="adminVerificationRequired" 
                      checked={kycSettings.adminVerificationRequired}
                      onCheckedChange={(checked) => setKycSettings({ ...kycSettings, adminVerificationRequired: checked })}
                    />
                  </div>
                  
                  <div className="pt-4">
                    <Button variant="outline" className="w-full">
                      View Pending Verifications
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Email Settings Tab */}
          <TabsContent value="email">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Email Configuration</CardTitle>
                  <CardDescription>
                    Configure email settings and addresses.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="enableEmails">Enable Email Notifications</Label>
                      <p className="text-sm text-muted-foreground">
                        Send emails for important events and notifications.
                      </p>
                    </div>
                    <Switch 
                      id="enableEmails" 
                      checked={emailSettings.enableEmails}
                      onCheckedChange={(checked) => setEmailSettings({ ...emailSettings, enableEmails: checked })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="adminEmail">Admin Email</Label>
                    <Input 
                      id="adminEmail"
                      type="email"
                      value={emailSettings.adminEmail}
                      onChange={(e) => setEmailSettings({ ...emailSettings, adminEmail: e.target.value })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="notificationEmail">Notification Email (From Address)</Label>
                    <Input 
                      id="notificationEmail"
                      type="email"
                      value={emailSettings.notificationEmail}
                      onChange={(e) => setEmailSettings({ ...emailSettings, notificationEmail: e.target.value })}
                    />
                  </div>
                  
                  <div className="pt-2">
                    <Button variant="outline" size="sm">
                      Test Email Configuration
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Email Templates</CardTitle>
                  <CardDescription>
                    Configure email templates for different notifications.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="welcomeEmailSubject">Welcome Email Subject</Label>
                    <Input 
                      id="welcomeEmailSubject"
                      value={emailSettings.welcomeEmailSubject}
                      onChange={(e) => setEmailSettings({ ...emailSettings, welcomeEmailSubject: e.target.value })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="welcomeEmailTemplate">Welcome Email Template</Label>
                    <Textarea 
                      id="welcomeEmailTemplate"
                      rows={5}
                      value={emailSettings.welcomeEmailTemplate}
                      onChange={(e) => setEmailSettings({ ...emailSettings, welcomeEmailTemplate: e.target.value })}
                      className="font-mono text-sm"
                    />
                    <p className="text-xs text-muted-foreground">
                      Available variables: {"{name}"}, {"{username}"}
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="payoutEmailSubject">Payout Email Subject</Label>
                    <Input 
                      id="payoutEmailSubject"
                      value={emailSettings.payoutEmailSubject}
                      onChange={(e) => setEmailSettings({ ...emailSettings, payoutEmailSubject: e.target.value })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="payoutEmailTemplate">Payout Email Template</Label>
                    <Textarea 
                      id="payoutEmailTemplate"
                      rows={5}
                      value={emailSettings.payoutEmailTemplate}
                      onChange={(e) => setEmailSettings({ ...emailSettings, payoutEmailTemplate: e.target.value })}
                      className="font-mono text-sm"
                    />
                    <p className="text-xs text-muted-foreground">
                      Available variables: {"{name}"}, {"{amount}"}, {"{date}"}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* RPP GOLD Settings Tab */}
          <TabsContent value="rpgold">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader className="bg-yellow-50">
                  <CardTitle>Tier 1 Configuration</CardTitle>
                  <CardDescription>
                    Configure settings for RPP GOLD Tier 1 investments.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 pt-6">
                  <div className="space-y-2">
                    <Label htmlFor="tier1MinAmount">Minimum Investment (₹)</Label>
                    <Input 
                      id="tier1MinAmount"
                      type="number"
                      value={rpgoldSettings.tier1MinAmount}
                      onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, tier1MinAmount: parseInt(e.target.value) })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="tier1MaxAmount">Maximum Investment (₹)</Label>
                    <Input 
                      id="tier1MaxAmount"
                      type="number"
                      value={rpgoldSettings.tier1MaxAmount}
                      onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, tier1MaxAmount: parseInt(e.target.value) })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="tier1DailyReturn">Daily Return Rate (%)</Label>
                    <Input 
                      id="tier1DailyReturn"
                      type="number"
                      step="0.01"
                      value={rpgoldSettings.tier1DailyReturn}
                      onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, tier1DailyReturn: parseFloat(e.target.value) })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="tier1WorkingDays">Working Days</Label>
                    <Input 
                      id="tier1WorkingDays"
                      type="number"
                      value={rpgoldSettings.tier1WorkingDays}
                      onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, tier1WorkingDays: parseInt(e.target.value) })}
                    />
                  </div>
                  
                  <div className="pt-2">
                    <div className="text-sm font-medium">Total Return</div>
                    <div className="text-2xl font-bold text-green-600">
                      {(rpgoldSettings.tier1DailyReturn * rpgoldSettings.tier1WorkingDays).toFixed(2)}%
                    </div>
                    <p className="text-xs text-muted-foreground">
                      ₹10,000 grows to ₹{Math.round(10000 * (1 + (rpgoldSettings.tier1DailyReturn * rpgoldSettings.tier1WorkingDays / 100))).toLocaleString('en-IN')}
                    </p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="bg-orange-50">
                  <CardTitle>Tier 2 Configuration</CardTitle>
                  <CardDescription>
                    Configure settings for RPP GOLD Tier 2 investments.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 pt-6">
                  <div className="space-y-2">
                    <Label htmlFor="tier2MinAmount">Minimum Investment (₹)</Label>
                    <Input 
                      id="tier2MinAmount"
                      type="number"
                      value={rpgoldSettings.tier2MinAmount}
                      onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, tier2MinAmount: parseInt(e.target.value) })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="tier2MaxAmount">Maximum Investment (₹)</Label>
                    <Input 
                      id="tier2MaxAmount"
                      type="number"
                      value={rpgoldSettings.tier2MaxAmount}
                      onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, tier2MaxAmount: parseInt(e.target.value) })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="tier2DailyReturn">Daily Return Rate (%)</Label>
                    <Input 
                      id="tier2DailyReturn"
                      type="number"
                      step="0.01"
                      value={rpgoldSettings.tier2DailyReturn}
                      onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, tier2DailyReturn: parseFloat(e.target.value) })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="tier2WorkingDays">Working Days</Label>
                    <Input 
                      id="tier2WorkingDays"
                      type="number"
                      value={rpgoldSettings.tier2WorkingDays}
                      onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, tier2WorkingDays: parseInt(e.target.value) })}
                    />
                  </div>
                  
                  <div className="pt-2">
                    <div className="text-sm font-medium">Total Return</div>
                    <div className="text-2xl font-bold text-green-600">
                      {(rpgoldSettings.tier2DailyReturn * rpgoldSettings.tier2WorkingDays).toFixed(2)}%
                    </div>
                    <p className="text-xs text-muted-foreground">
                      ₹300,000 grows to ₹{Math.round(300000 * (1 + (rpgoldSettings.tier2DailyReturn * rpgoldSettings.tier2WorkingDays / 100))).toLocaleString('en-IN')}
                    </p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="bg-amber-50">
                  <CardTitle>Tier 3 Configuration</CardTitle>
                  <CardDescription>
                    Configure settings for RPP GOLD Tier 3 investments.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 pt-6">
                  <div className="space-y-2">
                    <Label htmlFor="tier3MinAmount">Minimum Investment (₹)</Label>
                    <Input 
                      id="tier3MinAmount"
                      type="number"
                      value={rpgoldSettings.tier3MinAmount}
                      onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, tier3MinAmount: parseInt(e.target.value) })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="tier3DailyReturn">Daily Return Rate (%)</Label>
                    <Input 
                      id="tier3DailyReturn"
                      type="number"
                      step="0.01"
                      value={rpgoldSettings.tier3DailyReturn}
                      onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, tier3DailyReturn: parseFloat(e.target.value) })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="tier3WorkingDays">Working Days</Label>
                    <Input 
                      id="tier3WorkingDays"
                      type="number"
                      value={rpgoldSettings.tier3WorkingDays}
                      onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, tier3WorkingDays: parseInt(e.target.value) })}
                    />
                  </div>
                  
                  <div className="pt-2">
                    <div className="text-sm font-medium">Total Return</div>
                    <div className="text-2xl font-bold text-green-600">
                      {(rpgoldSettings.tier3DailyReturn * rpgoldSettings.tier3WorkingDays).toFixed(2)}%
                    </div>
                    <p className="text-xs text-muted-foreground">
                      ₹600,000 grows to ₹{Math.round(600000 * (1 + (rpgoldSettings.tier3DailyReturn * rpgoldSettings.tier3WorkingDays / 100))).toLocaleString('en-IN')}
                    </p>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="md:col-span-3">
                <CardHeader>
                  <CardTitle>Referral Commission Structure</CardTitle>
                  <CardDescription>
                    Configure the multi-level marketing commission rates for referrals.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="level1Commission">Level 1 Commission (%)</Label>
                        <Input 
                          id="level1Commission"
                          type="number"
                          step="0.1"
                          value={rpgoldSettings.level1Commission}
                          onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, level1Commission: parseFloat(e.target.value) })}
                        />
                      </div>
                      <div className="p-3 bg-green-50 border border-green-100 rounded-md">
                        <div className="text-xs text-gray-500">Example Commission</div>
                        <div className="text-lg font-bold text-green-600">₹{Math.round(100000 * rpgoldSettings.level1Commission / 100).toLocaleString('en-IN')}</div>
                        <div className="text-xs text-gray-500">on ₹1 Lakh investment</div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="level2Commission">Level 2 Commission (%)</Label>
                        <Input 
                          id="level2Commission"
                          type="number"
                          step="0.1"
                          value={rpgoldSettings.level2Commission}
                          onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, level2Commission: parseFloat(e.target.value) })}
                        />
                      </div>
                      <div className="p-3 bg-green-50 border border-green-100 rounded-md">
                        <div className="text-xs text-gray-500">Example Commission</div>
                        <div className="text-lg font-bold text-green-600">₹{Math.round(100000 * rpgoldSettings.level2Commission / 100).toLocaleString('en-IN')}</div>
                        <div className="text-xs text-gray-500">on ₹1 Lakh investment</div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="level3Commission">Level 3 Commission (%)</Label>
                        <Input 
                          id="level3Commission"
                          type="number"
                          step="0.1"
                          value={rpgoldSettings.level3Commission}
                          onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, level3Commission: parseFloat(e.target.value) })}
                        />
                      </div>
                      <div className="p-3 bg-green-50 border border-green-100 rounded-md">
                        <div className="text-xs text-gray-500">Example Commission</div>
                        <div className="text-lg font-bold text-green-600">₹{Math.round(100000 * rpgoldSettings.level3Commission / 100).toLocaleString('en-IN')}</div>
                        <div className="text-xs text-gray-500">on ₹1 Lakh investment</div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="level4Commission">Level 4 Commission (%)</Label>
                        <Input 
                          id="level4Commission"
                          type="number"
                          step="0.1"
                          value={rpgoldSettings.level4Commission}
                          onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, level4Commission: parseFloat(e.target.value) })}
                        />
                      </div>
                      <div className="p-3 bg-green-50 border border-green-100 rounded-md">
                        <div className="text-xs text-gray-500">Example Commission</div>
                        <div className="text-lg font-bold text-green-600">₹{Math.round(100000 * rpgoldSettings.level4Commission / 100).toLocaleString('en-IN')}</div>
                        <div className="text-xs text-gray-500">on ₹1 Lakh investment</div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="level5Commission">Level 5 Commission (%)</Label>
                        <Input 
                          id="level5Commission"
                          type="number"
                          step="0.1"
                          value={rpgoldSettings.level5Commission}
                          onChange={(e) => setRpgoldSettings({ ...rpgoldSettings, level5Commission: parseFloat(e.target.value) })}
                        />
                      </div>
                      <div className="p-3 bg-green-50 border border-green-100 rounded-md">
                        <div className="text-xs text-gray-500">Example Commission</div>
                        <div className="text-lg font-bold text-green-600">₹{Math.round(100000 * rpgoldSettings.level5Commission / 100).toLocaleString('en-IN')}</div>
                        <div className="text-xs text-gray-500">on ₹1 Lakh investment</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6 p-4 bg-blue-50 rounded-md">
                    <div className="font-medium">Total Referral Commission Structure</div>
                    <div className="mt-2 text-sm">
                      On a ₹1,00,000 investment, the total referral commission payout would be:
                      ₹{Math.round(100000 * (
                        rpgoldSettings.level1Commission + 
                        rpgoldSettings.level2Commission + 
                        rpgoldSettings.level3Commission + 
                        rpgoldSettings.level4Commission + 
                        rpgoldSettings.level5Commission
                      ) / 100).toLocaleString('en-IN')} 
                      ({(
                        rpgoldSettings.level1Commission + 
                        rpgoldSettings.level2Commission + 
                        rpgoldSettings.level3Commission + 
                        rpgoldSettings.level4Commission + 
                        rpgoldSettings.level5Commission
                      )}% total)
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Templates Tab */}
          <TabsContent value="templates">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Aadhar Card Template</CardTitle>
                  <CardDescription>
                    Upload a template for Aadhar card verification.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <DocumentUpload
                    documentType="aadhar"
                    title="Aadhar Card Template"
                    description="Upload a sample Aadhar card to use as a template for verification."
                    onUpload={handleUploadAadharTemplate}
                    isUploading={uploadTemplateMutation.isPending}
                    existingDocumentUrl="/assets/aadhar-template.jpg"
                  />
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>PAN Card Template</CardTitle>
                  <CardDescription>
                    Upload a template for PAN card verification.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <DocumentUpload
                    documentType="pan"
                    title="PAN Card Template"
                    description="Upload a sample PAN card to use as a template for verification."
                    onUpload={handleUploadPanTemplate}
                    isUploading={uploadTemplateMutation.isPending}
                    existingDocumentUrl="/assets/pan-template.jpg"
                  />
                </CardContent>
              </Card>
              
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Document Detection Settings</CardTitle>
                  <CardDescription>
                    Configure automatic document detection and validation settings.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-4">
                      <h3 className="font-medium">Aadhar Card Detection</h3>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="detectAadharText">Text Detection</Label>
                        <Switch id="detectAadharText" defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="detectAadharQR">QR Code Detection</Label>
                        <Switch id="detectAadharQR" defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="detectAadharLayout">Layout Detection</Label>
                        <Switch id="detectAadharLayout" defaultChecked />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="aadharMinConfidence">Minimum Confidence (%)</Label>
                        <Input id="aadharMinConfidence" type="number" defaultValue="70" />
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="font-medium">PAN Card Detection</h3>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="detectPanText">Text Detection</Label>
                        <Switch id="detectPanText" defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="detectPanPattern">Pattern Detection</Label>
                        <Switch id="detectPanPattern" defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="detectPanLayout">Layout Detection</Label>
                        <Switch id="detectPanLayout" defaultChecked />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="panMinConfidence">Minimum Confidence (%)</Label>
                        <Input id="panMinConfidence" type="number" defaultValue="75" />
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="font-medium">Validation Rules</h3>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="validateIdNumbers">Validate ID Numbers</Label>
                        <Switch id="validateIdNumbers" defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="checkImageQuality">Check Image Quality</Label>
                        <Switch id="checkImageQuality" defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label htmlFor="detectTampering">Detect Tampering</Label>
                        <Switch id="detectTampering" defaultChecked />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="minimumResolution">Minimum Resolution (DPI)</Label>
                        <Input id="minimumResolution" type="number" defaultValue="150" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Backup Settings Tab */}
          <TabsContent value="backup">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Backup Configuration</CardTitle>
                  <CardDescription>
                    Configure database backup settings.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="enableAutomaticBackups">Enable Automatic Backups</Label>
                      <p className="text-sm text-muted-foreground">
                        Automatically backup the database on a schedule.
                      </p>
                    </div>
                    <Switch 
                      id="enableAutomaticBackups" 
                      checked={backupSettings.enableAutomaticBackups}
                      onCheckedChange={(checked) => setBackupSettings({ ...backupSettings, enableAutomaticBackups: checked })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="backupInterval">Backup Interval</Label>
                    <Select 
                      value={backupSettings.backupInterval}
                      onValueChange={(value) => setBackupSettings({ ...backupSettings, backupInterval: value })}
                    >
                      <SelectTrigger id="backupInterval">
                        <SelectValue placeholder="Select backup interval" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hourly">Hourly</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="backupRetentionDays">Backup Retention (Days)</Label>
                    <Input 
                      id="backupRetentionDays"
                      type="number"
                      value={backupSettings.backupRetentionDays}
                      onChange={(e) => setBackupSettings({ ...backupSettings, backupRetentionDays: parseInt(e.target.value) })}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="includeDocuments">Include Documents</Label>
                      <p className="text-sm text-muted-foreground">
                        Include KYC documents in backups.
                      </p>
                    </div>
                    <Switch 
                      id="includeDocuments" 
                      checked={backupSettings.includeDocuments}
                      onCheckedChange={(checked) => setBackupSettings({ ...backupSettings, includeDocuments: checked })}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="includeTransactionHistory">Include Transaction History</Label>
                      <p className="text-sm text-muted-foreground">
                        Include complete transaction history in backups.
                      </p>
                    </div>
                    <Switch 
                      id="includeTransactionHistory" 
                      checked={backupSettings.includeTransactionHistory}
                      onCheckedChange={(checked) => setBackupSettings({ ...backupSettings, includeTransactionHistory: checked })}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Manual Backup Actions</CardTitle>
                  <CardDescription>
                    Perform manual backup and restoration operations.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Button variant="default" className="w-full">
                      Create Manual Backup Now
                    </Button>
                    <p className="text-xs text-muted-foreground">
                      Create a full backup of the database and documents.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full">
                      Export Database Only
                    </Button>
                    <p className="text-xs text-muted-foreground">
                      Export only the database data without documents.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full">
                      Export User Data
                    </Button>
                    <p className="text-xs text-muted-foreground">
                      Export user data in a spreadsheet format.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Button variant="destructive" className="w-full">
                      Restore from Backup
                    </Button>
                    <p className="text-xs text-muted-foreground">
                      Restore the database from a previous backup.
                    </p>
                  </div>
                  
                  <div className="pt-4">
                    <h3 className="text-sm font-medium mb-2">Recent Backups</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between p-2 bg-gray-50 rounded">
                        <span>2023-09-15 04:30 AM</span>
                        <span className="text-blue-600">Download</span>
                      </div>
                      <div className="flex justify-between p-2 bg-gray-50 rounded">
                        <span>2023-09-14 04:30 AM</span>
                        <span className="text-blue-600">Download</span>
                      </div>
                      <div className="flex justify-between p-2 bg-gray-50 rounded">
                        <span>2023-09-13 04:30 AM</span>
                        <span className="text-blue-600">Download</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}