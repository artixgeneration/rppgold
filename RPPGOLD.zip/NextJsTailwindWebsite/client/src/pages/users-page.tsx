import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/dashboard-layout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DocumentUpload } from "@/components/document/document-upload";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useQuery, useMutation } from "@tanstack/react-query";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { User, UserRole, Branch, InvestmentType, Investment, Referral, ReferralLevel } from "@shared/schema";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { 
  MoreHorizontal, 
  Pencil, 
  FileCheck, 
  Upload, 
  Check, 
  AlertCircle,
  UserPlus,
  Calendar as CalendarIcon,
  CreditCard,
  Wallet,
  UserCircle,
  CoinsIcon,
  Banknote, 
  PercentIcon, 
  ClockIcon, 
  BarChartIcon, 
  UsersIcon, 
  PiggyBankIcon, 
  ArrowLeftRight, 
  LockIcon, 
  UnlockIcon 
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useForm } from "react-hook-form";
import { format } from "date-fns";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { cn } from "@/lib/utils";


type KYCStatus = {
  aadharStatus: {
    uploaded: boolean;
    verified: boolean;
  };
  panStatus: {
    uploaded: boolean;
    verified: boolean;
  };
};

// Admin user registration form schema
const userFormSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  fullName: z.string().min(2, "Full name is required"),
  email: z.string().email("Invalid email address").optional().nullable(),
  role: z.string().default(UserRole.CUSTOMER),
  branch: z.string().optional().nullable(),
  phoneNumber: z.string().optional().nullable(),
  dateOfBirth: z.date().optional().nullable(),
  address: z.string().optional().nullable(),
  city: z.string().optional().nullable(),
  state: z.string().optional().nullable(),
  pincode: z.string().optional().nullable(),
  aadharNumber: z.string().optional().nullable(),
  panNumber: z.string().optional().nullable(),
  bankName: z.string().optional().nullable(),
  accountNumber: z.string().optional().nullable(),
  ifscCode: z.string().optional().nullable(),
});

// Investment form schema for admin user registration
const investmentFormSchema = z.object({
  branchId: z.string(),
  type: z.string(),
  amount: z.string(),
  startDate: z.date().default(() => new Date()),
  transactionDetails: z.object({
    paymentMethod: z.string(),
    transactionId: z.string().optional(),
    receiptNumber: z.string().optional(),
    date: z.date().default(() => new Date()),
    notes: z.string().optional(),
  }),
});

// Combined schema for admin user registration with investment
const adminRegisterSchema = z.object({
  user: userFormSchema,
  investment: investmentFormSchema.optional(),
});

type UserFormValues = z.infer<typeof userFormSchema>;
type InvestmentFormValues = z.infer<typeof investmentFormSchema>;
type AdminRegisterValues = z.infer<typeof adminRegisterSchema>;

export default function UsersPage() {
  const { toast } = useToast();
  const { isAdmin, isModerator } = useAuth();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isAadharUploadOpen, setIsAadharUploadOpen] = useState(false);
  const [isPanUploadOpen, setIsPanUploadOpen] = useState(false);
  const [isKycViewOpen, setIsKycViewOpen] = useState(false);
  const [isUserDetailsOpen, setIsUserDetailsOpen] = useState(false);
  const [isAdminRegisterOpen, setIsAdminRegisterOpen] = useState(false);
  const [aadharFile, setAadharFile] = useState<File | null>(null);
  const [panFile, setPanFile] = useState<File | null>(null);

  const { data: users, isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const { data: branches } = useQuery<Branch[]>({
    queryKey: ["/api/branches"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const { data: kycStatus, refetch: refetchKycStatus } = useQuery<KYCStatus>({
    queryKey: ["/api/users", selectedUser?.id, "kyc-status"],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: isKycViewOpen && !!selectedUser,
  });
  
  const { data: userInvestments, isLoading: isLoadingInvestments } = useQuery<Investment[]>({
    queryKey: ["/api/investments/user", selectedUser?.id],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: isUserDetailsOpen && !!selectedUser,
  });
  
  const { data: referrals } = useQuery<Referral[]>({
    queryKey: ["/api/referrals"],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: isUserDetailsOpen && !!selectedUser,
  });

  // Upload Aadhar mutation
  const uploadAadharMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      if (!selectedUser) throw new Error("No user selected");
      const res = await fetch(`/api/users/${selectedUser.id}/aadhar`, {
        method: "POST",
        body: formData,
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to upload Aadhar card");
      }
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Aadhar Card Uploaded",
        description: "Aadhar card has been uploaded successfully.",
      });
      setAadharFile(null);
      setIsAadharUploadOpen(false);
      refetchKycStatus();
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Upload Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Upload PAN mutation
  const uploadPanMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      if (!selectedUser) throw new Error("No user selected");
      const res = await fetch(`/api/users/${selectedUser.id}/pan`, {
        method: "POST",
        body: formData,
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to upload PAN card");
      }
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "PAN Card Uploaded",
        description: "PAN card has been uploaded successfully.",
      });
      setPanFile(null);
      setIsPanUploadOpen(false);
      refetchKycStatus();
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Upload Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Verify Aadhar mutation
  const verifyAadharMutation = useMutation({
    mutationFn: async () => {
      if (!selectedUser) throw new Error("No user selected");
      const res = await apiRequest("POST", `/api/users/${selectedUser.id}/verify-aadhar`);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to verify Aadhar card");
      }
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Aadhar Card Verified",
        description: "Aadhar card has been verified successfully.",
      });
      refetchKycStatus();
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Verification Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Verify PAN mutation
  const verifyPanMutation = useMutation({
    mutationFn: async () => {
      if (!selectedUser) throw new Error("No user selected");
      const res = await apiRequest("POST", `/api/users/${selectedUser.id}/verify-pan`);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to verify PAN card");
      }
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "PAN Card Verified",
        description: "PAN card has been verified successfully.",
      });
      refetchKycStatus();
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Verification Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Admin registration mutation - creates a user and investment
  const adminRegisterMutation = useMutation({
    mutationFn: async (data: AdminRegisterValues) => {
      const res = await apiRequest("POST", "/api/admin/register-with-investment", data);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to register user with investment");
      }
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "User Registered",
        description: "User and investment have been created successfully.",
      });
      setIsAdminRegisterOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleUploadAadhar = () => {
    if (!aadharFile || !selectedUser) return;
    
    const formData = new FormData();
    formData.append("aadharCard", aadharFile);
    uploadAadharMutation.mutate(formData);
  };

  const handleUploadPan = () => {
    if (!panFile || !selectedUser) return;
    
    const formData = new FormData();
    formData.append("panCard", panFile);
    uploadPanMutation.mutate(formData);
  };

  const getInitials = (name: string | undefined | null) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  const formatDate = (date: string | Date | undefined) => {
    if (!date) return "N/A";
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "admin":
        return "bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100";
      case "moderator":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100";
      case "developer":
        return "bg-purple-100 text-purple-800 dark:bg-purple-800 dark:text-purple-100";
      case "customer":
      default:
        return "bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100";
    }
  };
  
  // Calculate percentage of investment progress
  const calculateProgressPercentage = (investment: Investment): number => {
    if (!investment.workingDays || investment.workingDays === 0) return 0;
    const percentage = (investment.daysCompleted || 0) / investment.workingDays * 100;
    return Math.min(Math.max(percentage, 0), 100); // Ensure between 0-100
  };
  
  // Calculate total payout (principal × daily return × working days)
  const calculateTotalPayout = (investment: Investment): number => {
    if (!investment.amount || !investment.dailyReturn || !investment.workingDays) return 0;
    // Convert string values to numbers if needed
    const principal = typeof investment.amount === 'string' ? parseFloat(investment.amount) : investment.amount;
    const dailyReturn = typeof investment.dailyReturn === 'string' ? parseFloat(investment.dailyReturn) : investment.dailyReturn;
    const workingDays = investment.workingDays;
    return principal * (dailyReturn / 100) * workingDays;
  };
  
  // Calculate payout already made to the user
  const calculatePayoutMade = (investment: Investment): number => {
    if (!investment.amount || !investment.dailyReturn || !investment.daysCompleted) return 0;
    // Convert string values to numbers if needed
    const principal = typeof investment.amount === 'string' ? parseFloat(investment.amount) : investment.amount;
    const dailyReturn = typeof investment.dailyReturn === 'string' ? parseFloat(investment.dailyReturn) : investment.dailyReturn;
    const daysCompleted = investment.daysCompleted;
    return principal * (dailyReturn / 100) * daysCompleted;
  };
  
  // Calculate remaining payout (total - paid)
  const calculateRemainingPayout = (investment: Investment): number => {
    const totalPayout = calculateTotalPayout(investment);
    const payoutMade = calculatePayoutMade(investment);
    return totalPayout - payoutMade;
  };
  
  // Get investment referrals by investment ID
  const getInvestmentReferrals = (investmentId: number): Referral[] => {
    return referrals?.filter(ref => ref.investmentId === investmentId) || [];
  };
  
  // Check if a referral level is unlocked for an investment
  const isReferralLevelUnlocked = (investmentId: number, level: string): boolean => {
    return referrals?.some(ref => ref.investmentId === investmentId && ref.level === level) || false;
  };

  return (
    <DashboardLayout title="Users Management">
      <div className="flex justify-between items-center mb-6">
        {(isAdmin || isModerator) && (
          <Button
            onClick={() => setIsAdminRegisterOpen(true)}
            className="flex items-center"
          >
            <UserPlus className="mr-2 h-4 w-4" />
            <span>Add User</span>
          </Button>
        )}
      </div>
      
      <div className="mt-6">
        <div className="flex flex-col">
          <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
            <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
              <div className="shadow overflow-hidden border-b border-gray-200 dark:border-gray-700 sm:rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Joined</TableHead>
                      <TableHead className="relative">
                        <span className="sr-only">Actions</span>
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      Array(3)
                        .fill(0)
                        .map((_, index) => (
                          <TableRow key={index}>
                            <TableCell>
                              <div className="flex items-center">
                                <Skeleton className="h-10 w-10 rounded-full" />
                                <div className="ml-4">
                                  <Skeleton className="h-4 w-24" />
                                  <Skeleton className="h-3 w-32 mt-1" />
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Skeleton className="h-4 w-16" />
                            </TableCell>
                            <TableCell>
                              <Skeleton className="h-5 w-16 rounded-full" />
                            </TableCell>
                            <TableCell>
                              <Skeleton className="h-4 w-24" />
                            </TableCell>
                            <TableCell className="text-right">
                              <Skeleton className="h-4 w-8 ml-auto" />
                            </TableCell>
                          </TableRow>
                        ))
                    ) : users?.length ? (
                      users.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell>
                            <div className="flex items-center">
                              <Avatar className="h-10 w-10">
                                <AvatarImage
                                  src={`https://i.pravatar.cc/150?u=${user.id}`}
                                  alt={user.fullName || user.username}
                                />
                                <AvatarFallback>
                                  {getInitials(user.fullName || user.username)}
                                </AvatarFallback>
                              </Avatar>
                              <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900 dark:text-white">
                                  {user.fullName || user.username}
                                </div>
                                <div className="text-sm text-gray-500 dark:text-gray-400">
                                  {user.email || "No email provided"}
                                </div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm text-gray-900 dark:text-white">
                              {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={
                                user.isActive
                                  ? "bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100"
                                  : "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-100"
                              }
                            >
                              {user.isActive ? "Active" : "Inactive"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm text-gray-500 dark:text-gray-400">
                            {formatDate(user.createdAt)}
                          </TableCell>
                          <TableCell className="text-right text-sm font-medium">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  variant="ghost"
                                  className="h-8 w-8 p-0"
                                >
                                  <span className="sr-only">Open menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem
                                  className="flex items-center cursor-pointer"
                                >
                                  <Pencil className="mr-2 h-4 w-4" />
                                  <span>Edit</span>
                                </DropdownMenuItem>

                                {(isAdmin || isModerator) && (
                                  <>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem
                                      className="flex items-center cursor-pointer"
                                      onClick={() => {
                                        setSelectedUser(user);
                                        setIsKycViewOpen(true);
                                      }}
                                    >
                                      <FileCheck className="mr-2 h-4 w-4" />
                                      <span>KYC Status</span>
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      className="flex items-center cursor-pointer"
                                      onClick={() => {
                                        setSelectedUser(user);
                                        setIsAadharUploadOpen(true);
                                      }}
                                    >
                                      <Upload className="mr-2 h-4 w-4" />
                                      <span>Upload Aadhar</span>
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      className="flex items-center cursor-pointer"
                                      onClick={() => {
                                        setSelectedUser(user);
                                        setIsPanUploadOpen(true);
                                      }}
                                    >
                                      <Upload className="mr-2 h-4 w-4" />
                                      <span>Upload PAN</span>
                                    </DropdownMenuItem>
                                    <DropdownMenuItem
                                      className="flex items-center cursor-pointer"
                                      onClick={() => {
                                        setSelectedUser(user);
                                        setIsUserDetailsOpen(true);
                                      }}
                                    >
                                      <CreditCard className="mr-2 h-4 w-4" />
                                      <span>View Investments</span>
                                    </DropdownMenuItem>
                                  </>
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8">
                          <div className="text-gray-500 dark:text-gray-400">
                            No users found
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* KYC Status Dialog */}
      <Dialog open={isKycViewOpen} onOpenChange={setIsKycViewOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>KYC Status</DialogTitle>
            <DialogDescription>
              View and verify KYC documents for {selectedUser?.fullName || selectedUser?.username}
            </DialogDescription>
          </DialogHeader>
          
          {kycStatus ? (
            <div className="space-y-6 py-4">
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Aadhar Card</h3>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    {kycStatus?.aadharStatus?.uploaded ? (
                      <Badge variant="outline" className="bg-green-100 text-green-800 mr-2">
                        Uploaded
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-yellow-100 text-yellow-800 mr-2">
                        Not Uploaded
                      </Badge>
                    )}
                    
                    {kycStatus?.aadharStatus?.verified ? (
                      <Badge variant="outline" className="bg-green-100 text-green-800">
                        Verified
                      </Badge>
                    ) : kycStatus?.aadharStatus?.uploaded ? (
                      <Badge variant="outline" className="bg-yellow-100 text-yellow-800">
                        Not Verified
                      </Badge>
                    ) : null}
                  </div>
                  
                  {kycStatus?.aadharStatus?.uploaded && !kycStatus?.aadharStatus?.verified && (
                    <Button 
                      size="sm" 
                      onClick={() => verifyAadharMutation.mutate()}
                      disabled={verifyAadharMutation.isPending}
                    >
                      {verifyAadharMutation.isPending ? (
                        "Verifying..."
                      ) : (
                        <>
                          <Check className="h-4 w-4 mr-1" />
                          Verify
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-lg font-medium">PAN Card</h3>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    {kycStatus?.panStatus?.uploaded ? (
                      <Badge variant="outline" className="bg-green-100 text-green-800 mr-2">
                        Uploaded
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-yellow-100 text-yellow-800 mr-2">
                        Not Uploaded
                      </Badge>
                    )}
                    
                    {kycStatus?.panStatus?.verified ? (
                      <Badge variant="outline" className="bg-green-100 text-green-800">
                        Verified
                      </Badge>
                    ) : kycStatus?.panStatus?.uploaded ? (
                      <Badge variant="outline" className="bg-yellow-100 text-yellow-800">
                        Not Verified
                      </Badge>
                    ) : null}
                  </div>
                  
                  {kycStatus?.panStatus?.uploaded && !kycStatus?.panStatus?.verified && (
                    <Button 
                      size="sm" 
                      onClick={() => verifyPanMutation.mutate()}
                      disabled={verifyPanMutation.isPending}
                    >
                      {verifyPanMutation.isPending ? (
                        "Verifying..."
                      ) : (
                        <>
                          <Check className="h-4 w-4 mr-1" />
                          Verify
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="py-6 flex justify-center">
              <Skeleton className="h-24 w-full" />
            </div>
          )}
          
          <DialogFooter className="sm:justify-start">
            <Button type="button" variant="secondary" onClick={() => setIsKycViewOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Aadhar Upload Dialog */}
      <Dialog open={isAadharUploadOpen} onOpenChange={setIsAadharUploadOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Upload Aadhar Card</DialogTitle>
            <DialogDescription>
              Upload Aadhar card for {selectedUser?.fullName || selectedUser?.username}
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <DocumentUpload
              documentType="aadhar"
              title="Aadhar Card"
              description="Please upload a clear copy of the Aadhar card. Make sure all details are clearly visible."
              onUpload={(file) => {
                setAadharFile(file);
                handleUploadAadhar();
              }}
              isUploading={uploadAadharMutation.isPending}
              accept=".jpg,.jpeg,.png,.pdf"
              maxSize={5}
              existingDocumentUrl={selectedUser?.aadharVerified ? `/uploads/${selectedUser.id}/aadhar/aadhar.jpg` : null}
              isVerified={selectedUser?.aadharVerified}
            />
          </div>
        </DialogContent>
      </Dialog>

      {/* PAN Upload Dialog */}
      <Dialog open={isPanUploadOpen} onOpenChange={setIsPanUploadOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Upload PAN Card</DialogTitle>
            <DialogDescription>
              Upload PAN card for {selectedUser?.fullName || selectedUser?.username}
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <DocumentUpload
              documentType="pan"
              title="PAN Card"
              description="Please upload a clear copy of the PAN card. Make sure all details are clearly visible."
              onUpload={(file) => {
                setPanFile(file);
                handleUploadPan();
              }}
              isUploading={uploadPanMutation.isPending}
              accept=".jpg,.jpeg,.png,.pdf"
              maxSize={5}
              existingDocumentUrl={selectedUser?.panUrl}
              isVerified={selectedUser?.isPanVerified}
            />
          </div>
        </DialogContent>
      </Dialog>

      {/* Admin Register User Dialog */}
      <Dialog open={isAdminRegisterOpen} onOpenChange={setIsAdminRegisterOpen}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Register New User with Investment</DialogTitle>
            <DialogDescription>
              Create a new user account and set up their initial investment with transaction details.
            </DialogDescription>
          </DialogHeader>
          
          <AdminRegisterForm 
            branches={branches || []} 
            onSubmit={adminRegisterMutation.mutate} 
            isSubmitting={adminRegisterMutation.isPending} 
          />
        </DialogContent>
      </Dialog>

      {/* User Investments Dialog */}
      <Dialog open={isUserDetailsOpen} onOpenChange={setIsUserDetailsOpen}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>User Investments</DialogTitle>
            <DialogDescription>
              View investments and details for {selectedUser?.fullName || selectedUser?.username}
            </DialogDescription>
          </DialogHeader>
          
          {isLoadingInvestments ? (
            <div className="py-8 space-y-4">
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-24 w-full" />
            </div>
          ) : userInvestments?.length ? (
            <div className="space-y-6 py-4">
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Investments</h3>
                <div className="space-y-4">
                  {userInvestments.map((investment) => (
                    <Card key={investment.id} className="overflow-hidden">
                      <CardHeader className="bg-muted py-3">
                        <div className="flex justify-between items-center">
                          <div>
                            <CardTitle className="text-lg">
                              {investment.type} - ₹{typeof investment.amount === 'string' 
                                ? parseInt(investment.amount).toLocaleString('en-IN') 
                                : investment.amount.toLocaleString('en-IN')}
                            </CardTitle>
                            <CardDescription>
                              Started on {formatDate(investment.startDate)}
                            </CardDescription>
                          </div>
                          <Badge variant="outline" className={
                            investment.status === 'active' 
                              ? "bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100"
                              : "bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100"
                          }>
                            {investment.status.charAt(0).toUpperCase() + investment.status.slice(1)}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="p-4 space-y-4">
                        <div>
                          <div className="mb-2 flex justify-between">
                            <span className="text-sm font-medium">Progress</span>
                            <span className="text-sm text-muted-foreground">
                              {investment.daysCompleted || 0}/{investment.workingDays || 0} days ({Math.round(calculateProgressPercentage(investment))}%)
                            </span>
                          </div>
                          <Progress value={calculateProgressPercentage(investment)} className="h-2" />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 mt-4">
                          <div>
                            <div className="text-sm font-medium mb-1">Details</div>
                            <dl className="space-y-2 text-sm">
                              <div className="flex justify-between">
                                <dt className="text-muted-foreground">Daily Return</dt>
                                <dd>{investment.dailyReturn}%</dd>
                              </div>
                              <div className="flex justify-between">
                                <dt className="text-muted-foreground">Working Days</dt>
                                <dd>{investment.workingDays}</dd>
                              </div>
                              <div className="flex justify-between">
                                <dt className="text-muted-foreground">Days Completed</dt>
                                <dd>{investment.daysCompleted || 0}</dd>
                              </div>
                            </dl>
                          </div>
                          
                          <div>
                            <div className="text-sm font-medium mb-1">Payout Information</div>
                            <dl className="space-y-2 text-sm">
                              <div className="flex justify-between">
                                <dt className="text-muted-foreground">Total Payout</dt>
                                <dd>₹{Math.round(calculateTotalPayout(investment)).toLocaleString('en-IN')}</dd>
                              </div>
                              <div className="flex justify-between">
                                <dt className="text-muted-foreground">Payout Made</dt>
                                <dd>₹{Math.round(calculatePayoutMade(investment)).toLocaleString('en-IN')}</dd>
                              </div>
                              <div className="flex justify-between">
                                <dt className="text-muted-foreground">Remaining</dt>
                                <dd>₹{Math.round(calculateRemainingPayout(investment)).toLocaleString('en-IN')}</dd>
                              </div>
                            </dl>
                          </div>
                        </div>

                        {/* Referral Information */}
                        <div className="mt-4">
                          <div className="text-sm font-medium mb-2">MLM Referral Status</div>
                          <div className="grid grid-cols-5 gap-2">
                            <div className={`text-center p-2 rounded-lg ${isReferralLevelUnlocked(investment.id, ReferralLevel.LEVEL1) ? 'bg-green-100 dark:bg-green-800' : 'bg-gray-100 dark:bg-gray-800'}`}>
                              <div className="text-xs font-semibold">Level 1</div>
                              <div className="text-sm">{isReferralLevelUnlocked(investment.id, ReferralLevel.LEVEL1) ? '10%' : 'Locked'}</div>
                            </div>
                            <div className={`text-center p-2 rounded-lg ${isReferralLevelUnlocked(investment.id, ReferralLevel.LEVEL2) ? 'bg-green-100 dark:bg-green-800' : 'bg-gray-100 dark:bg-gray-800'}`}>
                              <div className="text-xs font-semibold">Level 2</div>
                              <div className="text-sm">{isReferralLevelUnlocked(investment.id, ReferralLevel.LEVEL2) ? '7%' : 'Locked'}</div>
                            </div>
                            <div className={`text-center p-2 rounded-lg ${isReferralLevelUnlocked(investment.id, ReferralLevel.LEVEL3) ? 'bg-green-100 dark:bg-green-800' : 'bg-gray-100 dark:bg-gray-800'}`}>
                              <div className="text-xs font-semibold">Level 3</div>
                              <div className="text-sm">{isReferralLevelUnlocked(investment.id, ReferralLevel.LEVEL3) ? '5%' : 'Locked'}</div>
                            </div>
                            <div className={`text-center p-2 rounded-lg ${isReferralLevelUnlocked(investment.id, ReferralLevel.LEVEL4) ? 'bg-green-100 dark:bg-green-800' : 'bg-gray-100 dark:bg-gray-800'}`}>
                              <div className="text-xs font-semibold">Level 4</div>
                              <div className="text-sm">{isReferralLevelUnlocked(investment.id, ReferralLevel.LEVEL4) ? '4%' : 'Locked'}</div>
                            </div>
                            <div className={`text-center p-2 rounded-lg ${isReferralLevelUnlocked(investment.id, ReferralLevel.LEVEL5) ? 'bg-green-100 dark:bg-green-800' : 'bg-gray-100 dark:bg-gray-800'}`}>
                              <div className="text-xs font-semibold">Level 5</div>
                              <div className="text-sm">{isReferralLevelUnlocked(investment.id, ReferralLevel.LEVEL5) ? '3%' : 'Locked'}</div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="py-8 text-center">
              <p className="text-muted-foreground">No investments found for this user</p>
            </div>
          )}
          
          <DialogFooter className="sm:justify-start">
            <Button type="button" variant="secondary" onClick={() => setIsUserDetailsOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}

interface AdminRegisterFormProps {
  branches: Branch[];
  onSubmit: (data: AdminRegisterValues) => void;
  isSubmitting: boolean;
}

function AdminRegisterForm({ branches, onSubmit, isSubmitting }: AdminRegisterFormProps) {
  const [tab, setTab] = useState<string>("user");
  const [includeInvestment, setIncludeInvestment] = useState(true);
  const [selectedInvestmentType, setSelectedInvestmentType] = useState<string | undefined>(undefined);
  const [investmentAmount, setInvestmentAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<string>("online");

  const formattedInvestmentAmount = parseInt(investmentAmount.replace(/[^0-9]/g, ""), 10) || 0;

  // Calculate daily return and working days based on the RPP GOLD tier
  const getDailyReturnRate = () => {
    // Automatically adjust based on investment amount
    if (selectedInvestmentType === InvestmentType.RPP_GOLD_TIER3 || formattedInvestmentAmount >= 600000) {
      return "1.5"; // For tier 3 (6,00,000+)
    } else if (selectedInvestmentType === InvestmentType.RPP_GOLD_TIER2 || formattedInvestmentAmount >= 300000) {
      return "1.0"; // For tier 2 (3,00,000 - 5,00,000)
    } else {
      return "0.75"; // For tier 1 (24,999 - 1,50,000)
    }
  };

  const getWorkingDays = () => {
    // Automatically adjust based on investment amount
    if (selectedInvestmentType === InvestmentType.RPP_GOLD_TIER3 || formattedInvestmentAmount >= 600000) {
      return 132; // For tier 3 (6,00,000+)
    } else if (selectedInvestmentType === InvestmentType.RPP_GOLD_TIER2 || formattedInvestmentAmount >= 300000) {
      return 200; // For tier 2 (3,00,000 - 5,00,000)
    } else {
      return 267; // For tier 1 (24,999 - 1,50,000)
    }
  };

  const form = useForm<AdminRegisterValues>({
    resolver: zodResolver(adminRegisterSchema),
    defaultValues: {
      user: {
        username: "",
        password: "",
        fullName: "",
        email: null,
        role: UserRole.CUSTOMER,
        branch: null,
        phoneNumber: null,
        dateOfBirth: null,
        address: null,
        city: null,
        state: null,
        pincode: null,
        aadharNumber: null,
        panNumber: null,
        bankName: null,
        accountNumber: null,
        ifscCode: null,
      },
      investment: includeInvestment
        ? {
            branchId: "",
            type: InvestmentType.RPP_GOLD_TIER1,
            amount: "",
            startDate: new Date(),
            transactionDetails: {
              paymentMethod: "online",
              transactionId: "",
              receiptNumber: "",
              date: new Date(),
              notes: "",
            },
          }
        : undefined,
    },
  });

  useEffect(() => {
    if (includeInvestment) {
      form.setValue("investment", {
        branchId: "",
        type: InvestmentType.RPP_GOLD_TIER1,
        amount: "",
        startDate: new Date(),
        transactionDetails: {
          paymentMethod: "online",
          transactionId: "",
          receiptNumber: "",
          date: new Date(),
          notes: "",
        },
      });
      // Set the initial investment type for the state as well
      setSelectedInvestmentType(InvestmentType.RPP_GOLD_TIER1);
    } else {
      form.setValue("investment", undefined);
    }
  }, [includeInvestment, form]);

  useEffect(() => {
    if (selectedInvestmentType) {
      form.setValue("investment.type", selectedInvestmentType);
    }
  }, [selectedInvestmentType, form]);

  useEffect(() => {
    form.setValue("investment.amount", investmentAmount);
  }, [investmentAmount, form]);

  useEffect(() => {
    if (paymentMethod) {
      form.setValue("investment.transactionDetails.paymentMethod", paymentMethod);
    }
  }, [paymentMethod, form]);

  const onSubmitForm = (data: AdminRegisterValues) => {
    onSubmit(data);
  };

  const formatCurrency = (value: string) => {
    // Remove non-numeric characters
    const numericValue = value.replace(/[^0-9]/g, "");
    
    // Convert to number and format as currency
    const amount = parseInt(numericValue, 10) || 0;
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const handleInvestmentAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9]/g, "");
    const formattedValue = value ? formatCurrency(value) : "";
    setInvestmentAmount(formattedValue);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmitForm)} className="space-y-6">
        <Tabs defaultValue="user" value={tab} onValueChange={setTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="user">User Information</TabsTrigger>
            <TabsTrigger value="investment" disabled={!includeInvestment}>
              Investment Details
            </TabsTrigger>
          </TabsList>

          {/* User Information Form */}
          <TabsContent value="user" className="space-y-6 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="user.username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username*</FormLabel>
                    <FormControl>
                      <Input placeholder="username" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="user.password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password*</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="••••••••" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="user.fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name*</FormLabel>
                    <FormControl>
                      <Input placeholder="John Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="user.email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input 
                        type="email" 
                        placeholder="john.doe@example.com" 
                        {...field} 
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value || null)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="user.phoneNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="9876543210" 
                        {...field} 
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value || null)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="user.dateOfBirth"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Date of Birth</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value || undefined}
                          onSelect={(date) => field.onChange(date || null)}
                          disabled={(date) =>
                            date > new Date() || date < new Date("1900-01-01")
                          }
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="user.branch"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Branch</FormLabel>
                    <Select 
                      onValueChange={(value) => field.onChange(value || null)}
                      value={field.value || ""}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select branch" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {branches.map((branch) => (
                          <SelectItem key={branch.id} value={branch.name}>
                            {branch.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="user.aadharNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Aadhar Number</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="1234 5678 9012" 
                        {...field} 
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value || null)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="user.panNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>PAN Number</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="ABCDE1234F" 
                        {...field} 
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value || null)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="user.address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Address</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Street address" 
                        {...field} 
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value || null)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="user.city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>City</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="City" 
                          {...field} 
                          value={field.value || ""}
                          onChange={(e) => field.onChange(e.target.value || null)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="user.state"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>State</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="State" 
                          {...field} 
                          value={field.value || ""}
                          onChange={(e) => field.onChange(e.target.value || null)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <FormField
              control={form.control}
              name="user.pincode"
              render={({ field }) => (
                <FormItem className="max-w-[200px]">
                  <FormLabel>Pincode</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="123456" 
                      {...field} 
                      value={field.value || ""}
                      onChange={(e) => field.onChange(e.target.value || null)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-4">
              <h3 className="text-lg font-medium">Bank Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="user.bankName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bank Name</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Bank name" 
                          {...field} 
                          value={field.value || ""}
                          onChange={(e) => field.onChange(e.target.value || null)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="user.accountNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Account Number</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Account number" 
                          {...field} 
                          value={field.value || ""}
                          onChange={(e) => field.onChange(e.target.value || null)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="user.ifscCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>IFSC Code</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="IFSC code" 
                          {...field} 
                          value={field.value || ""}
                          onChange={(e) => field.onChange(e.target.value || null)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <div className="flex items-center space-x-2 pt-4">
              <Checkbox
                id="include-investment"
                checked={includeInvestment}
                onCheckedChange={(checked) => setIncludeInvestment(!!checked)}
              />
              <Label
                htmlFor="include-investment"
                className="text-sm font-medium leading-none cursor-pointer"
              >
                Include investment with user registration
              </Label>
            </div>

            {includeInvestment && (
              <Button type="button" onClick={() => setTab("investment")}>
                Continue to Investment Details
              </Button>
            )}
          </TabsContent>

          {/* Investment Details Form */}
          <TabsContent value="investment" className="space-y-6 py-4">
            {includeInvestment && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="investment.branchId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Branch*</FormLabel>
                        <Select 
                          onValueChange={field.onChange}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select branch" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {branches.map((branch) => (
                              <SelectItem key={branch.id} value={String(branch.id)}>
                                {branch.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="investment.type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Investment Type*</FormLabel>
                        <Select 
                          onValueChange={(value) => {
                            field.onChange(value);
                            setSelectedInvestmentType(value);
                          }}
                          value={field.value}
                          defaultValue={InvestmentType.RPP_GOLD_TIER1}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value={InvestmentType.RPP_GOLD_TIER1}>
                              RPP GOLD Tier 1 (₹24,999-₹1,50,000)
                            </SelectItem>
                            <SelectItem value={InvestmentType.RPP_GOLD_TIER2}>
                              RPP GOLD Tier 2 (₹3,00,000-₹5,00,000)
                            </SelectItem>
                            <SelectItem value={InvestmentType.RPP_GOLD_TIER3}>
                              RPP GOLD Tier 3 (₹6,00,000+)
                            </SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="investment.amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Investment Amount*</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="₹ 50,000"
                            value={investmentAmount}
                            onChange={handleInvestmentAmountChange}
                          />
                        </FormControl>
                        <FormDescription>
                          RPP GOLD Tier: {formattedInvestmentAmount >= 600000 ? "Tier 3" : formattedInvestmentAmount >= 300000 ? "Tier 2" : "Tier 1"}
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="investment.startDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Start Date*</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "w-full pl-3 text-left font-normal",
                                  !field.value && "text-muted-foreground"
                                )}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-4 bg-muted/50 p-4 rounded-md">
                  <div>
                    <Label>Daily Return</Label>
                    <div className="text-xl font-bold mt-1">{getDailyReturnRate()}%</div>
                  </div>
                  <div>
                    <Label>Working Days</Label>
                    <div className="text-xl font-bold mt-1">{getWorkingDays()}</div>
                  </div>
                  <div>
                    <Label>Total Returns</Label>
                    <div className="text-xl font-bold mt-1">
                      {new Intl.NumberFormat("en-IN", {
                        style: "currency",
                        currency: "INR",
                        maximumFractionDigits: 0,
                      }).format(
                        formattedInvestmentAmount * 
                        (parseFloat(getDailyReturnRate()) / 100) * 
                        getWorkingDays()
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Transaction Details</h3>
                  
                  <FormField
                    name="investment.transactionDetails.paymentMethod"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel>Payment Method*</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={(value) => {
                              field.onChange(value);
                              setPaymentMethod(value);
                            }}
                            defaultValue="online"
                            className="flex flex-col space-y-1"
                          >
                            <div className="flex items-center space-x-3 space-y-0">
                              <RadioGroupItem value="online" id="online" />
                              <Label htmlFor="online">Online Transfer</Label>
                            </div>
                            <div className="flex items-center space-x-3 space-y-0">
                              <RadioGroupItem value="cash" id="cash" />
                              <Label htmlFor="cash">Cash</Label>
                            </div>
                            <div className="flex items-center space-x-3 space-y-0">
                              <RadioGroupItem value="cheque" id="cheque" />
                              <Label htmlFor="cheque">Cheque</Label>
                            </div>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {paymentMethod === "online" && (
                    <FormField
                      control={form.control}
                      name="investment.transactionDetails.transactionId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Transaction ID*</FormLabel>
                          <FormControl>
                            <Input placeholder="UTR Number / Transaction ID" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}

                  {paymentMethod === "cash" && (
                    <FormField
                      control={form.control}
                      name="investment.transactionDetails.receiptNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Receipt Number*</FormLabel>
                          <FormControl>
                            <Input placeholder="Receipt Number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}

                  {paymentMethod === "cheque" && (
                    <FormField
                      control={form.control}
                      name="investment.transactionDetails.receiptNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Cheque Number*</FormLabel>
                          <FormControl>
                            <Input placeholder="Cheque Number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}

                  <FormField
                    control={form.control}
                    name="investment.transactionDetails.date"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Transaction Date*</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "w-full pl-3 text-left font-normal",
                                  !field.value && "text-muted-foreground"
                                )}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="investment.transactionDetails.notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Additional Notes</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Any additional information about the transaction"
                            className="resize-none"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Button type="button" variant="outline" onClick={() => setTab("user")}>
                  Back to User Information
                </Button>
              </>
            )}
          </TabsContent>
        </Tabs>

        <div className="flex justify-end">
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Registering User..." : "Register User"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
