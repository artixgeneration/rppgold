import React, { useState } from 'react';
import DashboardLayout from '@/components/layout/dashboard-layout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Bell,
  CheckCircle,
  Clock,
  Info,
  AlertTriangle,
  ThumbsUp,
  RefreshCw,
  X,
  Settings,
} from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { useAuth } from '@/hooks/use-auth';

// Notification type definition
type NotificationType = 'info' | 'success' | 'warning' | 'payment' | 'system';

interface Notification {
  id: number;
  type: NotificationType;
  title: string;
  message: string;
  date: Date;
  isRead: boolean;
  actionUrl?: string;
  actionText?: string;
}

export default function NotificationsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('all');
  
  // Sample notifications data
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: 1,
      type: 'success',
      title: 'KYC Verified',
      message: 'Your KYC documents have been successfully verified.',
      date: new Date('2023-09-18T10:30:00'),
      isRead: false,
    },
    {
      id: 2,
      type: 'payment',
      title: 'Payment Received',
      message: 'You have received a payout of ₹12,500 for your investment #INV78901.',
      date: new Date('2023-09-17T14:45:00'),
      isRead: true,
      actionUrl: '/investments/details/78901',
      actionText: 'View Details',
    },
    {
      id: 3,
      type: 'info',
      title: 'New Feature Available',
      message: 'We have added a new chat feature to help you connect with our team easily.',
      date: new Date('2023-09-16T09:15:00'),
      isRead: false,
      actionUrl: '/chat',
      actionText: 'Try Now',
    },
    {
      id: 4,
      type: 'warning',
      title: 'Action Required',
      message: 'Please update your contact information to ensure you receive important updates.',
      date: new Date('2023-09-15T16:20:00'),
      isRead: false,
      actionUrl: '/profile',
      actionText: 'Update Profile',
    },
    {
      id: 5,
      type: 'system',
      title: 'System Maintenance',
      message: 'The system will undergo maintenance on September 20th from 2:00 AM to 4:00 AM IST.',
      date: new Date('2023-09-14T11:10:00'),
      isRead: true,
    },
    {
      id: 6,
      type: 'payment',
      title: 'Investment Matured',
      message: 'Your investment #INV78456 has matured. The final payment has been processed.',
      date: new Date('2023-09-13T08:30:00'),
      isRead: true,
      actionUrl: '/investments/details/78456',
      actionText: 'View Details',
    },
    {
      id: 7,
      type: 'success',
      title: 'Referral Bonus',
      message: 'You have earned a referral bonus of ₹5,000 for referring a new customer.',
      date: new Date('2023-09-12T13:40:00'),
      isRead: false,
    },
    {
      id: 8,
      type: 'info',
      title: 'Investment Tip',
      message: 'Consider diversifying your investments across different tiers for optimal returns.',
      date: new Date('2023-09-11T10:00:00'),
      isRead: true,
    },
  ]);
  
  // Filter notifications based on active tab
  const filteredNotifications = notifications.filter(notification => {
    if (activeTab === 'all') return true;
    if (activeTab === 'unread') return !notification.isRead;
    return notification.type === activeTab;
  });
  
  // Mark a notification as read
  const markAsRead = (id: number) => {
    setNotifications(notifications.map(notification => 
      notification.id === id ? { ...notification, isRead: true } : notification
    ));
  };
  
  // Mark all notifications as read
  const markAllAsRead = () => {
    setNotifications(notifications.map(notification => ({ ...notification, isRead: true })));
    toast({
      title: 'All notifications marked as read',
      description: 'You have cleared all your unread notifications.',
    });
  };
  
  // Delete a notification
  const deleteNotification = (id: number) => {
    setNotifications(notifications.filter(notification => notification.id !== id));
    toast({
      title: 'Notification deleted',
      description: 'The notification has been removed from your list.',
    });
  };
  
  // Get notification icon based on type
  const getNotificationIcon = (type: NotificationType) => {
    switch (type) {
      case 'info':
        return <Info className="h-5 w-5 text-blue-500" />;
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-amber-500" />;
      case 'payment':
        return <ThumbsUp className="h-5 w-5 text-purple-500" />;
      case 'system':
        return <Settings className="h-5 w-5 text-gray-500" />;
      default:
        return <Bell className="h-5 w-5 text-gray-500" />;
    }
  };
  
  // Get the count of unread notifications
  const unreadCount = notifications.filter(n => !n.isRead).length;
  
  return (
    <DashboardLayout title="Notifications">
      <div className="container mx-auto py-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Notifications</h1>
            <p className="text-muted-foreground">
              Stay updated with important alerts and information about your investments.
            </p>
          </div>
          
          <div className="flex items-center space-x-2">
            {unreadCount > 0 && (
              <Button variant="outline" onClick={markAllAsRead}>
                <CheckCircle className="h-4 w-4 mr-2" />
                Mark all as read
              </Button>
            )}
            <Button variant="outline">
              <Settings className="h-4 w-4 mr-2" />
              Notification Settings
            </Button>
          </div>
        </div>
        
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle>Your Notifications</CardTitle>
              <Badge variant="outline" className="font-normal">
                {unreadCount} unread
              </Badge>
            </div>
            <CardDescription>
              Recent updates, alerts, and information about your RPP GOLD account.
            </CardDescription>
          </CardHeader>
          
          <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
            <div className="px-6">
              <TabsList className="grid grid-cols-6 mb-6">
                <TabsTrigger value="all" className="flex items-center gap-2">
                  <Bell className="h-4 w-4" />
                  <span className="hidden sm:inline">All</span>
                </TabsTrigger>
                <TabsTrigger value="unread" className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  <span className="hidden sm:inline">Unread</span>
                </TabsTrigger>
                <TabsTrigger value="payment" className="flex items-center gap-2">
                  <ThumbsUp className="h-4 w-4" />
                  <span className="hidden sm:inline">Payments</span>
                </TabsTrigger>
                <TabsTrigger value="success" className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4" />
                  <span className="hidden sm:inline">Success</span>
                </TabsTrigger>
                <TabsTrigger value="warning" className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4" />
                  <span className="hidden sm:inline">Alerts</span>
                </TabsTrigger>
                <TabsTrigger value="info" className="flex items-center gap-2">
                  <Info className="h-4 w-4" />
                  <span className="hidden sm:inline">Info</span>
                </TabsTrigger>
              </TabsList>
            </div>
            
            <CardContent className="p-0">
              <ScrollArea className="h-[calc(100vh-24rem)] w-full">
                <div className="px-6">
                  {filteredNotifications.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-12">
                      <Bell className="h-12 w-12 text-gray-300 mb-4" />
                      <h3 className="text-lg font-medium text-gray-500">No notifications</h3>
                      <p className="text-sm text-gray-400 text-center mt-1">
                        You don't have any {activeTab !== 'all' ? activeTab : ''} notifications at the moment.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-1">
                      {filteredNotifications.map((notification, index) => (
                        <React.Fragment key={notification.id}>
                          {index > 0 && <Separator className="my-2" />}
                          <div 
                            className={cn(
                              "flex items-start p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors",
                              !notification.isRead && "bg-blue-50 dark:bg-blue-900/20"
                            )}
                          >
                            <div className="flex-shrink-0 mr-3 mt-1">
                              {getNotificationIcon(notification.type)}
                            </div>
                            
                            <div className="flex-1 min-w-0">
                              <div className="flex justify-between">
                                <p className={cn(
                                  "text-sm font-medium",
                                  !notification.isRead ? "text-gray-900 dark:text-white" : "text-gray-700 dark:text-gray-300"
                                )}>
                                  {notification.title}
                                </p>
                                <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap ml-2">
                                  {new Date(notification.date).toLocaleDateString('en-IN', { 
                                    month: 'short', 
                                    day: 'numeric',
                                    hour: '2-digit',
                                    minute: '2-digit'
                                  })}
                                </span>
                              </div>
                              
                              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                                {notification.message}
                              </p>
                              
                              {(notification.actionUrl && notification.actionText) && (
                                <div className="mt-2">
                                  <Button variant="link" className="h-6 p-0 text-sm text-primary" asChild>
                                    <a href={notification.actionUrl}>{notification.actionText}</a>
                                  </Button>
                                </div>
                              )}
                            </div>
                            
                            <div className="flex-shrink-0 ml-3 flex space-x-1">
                              {!notification.isRead && (
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="h-8 w-8" 
                                  onClick={() => markAsRead(notification.id)}
                                >
                                  <CheckCircle className="h-4 w-4 text-green-500" />
                                  <span className="sr-only">Mark as read</span>
                                </Button>
                              )}
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-8 w-8" 
                                onClick={() => deleteNotification(notification.id)}
                              >
                                <X className="h-4 w-4 text-gray-500" />
                                <span className="sr-only">Delete</span>
                              </Button>
                            </div>
                          </div>
                        </React.Fragment>
                      ))}
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Tabs>
          
          <CardFooter className="flex justify-center border-t p-4">
            <Button variant="outline" size="sm" className="text-xs">
              <RefreshCw className="h-3 w-3 mr-2" />
              Refresh Notifications
            </Button>
          </CardFooter>
        </Card>
      </div>
    </DashboardLayout>
  );
}