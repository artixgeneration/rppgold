import { useState } from "react";
import DashboardLayout from "@/components/layout/dashboard-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Switch } from "@/components/ui/switch";
import { useTheme } from "@/context/theme-context";
import { Loader2, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function SettingsPage() {
  const { theme, setTheme } = useTheme();
  const [themePreference, setThemePreference] = useState(theme);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [appNotifications, setAppNotifications] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  const handleSaveSettings = async () => {
    setIsSaving(true);
    
    // Apply theme change
    setTheme(themePreference);
    
    // Simulate API call to save settings
    setTimeout(() => {
      setIsSaving(false);
      toast({
        title: "Settings saved",
        description: "Your preferences have been updated successfully.",
      });
    }, 1000);
  };

  return (
    <DashboardLayout title="Settings">
      <div className="mt-6">
        <Card>
          <CardHeader>
            <CardTitle>App Settings</CardTitle>
            <CardDescription>
              Configure your application settings and preferences.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Theme Preferences
                </h4>
                <RadioGroup
                  value={themePreference}
                  onValueChange={setThemePreference}
                  className="mt-2 space-y-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="system" id="theme-system" />
                    <Label htmlFor="theme-system">System Preference</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="light" id="theme-light" />
                    <Label htmlFor="theme-light">Light Mode</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="dark" id="theme-dark" />
                    <Label htmlFor="theme-dark">Dark Mode</Label>
                  </div>
                </RadioGroup>
              </div>

              <div>
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Notification Settings
                </h4>
                <div className="mt-2 space-y-4">
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <Switch
                        id="notify-email"
                        checked={emailNotifications}
                        onCheckedChange={setEmailNotifications}
                      />
                    </div>
                    <div className="ml-3 text-sm">
                      <Label
                        htmlFor="notify-email"
                        className="font-medium text-gray-700 dark:text-gray-300"
                      >
                        Email notifications
                      </Label>
                      <p className="text-gray-500 dark:text-gray-400">
                        Receive notifications via email for important updates.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <Switch
                        id="notify-app"
                        checked={appNotifications}
                        onCheckedChange={setAppNotifications}
                      />
                    </div>
                    <div className="ml-3 text-sm">
                      <Label
                        htmlFor="notify-app"
                        className="font-medium text-gray-700 dark:text-gray-300"
                      >
                        In-app notifications
                      </Label>
                      <p className="text-gray-500 dark:text-gray-400">
                        Receive notifications within the application.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <Button
                  type="button"
                  onClick={handleSaveSettings}
                  disabled={isSaving}
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Save Settings
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
