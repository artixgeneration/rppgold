import DashboardLayout from "@/components/layout/dashboard-layout";
import StatsCard from "@/components/dashboard/stats-card";
import RecentActivity, { Activity } from "@/components/dashboard/recent-activity";
import { useAuth } from "@/hooks/use-auth";
import { Users, Coins, TrendingUp, MessageSquare } from "lucide-react";
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";

export default function DashboardPage() {
  const { user } = useAuth();
  const [recentActivities, setRecentActivities] = useState<Activity[]>([]);
  
  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Since we are using in-memory data, this will populate some sample activities
  useEffect(() => {
    // This would normally come from the API
    const activities: Activity[] = [
      {
        id: 1,
        user: {
          name: "James Wilson",
          imageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
          initials: "JW"
        },
        description: "Invested ₹25,000 in Gold Plan",
        date: "January 13, 2023",
        time: "2 hours ago",
        badgeText: "New Investment",
        badgeColor: "green"
      },
      {
        id: 2,
        user: {
          name: "Alicia Chen",
          imageUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
          initials: "AC"
        },
        description: "Registered as a new user",
        date: "January 12, 2023",
        time: "1 day ago",
        badgeText: "New User",
        badgeColor: "blue"
      }
    ];
    
    setRecentActivities(activities);
  }, []);

  const defaultStats = {
    users: { count: 2340, change: { value: 12, isPositive: true } },
    investments: { count: "₹15.2M", change: { value: 8.1, isPositive: true } },
    activePlans: { count: 1854, change: { value: 5.4, isPositive: true } },
    chatRequests: { count: 24, change: { value: 3.2, isPositive: false } }
  };

  const dashboardStats = stats || defaultStats;
  
  return (
    <DashboardLayout title="Dashboard">
      {/* Stats cards */}
      <div className="mt-4 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Total Users"
          value={dashboardStats.users.count}
          change={dashboardStats.users.change}
          icon={<Users className="h-8 w-8" />}
        />
        <StatsCard
          title="Total Investments"
          value={dashboardStats.investments.count}
          change={dashboardStats.investments.change}
          icon={<Coins className="h-8 w-8" />}
        />
        <StatsCard
          title="Active Plans"
          value={dashboardStats.activePlans.count}
          change={dashboardStats.activePlans.change}
          icon={<TrendingUp className="h-8 w-8" />}
        />
        <StatsCard
          title="Chat Requests"
          value={dashboardStats.chatRequests.count}
          change={dashboardStats.chatRequests.change}
          icon={<MessageSquare className="h-8 w-8" />}
        />
      </div>
      
      {/* Recent activity */}
      <div className="mt-6">
        <RecentActivity activities={recentActivities} />
      </div>
    </DashboardLayout>
  );
}
