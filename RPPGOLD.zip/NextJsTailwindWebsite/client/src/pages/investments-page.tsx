import React, { useState } from 'react';
import DashboardLayout from '@/components/layout/dashboard-layout';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { insertInvestmentSchema, InvestmentType, ReferralLevel, type Investment, type Branch, type User, type Referral } from '@shared/schema';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { CoinsIcon, Banknote, Calendar, EditIcon, FileCheck, PercentIcon, ClockIcon, BarChartIcon, UsersIcon, PiggyBankIcon, ArrowLeftRight, LockIcon, UnlockIcon } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/use-auth';
import { format } from 'date-fns';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';

// Extended schema with validation
const investmentFormSchema = z.object({
  userId: z.number().or(z.string().transform(val => parseInt(val, 10))),
  branchId: z.number().or(z.string().transform(val => parseInt(val, 10))),
  type: z.string().min(1, 'Investment type is required'),
  amount: z.string().transform(val => parseFloat(val)),
  interestRate: z.string().transform(val => val ? parseFloat(val) : null).nullable().optional(),
  dailyReturn: z.string().transform(val => val ? parseFloat(val) : null).nullable().optional(),
  workingDays: z.string().transform(val => val ? parseInt(val, 10) : null).nullable().optional(),
  daysCompleted: z.number().default(0),
  totalReturns: z.string().transform(val => val ? parseFloat(val) : 0).default('0'),
  startDate: z.date({ required_error: "Start date is required" }),
  maturityDate: z.date().nullable().optional(),
  term: z.string().transform(val => val ? parseInt(val, 10) : null).nullable().optional(),
  status: z.string().default('active'),
  certificateNumber: z.string().nullable().optional(),
  remarks: z.string().nullable().optional(),
});

type InvestmentFormValues = z.infer<typeof investmentFormSchema>;

export default function InvestmentsPage() {
  const { toast } = useToast();
  const { user, isAdmin, isModerator } = useAuth();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedInvestment, setSelectedInvestment] = useState<Investment | null>(null);
  const [activeTab, setActiveTab] = useState<string>("all");
  
  // Query to fetch investments
  const {
    data: investments,
    isLoading: isLoadingInvestments,
    error: investmentsError,
  } = useQuery<Investment[]>({
    queryKey: ['/api/investments'],
    queryFn: async () => {
      const url = isAdmin || isModerator 
        ? '/api/investments' 
        : `/api/investments/user/${user?.id}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error('Failed to fetch investments');
      return res.json();
    },
    enabled: !!user,
  });
  
  // Query to fetch branches for dropdown
  const {
    data: branches,
    isLoading: isLoadingBranches,
  } = useQuery<Branch[]>({
    queryKey: ['/api/branches'],
    queryFn: async () => {
      const res = await fetch('/api/branches');
      if (!res.ok) throw new Error('Failed to fetch branches');
      return res.json();
    },
  });
  
  // Query to fetch users for dropdown (admin/moderator only)
  const {
    data: users,
    isLoading: isLoadingUsers,
  } = useQuery<User[]>({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const res = await fetch('/api/users');
      if (!res.ok) throw new Error('Failed to fetch users');
      return res.json();
    },
    enabled: isAdmin || isModerator,
  });

  // Query to fetch referrals (admin/moderator only)
  const {
    data: referrals,
    isLoading: isLoadingReferrals,
  } = useQuery<Referral[]>({
    queryKey: ['/api/referrals'],
    queryFn: async () => {
      const res = await fetch('/api/referrals');
      if (!res.ok) throw new Error('Failed to fetch referrals');
      return res.json();
    },
    enabled: (isAdmin || isModerator) && !!user,
  });
  
  // Add Investment Form
  const addInvestmentForm = useForm<InvestmentFormValues>({
    resolver: zodResolver(investmentFormSchema),
    defaultValues: {
      userId: user?.id || 0,
      branchId: '',
      type: '',
      amount: '',
      interestRate: '',
      dailyReturn: '',
      workingDays: '',
      daysCompleted: 0,
      totalReturns: '0',
      startDate: new Date(),
      maturityDate: null,
      term: '',
      status: 'active',
      certificateNumber: '',
      remarks: '',
    },
  });
  
  // Watch the type field to automatically set daily return and working days
  const selectedType = addInvestmentForm.watch("type");
  
  React.useEffect(() => {
    if (selectedType) {
      // Set dailyReturn based on investment type
      addInvestmentForm.setValue("dailyReturn", getDailyReturnRate(selectedType).toString());
      
      // Set workingDays based on investment type
      addInvestmentForm.setValue("workingDays", getWorkingDays(selectedType).toString());
    }
  }, [selectedType, addInvestmentForm]);
  
  // Edit Investment Form
  const editInvestmentForm = useForm<InvestmentFormValues>({
    resolver: zodResolver(investmentFormSchema),
    defaultValues: {
      userId: user?.id || 0,
      branchId: '',
      type: '',
      amount: '',
      interestRate: '',
      dailyReturn: '',
      workingDays: '',
      daysCompleted: 0,
      totalReturns: '0',
      startDate: new Date(),
      maturityDate: null,
      term: '',
      status: 'active',
      certificateNumber: '',
      remarks: '',
    },
  });
  
  // Watch the type field to automatically set daily return and working days in edit form
  const selectedEditType = editInvestmentForm.watch("type");
  
  React.useEffect(() => {
    if (selectedEditType) {
      // Set dailyReturn based on investment type
      editInvestmentForm.setValue("dailyReturn", getDailyReturnRate(selectedEditType).toString());
      
      // Set workingDays based on investment type
      editInvestmentForm.setValue("workingDays", getWorkingDays(selectedEditType).toString());
    }
  }, [selectedEditType, editInvestmentForm]);
  
  // Add Investment Mutation
  const addInvestmentMutation = useMutation({
    mutationFn: async (data: InvestmentFormValues) => {
      const response = await apiRequest('POST', '/api/investments', data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/investments'] });
      setIsAddDialogOpen(false);
      addInvestmentForm.reset();
      toast({
        title: 'Investment Added',
        description: 'The investment has been added successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to add investment',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  // Update Investment Mutation
  const updateInvestmentMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: InvestmentFormValues }) => {
      const response = await apiRequest('PATCH', `/api/investments/${id}`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/investments'] });
      setIsEditDialogOpen(false);
      setSelectedInvestment(null);
      toast({
        title: 'Investment Updated',
        description: 'The investment has been updated successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to update investment',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  // Handle Add Investment Form Submission
  function onAddInvestmentSubmit(values: InvestmentFormValues) {
    addInvestmentMutation.mutate(values);
  }
  
  // Handle Edit Investment Form Submission
  function onEditInvestmentSubmit(values: InvestmentFormValues) {
    if (selectedInvestment) {
      updateInvestmentMutation.mutate({ id: selectedInvestment.id, data: values });
    }
  }
  
  // Open Edit Dialog and Set Form Values
  function handleEditInvestment(investment: Investment) {
    setSelectedInvestment(investment);
    
    // Format dates and values for the form
    editInvestmentForm.reset({
      userId: investment.userId,
      branchId: investment.branchId,
      type: investment.type,
      amount: investment.amount.toString(),
      interestRate: investment.interestRate ? investment.interestRate.toString() : '',
      dailyReturn: investment.dailyReturn ? investment.dailyReturn.toString() : getDailyReturnRate(investment.type).toString(),
      workingDays: investment.workingDays ? investment.workingDays.toString() : getWorkingDays(investment.type).toString(),
      daysCompleted: investment.daysCompleted || 0,
      totalReturns: investment.totalReturns ? investment.totalReturns.toString() : '0',
      startDate: new Date(investment.startDate),
      maturityDate: investment.maturityDate ? new Date(investment.maturityDate) : null,
      term: investment.term ? investment.term.toString() : '',
      status: investment.status,
      certificateNumber: investment.certificateNumber || '',
      remarks: investment.remarks || '',
    });
    
    setIsEditDialogOpen(true);
  }
  
  // Get Investment Type Display Label
  const getInvestmentTypeLabel = (type: string): string => {
    switch(type) {
      case InvestmentType.RPP_GOLD_TIER1: return 'RPP GOLD Tier 1 (₹24,999-₹1,50,000)';
      case InvestmentType.RPP_GOLD_TIER2: return 'RPP GOLD Tier 2 (₹3,00,000-₹5,00,000)';
      case InvestmentType.RPP_GOLD_TIER3: return 'RPP GOLD Tier 3 (₹6,00,000+)';
      default: return type;
    }
  };
  
  // Get default daily return rate based on investment type
  const getDailyReturnRate = (type: string): number => {
    switch(type) {
      case InvestmentType.RPP_GOLD_TIER1: return 0.75;
      case InvestmentType.RPP_GOLD_TIER2: return 1.0;
      case InvestmentType.RPP_GOLD_TIER3: return 1.5;
      default: return 0;
    }
  };
  
  // Get default working days based on investment type
  const getWorkingDays = (type: string): number => {
    switch(type) {
      case InvestmentType.RPP_GOLD_TIER1: return 267;
      case InvestmentType.RPP_GOLD_TIER2: return 200;
      case InvestmentType.RPP_GOLD_TIER3: return 132;
      default: return 0;
    }
  };
  
  // Get Branch Name by ID
  const getBranchName = (branchId: number): string => {
    const branch = branches?.find(b => b.id === branchId);
    return branch ? branch.name : 'Unknown Branch';
  };
  
  // Get User Name by ID
  const getUserName = (userId: number): string => {
    const foundUser = users?.find(u => u.id === userId);
    return foundUser ? (foundUser.fullName || foundUser.username) : 'Unknown User';
  };
  
  // Filter Investments by Type (for tabs)
  const filteredInvestments = activeTab === 'all'
    ? investments
    : investments?.filter(inv => inv.type === activeTab);
    
  // Calculate investment progress percentage
  const calculateProgressPercentage = (investment: Investment): number => {
    if (!investment.workingDays || investment.workingDays === 0) return 0;
    const percentage = (investment.daysCompleted || 0) / investment.workingDays * 100;
    return Math.min(Math.max(percentage, 0), 100); // Ensure between 0-100
  };
  
  // Calculate total payout amount (with 10% admin charges deducted)
  const calculateTotalPayout = (investment: Investment): number => {
    if (!investment.amount || !investment.dailyReturn || !investment.workingDays) return 0;
    const principal = parseFloat(investment.amount);
    const dailyReturn = parseFloat(investment.dailyReturn);
    const workingDays = investment.workingDays;
    const grossPayout = principal * (dailyReturn / 100) * workingDays;
    // Apply 10% admin charges deduction
    return grossPayout * 0.9;
  };
  
  // Calculate payout made so far (with 10% admin charges deducted)
  const calculatePayoutMade = (investment: Investment): number => {
    if (!investment.amount || !investment.dailyReturn || !investment.daysCompleted) return 0;
    const principal = parseFloat(investment.amount);
    const dailyReturn = parseFloat(investment.dailyReturn);
    const daysCompleted = investment.daysCompleted;
    const grossPayoutMade = principal * (dailyReturn / 100) * daysCompleted;
    // Apply 10% admin charges deduction
    return grossPayoutMade * 0.9;
  };
  
  // Calculate remaining payout amount (with 10% admin charges deducted)
  const calculateRemainingPayout = (investment: Investment): number => {
    const totalPayout = calculateTotalPayout(investment);
    const payoutMade = calculatePayoutMade(investment);
    return totalPayout - payoutMade;
  };
  
  // Get investment referrals by investment ID
  const getInvestmentReferrals = (investmentId: number): Referral[] => {
    return referrals?.filter(ref => ref.investmentId === investmentId) || [];
  };
  
  // Check if a referral level is unlocked for an investment
  const isReferralLevelUnlocked = (investmentId: number, level: string): boolean => {
    return referrals?.some(ref => ref.investmentId === investmentId && ref.level === level) || false;
  };
  
  // Get all possible referral levels (in order)
  const getReferralLevels = (): string[] => {
    return [
      ReferralLevel.DIRECT,
      ReferralLevel.LEVEL1,
      ReferralLevel.LEVEL2,
      ReferralLevel.LEVEL3,
      ReferralLevel.LEVEL4,
      ReferralLevel.LEVEL5
    ];
  };
  
  // Get referral level display name
  const getReferralLevelName = (level: string): string => {
    switch(level) {
      case ReferralLevel.DIRECT: return 'Direct Referral';
      case ReferralLevel.LEVEL1: return 'Level 1';
      case ReferralLevel.LEVEL2: return 'Level 2';
      case ReferralLevel.LEVEL3: return 'Level 3';
      case ReferralLevel.LEVEL4: return 'Level 4';
      case ReferralLevel.LEVEL5: return 'Level 5';
      default: return level;
    }
  };
  
  // Get referral level commission rate
  const getReferralCommissionRate = (level: string): number => {
    switch(level) {
      case ReferralLevel.DIRECT: return 5;
      case ReferralLevel.LEVEL1: return 10;
      case ReferralLevel.LEVEL2: return 7;
      case ReferralLevel.LEVEL3: return 5;
      case ReferralLevel.LEVEL4: return 4;
      case ReferralLevel.LEVEL5: return 3;
      default: return 0;
    }
  };
  
  if (isLoadingInvestments || isLoadingBranches || (isAdmin && isLoadingUsers)) {
    return (
      <DashboardLayout title="Investments">
        <div className="flex items-center justify-center h-64">
          <p>Loading investments...</p>
        </div>
      </DashboardLayout>
    );
  }
  
  if (investmentsError) {
    return (
      <DashboardLayout title="Investments">
        <div className="flex items-center justify-center h-64">
          <p className="text-red-500">Error: {(investmentsError as Error).message}</p>
        </div>
      </DashboardLayout>
    );
  }
  
  return (
    <DashboardLayout title="Investments">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Manage Investments</h2>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>Add New Investment</Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Add New Investment</DialogTitle>
              </DialogHeader>
              <Form {...addInvestmentForm}>
                <form onSubmit={addInvestmentForm.handleSubmit(onAddInvestmentSubmit)} className="space-y-4">
                  {(isAdmin || isModerator) && (
                    <FormField
                      control={addInvestmentForm.control}
                      name="userId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>User</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value.toString()}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select User" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {users?.map(user => (
                                <SelectItem key={user.id} value={user.id.toString()}>
                                  {user.fullName || user.username}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                  
                  <FormField
                    control={addInvestmentForm.control}
                    name="branchId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Branch</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value.toString()}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select Branch" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {branches?.map(branch => (
                              <SelectItem key={branch.id} value={branch.id.toString()}>
                                {branch.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addInvestmentForm.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Investment Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select Type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value={InvestmentType.RPP_GOLD_TIER1}>RPP GOLD Tier 1 (₹24,999-₹1,50,000)</SelectItem>
                            <SelectItem value={InvestmentType.RPP_GOLD_TIER2}>RPP GOLD Tier 2 (₹3,00,000-₹5,00,000)</SelectItem>
                            <SelectItem value={InvestmentType.RPP_GOLD_TIER3}>RPP GOLD Tier 3 (₹6,00,000+)</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={addInvestmentForm.control}
                      name="amount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Amount</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.01" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={addInvestmentForm.control}
                      name="interestRate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Interest Rate (%)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.01" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <FormField
                      control={addInvestmentForm.control}
                      name="dailyReturn"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Daily Return (%)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.01" readOnly />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={addInvestmentForm.control}
                      name="workingDays"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Working Days</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" readOnly />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={addInvestmentForm.control}
                      name="daysCompleted"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Days Completed</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={addInvestmentForm.control}
                      name="totalReturns"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Total Returns (₹)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" step="0.01" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={addInvestmentForm.control}
                      name="startDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Start Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant="outline"
                                  className="text-left font-normal"
                                >
                                  {field.value ? (
                                    format(field.value, "PPP")
                                  ) : (
                                    <span>Pick a date</span>
                                  )}
                                  <Calendar className="ml-auto h-4 w-4" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                              <CalendarComponent
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={addInvestmentForm.control}
                      name="maturityDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Maturity Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant="outline"
                                  className="text-left font-normal"
                                >
                                  {field.value ? (
                                    format(field.value, "PPP")
                                  ) : (
                                    <span>Pick a date</span>
                                  )}
                                  <Calendar className="ml-auto h-4 w-4" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                              <CalendarComponent
                                mode="single"
                                selected={field.value || undefined}
                                onSelect={field.onChange}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={addInvestmentForm.control}
                      name="term"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Term (Months)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={addInvestmentForm.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Status</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select Status" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="active">Active</SelectItem>
                              <SelectItem value="matured">Matured</SelectItem>
                              <SelectItem value="closed">Closed</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={addInvestmentForm.control}
                    name="certificateNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Certificate Number</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addInvestmentForm.control}
                    name="remarks"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Remarks</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Additional notes about this investment"
                            className="resize-none"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button type="submit" disabled={addInvestmentMutation.isPending}>
                      {addInvestmentMutation.isPending ? 'Saving...' : 'Save Investment'}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
        
        {/* Investment Type Tabs */}
        <Tabs 
          defaultValue="all" 
          className="mb-6"
          value={activeTab}
          onValueChange={setActiveTab}
        >
          <TabsList className="grid grid-cols-4 w-full max-w-3xl">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value={InvestmentType.RPP_GOLD_TIER1}>Tier 1</TabsTrigger>
            <TabsTrigger value={InvestmentType.RPP_GOLD_TIER2}>Tier 2</TabsTrigger>
            <TabsTrigger value={InvestmentType.RPP_GOLD_TIER3}>Tier 3</TabsTrigger>
          </TabsList>
        </Tabs>
        
        {filteredInvestments && filteredInvestments.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredInvestments.map((investment) => (
              <Card key={investment.id} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <CoinsIcon className="mr-2 h-5 w-5" />
                      <CardTitle className="text-lg font-medium">
                        {getInvestmentTypeLabel(investment.type)}
                      </CardTitle>
                    </div>
                    <Badge 
                      variant={
                        investment.status === 'active' ? "default" : 
                        investment.status === 'matured' ? "secondary" : 
                        "outline"
                      }
                    >
                      {investment.status.charAt(0).toUpperCase() + investment.status.slice(1)}
                    </Badge>
                  </div>
                  <CardDescription>
                    {isAdmin || isModerator ? `${getUserName(investment.userId)} - ` : ''}
                    {getBranchName(investment.branchId)}
                  </CardDescription>
                </CardHeader>
                <CardContent className="pb-3">
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center">
                        <Banknote className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span className="text-sm font-medium">₹{investment.amount.toLocaleString()}</span>
                      </div>
                      {investment.dailyReturn ? (
                        <div className="flex items-center">
                          <PercentIcon className="h-4 w-4 mr-2 text-muted-foreground" />
                          <span className="text-sm font-medium">{investment.dailyReturn}% Daily</span>
                        </div>
                      ) : investment.interestRate && (
                        <div className="flex items-center">
                          <PercentIcon className="h-4 w-4 mr-2 text-muted-foreground" />
                          <span className="text-sm font-medium">{investment.interestRate}% Interest</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center">
                        <ClockIcon className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span className="text-sm">
                          {investment.daysCompleted || 0} / {investment.workingDays || '?'} days
                        </span>
                      </div>
                      <div className="flex items-center justify-end">
                        <BarChartIcon className="h-4 w-4 mr-2 text-muted-foreground" />
                        <div className="text-sm flex flex-col items-end">
                          <span>
                            ₹{(investment.totalReturns || 0).toLocaleString()} gross returns
                          </span>
                          <span className="text-xs text-muted-foreground">
                            ₹{(Number(investment.totalReturns || 0) * 0.9).toLocaleString()} net (after 10% admin charges)
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span className="text-sm">
                          {format(new Date(investment.startDate), 'dd MMM yyyy')}
                        </span>
                      </div>
                      {investment.maturityDate && (
                        <div className="text-sm text-right">
                          Matures: {format(new Date(investment.maturityDate), 'dd MMM yyyy')}
                        </div>
                      )}
                    </div>
                    
                    {investment.term && (
                      <div className="text-sm text-muted-foreground">
                        Term: {investment.term} months
                      </div>
                    )}
                    
                    {investment.certificateNumber && (
                      <div className="flex items-center">
                        <FileCheck className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">
                          Cert #{investment.certificateNumber}
                        </span>
                      </div>
                    )}
                    
                    {/* Progress Bar */}
                    <div className="mt-2">
                      <div className="flex justify-between items-center mb-1 text-xs">
                        <span>Progress: {investment.daysCompleted || 0}/{investment.workingDays || 0} days</span>
                        <span>{calculateProgressPercentage(investment).toFixed(1)}%</span>
                      </div>
                      <Progress value={calculateProgressPercentage(investment)} className="h-2" />
                    </div>
                    
                    {/* Payout Information */}
                    <div className="mt-4 p-3 bg-muted/50 rounded-md">
                      <h4 className="text-sm font-semibold mb-2 flex items-center">
                        <PiggyBankIcon className="mr-2 h-4 w-4" /> Payout Information
                      </h4>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div>
                          <p className="text-muted-foreground">Total Payout:</p>
                          <p className="font-medium">₹{calculateTotalPayout(investment).toLocaleString('en-IN', {maximumFractionDigits: 2})}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Payout Made:</p>
                          <p className="font-medium">₹{calculatePayoutMade(investment).toLocaleString('en-IN', {maximumFractionDigits: 2})}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Remaining Payout:</p>
                          <p className="font-medium">₹{calculateRemainingPayout(investment).toLocaleString('en-IN', {maximumFractionDigits: 2})}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Next Payout:</p>
                          <p className="font-medium">15th or 30th</p>
                        </div>
                      </div>
                    </div>
                    
                    {/* Referral Levels Section (for admins only) */}
                    {(isAdmin || isModerator) && (
                      <div className="mt-4 p-3 bg-muted/50 rounded-md">
                        <h4 className="text-sm font-semibold mb-2 flex items-center">
                          <UsersIcon className="mr-2 h-4 w-4" /> Referral Levels
                        </h4>
                        <div className="grid grid-cols-3 gap-1 text-xs">
                          {getReferralLevels().map(level => (
                            <div 
                              key={level} 
                              className={`flex flex-col items-center p-1 rounded ${
                                isReferralLevelUnlocked(investment.id, level) 
                                  ? 'bg-green-100 dark:bg-green-900/30' 
                                  : 'bg-gray-100 dark:bg-gray-800/50'
                              }`}
                            >
                              <div className="mb-1">
                                {isReferralLevelUnlocked(investment.id, level) 
                                  ? <UnlockIcon className="h-3 w-3 text-green-600 dark:text-green-400" /> 
                                  : <LockIcon className="h-3 w-3 text-gray-400" />
                                }
                              </div>
                              <span className={isReferralLevelUnlocked(investment.id, level) ? 'font-medium' : 'text-muted-foreground'}>
                                {getReferralLevelName(level)}
                              </span>
                              <span className="text-[10px]">{getReferralCommissionRate(level)}%</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {investment.remarks && (
                      <div className="text-sm text-muted-foreground italic pt-2 border-t">
                        {investment.remarks}
                      </div>
                    )}
                  </div>
                </CardContent>
                <div className="p-4 pt-0">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full"
                    onClick={() => handleEditInvestment(investment)}
                  >
                    <EditIcon className="h-4 w-4 mr-2" />
                    Edit Investment
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-64 bg-gray-50 rounded-lg">
            <CoinsIcon className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900">No Investments Found</h3>
            <p className="text-sm text-gray-500 mt-2">
              {activeTab !== "all" 
                ? `No ${getInvestmentTypeLabel(activeTab)} investments found.` 
                : "Get started by adding a new investment"}
            </p>
          </div>
        )}
      </div>
      
      {/* Edit Dialog */}
      {selectedInvestment && (
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Edit Investment</DialogTitle>
            </DialogHeader>
            <Form {...editInvestmentForm}>
              <form onSubmit={editInvestmentForm.handleSubmit(onEditInvestmentSubmit)} className="space-y-4">
                {(isAdmin || isModerator) && (
                  <FormField
                    control={editInvestmentForm.control}
                    name="userId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>User</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value.toString()}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select User" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {users?.map(user => (
                              <SelectItem key={user.id} value={user.id.toString()}>
                                {user.fullName || user.username}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
                
                <FormField
                  control={editInvestmentForm.control}
                  name="branchId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Branch</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Branch" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {branches?.map(branch => (
                            <SelectItem key={branch.id} value={branch.id.toString()}>
                              {branch.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={editInvestmentForm.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Investment Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value={InvestmentType.RPP_GOLD_TIER1}>RPP GOLD Tier 1 (₹24,999-₹1,50,000)</SelectItem>
                          <SelectItem value={InvestmentType.RPP_GOLD_TIER2}>RPP GOLD Tier 2 (₹3,00,000-₹5,00,000)</SelectItem>
                          <SelectItem value={InvestmentType.RPP_GOLD_TIER3}>RPP GOLD Tier 3 (₹6,00,000+)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editInvestmentForm.control}
                    name="amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Amount</FormLabel>
                        <FormControl>
                          <Input {...field} type="number" step="0.01" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editInvestmentForm.control}
                    name="interestRate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Interest Rate (%)</FormLabel>
                        <FormControl>
                          <Input {...field} type="number" step="0.01" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <FormField
                    control={editInvestmentForm.control}
                    name="dailyReturn"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Daily Return (%)</FormLabel>
                        <FormControl>
                          <Input {...field} type="number" step="0.01" readOnly />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editInvestmentForm.control}
                    name="workingDays"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Working Days</FormLabel>
                        <FormControl>
                          <Input {...field} type="number" readOnly />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editInvestmentForm.control}
                    name="daysCompleted"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Days Completed</FormLabel>
                        <FormControl>
                          <Input {...field} type="number" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editInvestmentForm.control}
                    name="totalReturns"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Total Returns (₹)</FormLabel>
                        <FormControl>
                          <Input {...field} type="number" step="0.01" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editInvestmentForm.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Start Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant="outline"
                                className="text-left font-normal"
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>Pick a date</span>
                                )}
                                <Calendar className="ml-auto h-4 w-4" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <CalendarComponent
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editInvestmentForm.control}
                    name="maturityDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Maturity Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant="outline"
                                className="text-left font-normal"
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>Pick a date</span>
                                )}
                                <Calendar className="ml-auto h-4 w-4" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <CalendarComponent
                              mode="single"
                              selected={field.value || undefined}
                              onSelect={field.onChange}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editInvestmentForm.control}
                    name="term"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Term (Months)</FormLabel>
                        <FormControl>
                          <Input {...field} type="number" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editInvestmentForm.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Status</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select Status" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="active">Active</SelectItem>
                            <SelectItem value="matured">Matured</SelectItem>
                            <SelectItem value="closed">Closed</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={editInvestmentForm.control}
                  name="certificateNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Certificate Number</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={editInvestmentForm.control}
                  name="remarks"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Remarks</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Additional notes about this investment"
                          className="resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button type="submit" disabled={updateInvestmentMutation.isPending}>
                    {updateInvestmentMutation.isPending ? 'Updating...' : 'Update Investment'}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      )}
    </DashboardLayout>
  );
}