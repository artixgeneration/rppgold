import { IStorage } from './storage-types';
import { 
  User, InsertUser, Message, InsertMessage, 
  Folder, InsertFolder, UserRole 
} from '@shared/schema';
import { pool } from './database';
import session from 'express-session';
import memorystore from 'memorystore';

export class MySQLStorage implements IStorage {
  public sessionStore: any;

  constructor() {
    // Using memory store for sessions for now
    const MemoryStore = memorystore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    try {
      const [rows] = await pool.query(
        'SELECT * FROM users WHERE id = ?',
        [id]
      );
      const users = rows as any[];
      return users.length > 0 ? this.mapToUser(users[0]) : undefined;
    } catch (error) {
      console.error('Error getting user:', error);
      return undefined;
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const [rows] = await pool.query(
        'SELECT * FROM users WHERE username = ?',
        [username]
      );
      const users = rows as any[];
      return users.length > 0 ? this.mapToUser(users[0]) : undefined;
    } catch (error) {
      console.error('Error getting user by username:', error);
      return undefined;
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      const [result] = await pool.query(
        'INSERT INTO users (username, password, email, full_name, role, branch, phone_number, aadhar_number, pan_number, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
          insertUser.username, 
          insertUser.password, 
          insertUser.email || null, 
          insertUser.fullName || null, 
          insertUser.role || UserRole.CUSTOMER, 
          insertUser.branch || null,
          insertUser.phoneNumber || null,
          insertUser.aadharNumber || null,
          insertUser.panNumber || null,
          insertUser.isActive === undefined ? true : insertUser.isActive
        ]
      );
      
      const id = (result as any).insertId;
      
      const user: User = {
        id,
        username: insertUser.username,
        password: insertUser.password,
        email: insertUser.email || null,
        fullName: insertUser.fullName || null,
        role: insertUser.role || UserRole.CUSTOMER,
        branch: insertUser.branch || null,
        phoneNumber: insertUser.phoneNumber || null,
        aadharNumber: insertUser.aadharNumber || null,
        panNumber: insertUser.panNumber || null,
        isActive: insertUser.isActive === undefined ? true : insertUser.isActive,
        createdAt: new Date()
      };
      
      return user;
    } catch (error) {
      console.error('Error creating user:', error);
      throw error;
    }
  }

  async getAllUsers(): Promise<User[]> {
    try {
      const [rows] = await pool.query('SELECT * FROM users');
      return (rows as any[]).map(row => this.mapToUser(row));
    } catch (error) {
      console.error('Error getting all users:', error);
      return [];
    }
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    try {
      // Build the SET part of the query dynamically
      const updates: string[] = [];
      const values: any[] = [];

      // Map object properties to database column names
      const columnMap: Record<string, string> = {
        username: 'username',
        password: 'password',
        email: 'email',
        fullName: 'full_name',
        role: 'role',
        branch: 'branch',
        phoneNumber: 'phone_number',
        aadharNumber: 'aadhar_number',
        panNumber: 'pan_number',
        isActive: 'is_active'
      };

      for (const [key, value] of Object.entries(userData)) {
        if (key !== 'id' && key !== 'createdAt' && columnMap[key]) {
          updates.push(`${columnMap[key]} = ?`);
          values.push(value);
        }
      }

      if (updates.length === 0) {
        return await this.getUser(id);
      }

      values.push(id);

      await pool.query(
        `UPDATE users SET ${updates.join(', ')} WHERE id = ?`,
        values
      );

      return await this.getUser(id);
    } catch (error) {
      console.error('Error updating user:', error);
      return undefined;
    }
  }

  // Chat message operations
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    try {
      const [result] = await pool.query(
        'INSERT INTO messages (sender_id, receiver_id, content, is_read) VALUES (?, ?, ?, ?)',
        [
          insertMessage.senderId, 
          insertMessage.receiverId, 
          insertMessage.content, 
          insertMessage.isRead === undefined ? false : insertMessage.isRead
        ]
      );
      
      const id = (result as any).insertId;
      
      const message: Message = {
        id,
        senderId: insertMessage.senderId,
        receiverId: insertMessage.receiverId,
        content: insertMessage.content,
        isRead: insertMessage.isRead === undefined ? false : insertMessage.isRead,
        createdAt: new Date()
      };
      
      return message;
    } catch (error) {
      console.error('Error creating message:', error);
      throw error;
    }
  }

  async getChatMessages(senderId: number, receiverId: number): Promise<Message[]> {
    try {
      const [rows] = await pool.query(
        'SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY created_at ASC',
        [senderId, receiverId, receiverId, senderId]
      );
      return (rows as any[]).map(row => this.mapToMessage(row));
    } catch (error) {
      console.error('Error getting chat messages:', error);
      return [];
    }
  }

  async markMessageAsRead(id: number): Promise<Message | undefined> {
    try {
      await pool.query(
        'UPDATE messages SET is_read = true WHERE id = ?',
        [id]
      );
      
      const [rows] = await pool.query(
        'SELECT * FROM messages WHERE id = ?',
        [id]
      );
      const messages = rows as any[];
      return messages.length > 0 ? this.mapToMessage(messages[0]) : undefined;
    } catch (error) {
      console.error('Error marking message as read:', error);
      return undefined;
    }
  }

  // Folder operations
  async createFolder(insertFolder: InsertFolder): Promise<Folder> {
    try {
      const [result] = await pool.query(
        'INSERT INTO folders (name, owner_id) VALUES (?, ?)',
        [insertFolder.name, insertFolder.ownerId]
      );
      
      const id = (result as any).insertId;
      
      const folder: Folder = {
        id,
        name: insertFolder.name,
        ownerId: insertFolder.ownerId,
        createdAt: new Date()
      };
      
      return folder;
    } catch (error) {
      console.error('Error creating folder:', error);
      throw error;
    }
  }

  async getUserFolders(userId: number): Promise<Folder[]> {
    try {
      const [rows] = await pool.query(
        'SELECT * FROM folders WHERE owner_id = ?',
        [userId]
      );
      return (rows as any[]).map(row => this.mapToFolder(row));
    } catch (error) {
      console.error('Error getting user folders:', error);
      return [];
    }
  }

  // Helper methods to map database results to our types
  private mapToUser(row: any): User {
    return {
      id: row.id,
      username: row.username,
      password: row.password,
      email: row.email,
      fullName: row.full_name,
      role: row.role || UserRole.CUSTOMER,
      branch: row.branch,
      phoneNumber: row.phone_number,
      aadharNumber: row.aadhar_number,
      panNumber: row.pan_number,
      isActive: Boolean(row.is_active),
      createdAt: row.created_at ? new Date(row.created_at) : null
    };
  }

  private mapToMessage(row: any): Message {
    return {
      id: row.id,
      senderId: row.sender_id,
      receiverId: row.receiver_id,
      content: row.content,
      isRead: Boolean(row.is_read),
      createdAt: row.created_at ? new Date(row.created_at) : null
    };
  }

  private mapToFolder(row: any): Folder {
    return {
      id: row.id,
      name: row.name,
      ownerId: row.owner_id,
      createdAt: row.created_at ? new Date(row.created_at) : null
    };
  }
}