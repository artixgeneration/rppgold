import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { storage } from './storage';
import { WebSocketMessage, ChatMessage } from '@shared/schema';

export function setupWebSocketServer(httpServer: Server) {
  const wss = new WebSocketServer({ 
    server: httpServer, 
    path: '/ws',
    // Add more robust error handling
    clientTracking: true,
    // Allow keepalive to prevent timeouts
    perMessageDeflate: {
      zlibDeflateOptions: {
        chunkSize: 1024,
        memLevel: 7,
        level: 3
      },
      zlibInflateOptions: {
        chunkSize: 10 * 1024
      },
      // Below options help save CPU cycles
      concurrencyLimit: 10,
      threshold: 1024 // Only deflate messages >= 1kb
    }
  });

  // Store connected clients with their user IDs
  const clients = new Map<number, WebSocket>();
  
  // Handle periodic ping to keep connections alive
  const pingInterval = setInterval(() => {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.ping();
      }
    });
  }, 30000); // Ping every 30 seconds

  wss.on('connection', (ws: WebSocket) => {
    console.log('WebSocket client connected');
    
    let userId: number | null = null;
    let pingTimeout: NodeJS.Timeout | null = null;
    
    // Reset timeout on pong response
    ws.on('pong', () => {
      if (pingTimeout) clearTimeout(pingTimeout);
      
      // Set timeout to close connection if no pong received
      pingTimeout = setTimeout(() => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.terminate();
        }
      }, 60000); // 60 seconds timeout
    });

    ws.on('message', async (message: string) => {
      try {
        const parsedMessage: WebSocketMessage = JSON.parse(message);
        
        switch (parsedMessage.type) {
          case 'chat':
            // Handle chat messages
            const chatMessage = parsedMessage.data as ChatMessage;
            
            // Store message in database
            if (chatMessage.senderId && chatMessage.receiverId && chatMessage.content) {
              const savedMessage = await storage.createMessage({
                senderId: chatMessage.senderId,
                receiverId: chatMessage.receiverId,
                content: chatMessage.content,
                isRead: false
              });
              
              // Set the user ID for this connection if not set yet
              if (!userId) {
                userId = chatMessage.senderId;
                clients.set(userId, ws);
              }
              
              // Send the message to the recipient if they're online
              const recipientWs = clients.get(chatMessage.receiverId);
              if (recipientWs && recipientWs.readyState === WebSocket.OPEN) {
                recipientWs.send(JSON.stringify({
                  type: 'chat',
                  data: savedMessage
                }));
              }
              
              // Send confirmation back to sender
              ws.send(JSON.stringify({
                type: 'chat',
                data: savedMessage
              }));
            }
            break;
            
          case 'notification':
            // Handle notification messages
            console.log('Received notification message', parsedMessage.data);
            if (parsedMessage.data && parsedMessage.data.targetUserId) {
              const targetWs = clients.get(parsedMessage.data.targetUserId);
              if (targetWs && targetWs.readyState === WebSocket.OPEN) {
                targetWs.send(JSON.stringify({
                  type: 'notification',
                  data: parsedMessage.data
                }));
              }
            }
            break;
            
          case 'system':
            // Handle system messages (like user connected/disconnected)
            console.log('Received system message', parsedMessage.data);
            
            // If it's a connection message with user ID
            if (parsedMessage.data && parsedMessage.data.userId) {
              userId = parsedMessage.data.userId;
              clients.set(userId, ws);
              
              // Notify clients that this user is online
              wss.clients.forEach((client) => {
                if (client !== ws && client.readyState === WebSocket.OPEN) {
                  client.send(JSON.stringify({
                    type: 'system',
                    data: { 
                      event: 'user_online',
                      userId: userId 
                    }
                  }));
                }
              });
              
              // Send online users list to new connection
              const onlineUsers = Array.from(clients.keys());
              ws.send(JSON.stringify({
                type: 'system',
                data: { 
                  event: 'online_users',
                  users: onlineUsers 
                }
              }));
            }
            break;
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
            type: 'system',
            data: { error: 'Invalid message format' }
          }));
        }
      }
    });

    ws.on('close', () => {
      console.log('WebSocket client disconnected');
      
      // Clear ping timeout
      if (pingTimeout) clearTimeout(pingTimeout);
      
      // Remove client from connections map
      if (userId) {
        clients.delete(userId);
        
        // Notify other clients that this user is offline
        wss.clients.forEach((client) => {
          if (client !== ws && client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({
              type: 'system',
              data: { 
                event: 'user_offline',
                userId: userId 
              }
            }));
          }
        });
      }
    });
    
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      if (pingTimeout) clearTimeout(pingTimeout);
      if (userId) clients.delete(userId);
    });
    
    // Send initial confirmation that connection is established
    ws.send(JSON.stringify({
      type: 'system',
      data: { message: 'Connected to server' }
    }));
  });

  console.log('WebSocket server initialized with ping/pong health checks');
  
  // Clean up interval on server shutdown
  httpServer.on('close', () => {
    clearInterval(pingInterval);
  });
  
  return wss;
}
