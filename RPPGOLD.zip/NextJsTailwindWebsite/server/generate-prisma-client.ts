import { exec } from 'child_process';
import { promisify } from 'util';
import * as fs from 'fs';
import * as path from 'path';

const execAsync = promisify(exec);

async function generatePrismaClient() {
  try {
    console.log('Generating Prisma client...');
    await execAsync('npx prisma generate');
    console.log('Prisma client generated successfully!');
  } catch (error) {
    console.error('Error generating Prisma client:', error);
    process.exit(1);
  }
}

async function runMigrations() {
  try {
    console.log('Running database migrations...');
    // First check if migrations directory exists, if not create it
    const migrationsDir = path.join(__dirname, '../prisma/migrations');
    if (!fs.existsSync(migrationsDir)) {
      fs.mkdirSync(migrationsDir, { recursive: true });
    }
    
    // Run migrations
    await execAsync('npx prisma migrate dev --name initial-migration');
    console.log('Database migrations completed successfully!');
  } catch (error) {
    console.error('Error running migrations:', error);
    process.exit(1);
  }
}

async function main() {
  try {
    await generatePrismaClient();
    await runMigrations();
    console.log('Database setup completed successfully!');
  } catch (error) {
    console.error('Database setup failed:', error);
    process.exit(1);
  }
}

main();