import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser, UserRole } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

// Create some sample users if using memory storage
async function seedUsers() {
  try {
    // Check if admin user exists
    const adminUser = await storage.getUserByUsername("admin");
    if (!adminUser) {
      await storage.createUser({
        username: "admin",
        password: await hashPassword("admin123"),
        email: "admin@example.com",
        fullName: "Admin User",
        role: UserRole.ADMIN,
        branch: "HQ",
        isActive: true,
      });
    }

    // Check if moderator user exists
    const modUser = await storage.getUserByUsername("moderator");
    if (!modUser) {
      await storage.createUser({
        username: "moderator",
        password: await hashPassword("mod123"),
        email: "mod@example.com",
        fullName: "Moderator User",
        role: UserRole.MODERATOR,
        branch: "Mumbai",
        isActive: true,
      });
    }
    
    // Check if branch manager exists
    const branchManagerUser = await storage.getUserByUsername("branchmanager");
    if (!branchManagerUser) {
      await storage.createUser({
        username: "branchmanager",
        password: await hashPassword("branch123"),
        email: "branch@example.com",
        fullName: "Branch Manager",
        role: UserRole.BRANCH_MANAGER,
        branch: "Delhi",
        isActive: true,
      });
    }

    // Create a few customer users
    const customer1 = await storage.getUserByUsername("customer");
    if (!customer1) {
      await storage.createUser({
        username: "customer",
        password: await hashPassword("customer123"),
        email: "customer@example.com",
        fullName: "John Customer",
        role: UserRole.CUSTOMER,
        branch: "Delhi",
        aadharNumber: "1234-5678-9012",
        panNumber: "ABCDE1234F",
        isActive: true,
      });
    }

    const customer2 = await storage.getUserByUsername("james");
    if (!customer2) {
      await storage.createUser({
        username: "james",
        password: await hashPassword("james123"),
        email: "james@example.com",
        fullName: "James Wilson",
        role: UserRole.CUSTOMER,
        branch: "Mumbai",
        aadharNumber: "9876-5432-1098",
        panNumber: "FGHIJ5678K",
        isActive: true,
      });
    }

    const devUser = await storage.getUserByUsername("developer");
    if (!devUser) {
      await storage.createUser({
        username: "developer",
        password: await hashPassword("dev123"),
        email: "dev@example.com",
        fullName: "Dev User",
        role: UserRole.DEVELOPER,
        branch: "Tech",
        isActive: true,
      });
    }
  } catch (error) {
    console.error("Error seeding users:", error);
  }
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "super-secret-key",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 86400000, // 24 hours
    },
  };

  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false, { message: "Incorrect username or password" });
        }
        return done(null, user);
      } catch (err) {
        return done(err);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // Registration endpoint
  app.post("/api/register", async (req, res, next) => {
    try {
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const hashedPassword = await hashPassword(req.body.password);
      
      const user = await storage.createUser({
        ...req.body,
        password: hashedPassword,
      });

      req.login(user, (err) => {
        if (err) return next(err);
        return res.status(201).json(user);
      });
    } catch (error) {
      next(error);
    }
  });

  // Login endpoint
  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) return next(err);
      if (!user) {
        return res.status(401).json({ message: info?.message || "Authentication failed" });
      }
      req.login(user, (err) => {
        if (err) return next(err);
        return res.json(user);
      });
    })(req, res, next);
  });

  // Logout endpoint
  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  // Current user endpoint
  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    res.json(req.user);
  });

  // Seed initial users for development
  seedUsers();
}
