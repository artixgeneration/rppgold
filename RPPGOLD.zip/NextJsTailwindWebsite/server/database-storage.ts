import { 
  users, messages, folders, branches, investments,
  type User, type InsertUser, 
  type Message, type InsertMessage, 
  type Folder, type InsertFolder,
  type Branch, type InsertBranch,
  type Investment, type InsertInvestment
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, desc } from "drizzle-orm";
import connectPgSimple from "connect-pg-simple";
import session from "express-session";
import { IStorage } from "./storage-types";
import { Pool } from "@neondatabase/serverless";

// Initialize PostgreSQL session store
const PostgresSessionStore = connectPgSimple(session);
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// DatabaseStorage implementation using PostgreSQL and Drizzle ORM
export class DatabaseStorage implements IStorage {
  public sessionStore: any;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      tableName: 'session',
      createTableIfMissing: true 
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db.update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  // Chat message operations
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db.insert(messages).values(insertMessage).returning();
    return message;
  }

  async getChatMessages(senderId: number, receiverId: number): Promise<Message[]> {
    return await db.select()
      .from(messages)
      .where(
        or(
          and(
            eq(messages.senderId, senderId),
            eq(messages.receiverId, receiverId)
          ),
          and(
            eq(messages.senderId, receiverId),
            eq(messages.receiverId, senderId)
          )
        )
      )
      .orderBy(messages.createdAt);
  }

  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const [updatedMessage] = await db.update(messages)
      .set({ isRead: true })
      .where(eq(messages.id, id))
      .returning();
    return updatedMessage;
  }

  // Folder operations
  async createFolder(insertFolder: InsertFolder): Promise<Folder> {
    const [folder] = await db.insert(folders).values(insertFolder).returning();
    return folder;
  }

  async getUserFolders(userId: number): Promise<Folder[]> {
    return await db.select()
      .from(folders)
      .where(eq(folders.ownerId, userId));
  }

  // Branch operations
  async createBranch(insertBranch: InsertBranch): Promise<Branch> {
    const [branch] = await db.insert(branches).values(insertBranch).returning();
    return branch;
  }

  async getBranch(id: number): Promise<Branch | undefined> {
    const [branch] = await db.select().from(branches).where(eq(branches.id, id));
    return branch;
  }

  async getAllBranches(): Promise<Branch[]> {
    return await db.select().from(branches);
  }

  async updateBranch(id: number, branchData: Partial<Branch>): Promise<Branch | undefined> {
    const [updatedBranch] = await db.update(branches)
      .set(branchData)
      .where(eq(branches.id, id))
      .returning();
    return updatedBranch;
  }

  // Investment operations
  async createInvestment(insertInvestment: InsertInvestment): Promise<Investment> {
    const now = new Date();
    const [investment] = await db.insert(investments)
      .values({
        ...insertInvestment,
        updatedAt: now
      })
      .returning();
    return investment;
  }

  async getInvestment(id: number): Promise<Investment | undefined> {
    const [investment] = await db.select().from(investments).where(eq(investments.id, id));
    return investment;
  }

  async getUserInvestments(userId: number): Promise<Investment[]> {
    return await db.select()
      .from(investments)
      .where(eq(investments.userId, userId))
      .orderBy(desc(investments.createdAt));
  }

  async getBranchInvestments(branchId: number): Promise<Investment[]> {
    return await db.select()
      .from(investments)
      .where(eq(investments.branchId, branchId))
      .orderBy(desc(investments.createdAt));
  }

  async updateInvestment(id: number, investmentData: Partial<Investment>): Promise<Investment | undefined> {
    const [updatedInvestment] = await db.update(investments)
      .set({
        ...investmentData,
        updatedAt: new Date()
      })
      .where(eq(investments.id, id))
      .returning();
    return updatedInvestment;
  }
}