import dotenv from 'dotenv';
import { pool, testConnection } from './database';

// Load environment variables
dotenv.config();

// SQL to create users table if it doesn't exist
const createUsersTable = `
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  full_name VARCHAR(255),
  role VARCHAR(50) NOT NULL DEFAULT 'customer',
  branch VARCHAR(100),
  phone_number VARCHAR(20),
  aadhar_number VARCHAR(20),
  pan_number VARCHAR(20),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
`;

// SQL to create messages table if it doesn't exist
const createMessagesTable = `
CREATE TABLE IF NOT EXISTS messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sender_id INT NOT NULL,
  receiver_id INT NOT NULL,
  content TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (sender_id) REFERENCES users(id),
  FOREIGN KEY (receiver_id) REFERENCES users(id)
);
`;

// SQL to create folders table if it doesn't exist
const createFoldersTable = `
CREATE TABLE IF NOT EXISTS folders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  owner_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (owner_id) REFERENCES users(id)
);
`;

// Initialize the database
async function initializeDatabase() {
  try {
    // Test connection
    const isConnected = await testConnection();
    if (!isConnected) {
      console.error('Failed to connect to MySQL database');
      return false;
    }
    
    // Create tables
    await pool.query(createUsersTable);
    console.log('Users table created or confirmed to exist');
    
    await pool.query(createMessagesTable);
    console.log('Messages table created or confirmed to exist');
    
    await pool.query(createFoldersTable);
    console.log('Folders table created or confirmed to exist');
    
    console.log('Database initialization completed successfully');
    return true;
  } catch (error) {
    console.error('Error initializing database:', error);
    return false;
  }
}

// Export the initialization function
export { initializeDatabase };