import { db } from './db';
import * as schema from '@shared/schema';

async function push() {
  console.log('Pushing schema to PostgreSQL database...');
  
  try {
    // Create tables using SQL statements for PostgreSQL
    await db.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        email TEXT,
        full_name TEXT,
        role TEXT NOT NULL DEFAULT 'customer',
        branch TEXT,
        phone_number TEXT,
        date_of_birth DATE,
        address TEXT,
        city TEXT,
        state TEXT,
        pincode TEXT,
        aadhar_number TEXT,
        aadhar_card_path TEXT,
        aadhar_verified BOOLEAN DEFAULT FALSE,
        pan_number TEXT,
        pan_card_path TEXT,
        pan_verified BOOLEAN DEFAULT FALSE,
        nominee_name TEXT,
        nominee_relationship TEXT,
        nominee_contact TEXT,
        bank_name TEXT,
        account_number TEXT,
        ifsc_code TEXT,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS messages (
        id SERIAL PRIMARY KEY,
        sender_id INTEGER NOT NULL REFERENCES users(id),
        receiver_id INTEGER NOT NULL REFERENCES users(id),
        content TEXT NOT NULL,
        is_read BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS folders (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        owner_id INTEGER NOT NULL REFERENCES users(id),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS branches (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        code TEXT NOT NULL UNIQUE,
        address TEXT NOT NULL,
        city TEXT NOT NULL,
        state TEXT NOT NULL,
        pincode TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        manager_name TEXT,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS investments (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        branch_id INTEGER NOT NULL REFERENCES branches(id),
        type TEXT NOT NULL,
        amount NUMERIC NOT NULL,
        interest_rate NUMERIC,
        daily_return NUMERIC,
        working_days INTEGER,
        days_completed INTEGER DEFAULT 0,
        total_returns NUMERIC DEFAULT 0,
        referred_by_id INTEGER REFERENCES users(id),
        start_date DATE NOT NULL,
        maturity_date DATE,
        term INTEGER,
        status TEXT NOT NULL DEFAULT 'active',
        certificate_number TEXT,
        remarks TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS referrals (
        id SERIAL PRIMARY KEY,
        investment_id INTEGER NOT NULL REFERENCES investments(id),
        referrer_id INTEGER NOT NULL REFERENCES users(id),
        referred_user_id INTEGER NOT NULL REFERENCES users(id),
        level TEXT NOT NULL,
        commission_rate NUMERIC NOT NULL,
        commission_amount NUMERIC NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        paid_date DATE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS session (
        sid VARCHAR NOT NULL,
        sess JSON NOT NULL,
        expire TIMESTAMP(6) NOT NULL,
        PRIMARY KEY (sid)
      );
    `);
    
    // Add any missing columns with ALTER TABLE statements for existing tables
    await db.execute(`
      DO $$
      BEGIN
        -- Add missing columns to users table
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'date_of_birth') THEN
          ALTER TABLE users ADD COLUMN date_of_birth DATE;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'address') THEN
          ALTER TABLE users ADD COLUMN address TEXT;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'city') THEN
          ALTER TABLE users ADD COLUMN city TEXT;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'state') THEN
          ALTER TABLE users ADD COLUMN state TEXT;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'pincode') THEN
          ALTER TABLE users ADD COLUMN pincode TEXT;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'aadhar_card_path') THEN
          ALTER TABLE users ADD COLUMN aadhar_card_path TEXT;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'aadhar_verified') THEN
          ALTER TABLE users ADD COLUMN aadhar_verified BOOLEAN DEFAULT FALSE;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'pan_card_path') THEN
          ALTER TABLE users ADD COLUMN pan_card_path TEXT;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'pan_verified') THEN
          ALTER TABLE users ADD COLUMN pan_verified BOOLEAN DEFAULT FALSE;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'nominee_name') THEN
          ALTER TABLE users ADD COLUMN nominee_name TEXT;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'nominee_relationship') THEN
          ALTER TABLE users ADD COLUMN nominee_relationship TEXT;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'nominee_contact') THEN
          ALTER TABLE users ADD COLUMN nominee_contact TEXT;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'bank_name') THEN
          ALTER TABLE users ADD COLUMN bank_name TEXT;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'account_number') THEN
          ALTER TABLE users ADD COLUMN account_number TEXT;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'ifsc_code') THEN
          ALTER TABLE users ADD COLUMN ifsc_code TEXT;
        END IF;
        
        -- Add missing columns to investments table
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'investments' AND column_name = 'daily_return') THEN
          ALTER TABLE investments ADD COLUMN daily_return NUMERIC;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'investments' AND column_name = 'working_days') THEN
          ALTER TABLE investments ADD COLUMN working_days INTEGER;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'investments' AND column_name = 'days_completed') THEN
          ALTER TABLE investments ADD COLUMN days_completed INTEGER DEFAULT 0;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'investments' AND column_name = 'total_returns') THEN
          ALTER TABLE investments ADD COLUMN total_returns NUMERIC DEFAULT 0;
        END IF;
        
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'investments' AND column_name = 'referred_by_id') THEN
          ALTER TABLE investments ADD COLUMN referred_by_id INTEGER REFERENCES users(id);
        END IF;
      END
      $$;
    `);
    
    console.log('Successfully pushed schema to PostgreSQL database');
  } catch (error) {
    console.error('Error pushing schema:', error);
  }
}

push();