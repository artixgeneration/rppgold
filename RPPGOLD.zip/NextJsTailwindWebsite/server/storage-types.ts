import type { 
  User, InsertUser,
  Message, InsertMessage,
  Folder, InsertFolder,
  Branch, InsertBranch,
  Investment, InsertInvestment
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Chat message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getChatMessages(senderId: number, receiverId: number): Promise<Message[]>;
  markMessageAsRead(id: number): Promise<Message | undefined>;
  
  // Folder operations
  createFolder(folder: InsertFolder): Promise<Folder>;
  getUserFolders(userId: number): Promise<Folder[]>;
  
  // Branch operations
  createBranch(branch: InsertBranch): Promise<Branch>;
  getBranch(id: number): Promise<Branch | undefined>;
  getAllBranches(): Promise<Branch[]>;
  updateBranch(id: number, branch: Partial<Branch>): Promise<Branch | undefined>;
  
  // Investment operations
  createInvestment(investment: InsertInvestment): Promise<Investment>;
  getInvestment(id: number): Promise<Investment | undefined>;
  getUserInvestments(userId: number): Promise<Investment[]>;
  getBranchInvestments(branchId: number): Promise<Investment[]>;
  updateInvestment(id: number, investment: Partial<Investment>): Promise<Investment | undefined>;
  
  // Session store
  sessionStore: any;
}