import { 
  users, messages, folders, branches, investments,
  type User, type InsertUser, 
  type Message, type InsertMessage, 
  type Folder, type InsertFolder,
  type Branch, type InsertBranch,
  type Investment, type InsertInvestment
} from "@shared/schema";
import memorystore from "memorystore";
import session from "express-session";
import { IStorage } from "./storage-types";
import { PrismaStorage } from "./prisma-storage";
import { DatabaseStorage } from "./database-storage";

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private messagesData: Map<number, Message>;
  private foldersData: Map<number, Folder>;
  private branchesData: Map<number, Branch>;
  private investmentsData: Map<number, Investment>;
  private userIdCounter: number;
  private messageIdCounter: number;
  private folderIdCounter: number;
  private branchIdCounter: number;
  private investmentIdCounter: number;
  public sessionStore: any;
  
  constructor() {
    this.users = new Map();
    this.messagesData = new Map();
    this.foldersData = new Map();
    this.branchesData = new Map();
    this.investmentsData = new Map();
    this.userIdCounter = 1;
    this.messageIdCounter = 1;
    this.folderIdCounter = 1;
    this.branchIdCounter = 1;
    this.investmentIdCounter = 1;
    
    // Initialize session store
    const MemoryStore = memorystore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const createdAt = new Date();
    
    // Create a properly typed user object with default values for optional fields
    const user: User = {
      id,
      createdAt,
      username: insertUser.username,
      password: insertUser.password,
      email: insertUser.email || null,
      fullName: insertUser.fullName || null,
      role: insertUser.role || "customer",
      branch: insertUser.branch || null,
      phoneNumber: insertUser.phoneNumber || null,
      aadharNumber: insertUser.aadharNumber || null,
      panNumber: insertUser.panNumber || null,
      isActive: insertUser.isActive ?? true
    };
    
    this.users.set(id, user);
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Chat message operations
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageIdCounter++;
    const createdAt = new Date();
    
    // Create a properly typed message object
    const message: Message = {
      id,
      createdAt,
      senderId: insertMessage.senderId,
      receiverId: insertMessage.receiverId,
      content: insertMessage.content,
      isRead: insertMessage.isRead ?? false
    };
    
    this.messagesData.set(id, message);
    return message;
  }
  
  async getChatMessages(userId1: number, userId2: number): Promise<Message[]> {
    return Array.from(this.messagesData.values())
      .filter(message => 
        (message.senderId === userId1 && message.receiverId === userId2) ||
        (message.senderId === userId2 && message.receiverId === userId1)
      )
      .sort((a, b) => {
        // Handle nullable dates
        const dateA = a.createdAt instanceof Date ? a.createdAt.getTime() : 0;
        const dateB = b.createdAt instanceof Date ? b.createdAt.getTime() : 0;
        return dateA - dateB;
      });
  }
  
  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const message = this.messagesData.get(id);
    if (!message) return undefined;
    
    const updatedMessage = { ...message, isRead: true };
    this.messagesData.set(id, updatedMessage);
    return updatedMessage;
  }
  
  // Folder operations
  async createFolder(insertFolder: InsertFolder): Promise<Folder> {
    const id = this.folderIdCounter++;
    const createdAt = new Date();
    
    // Create a properly typed folder object
    const folder: Folder = {
      id,
      name: insertFolder.name,
      ownerId: insertFolder.ownerId,
      createdAt
    };
    
    this.foldersData.set(id, folder);
    return folder;
  }
  
  async getUserFolders(userId: number): Promise<Folder[]> {
    return Array.from(this.foldersData.values()).filter(
      (folder) => folder.ownerId === userId
    );
  }

  // Branch operations
  async createBranch(insertBranch: InsertBranch): Promise<Branch> {
    const id = this.branchIdCounter++;
    const createdAt = new Date();
    
    // Create a properly typed branch object
    const branch: Branch = {
      id,
      name: insertBranch.name,
      code: insertBranch.code,
      address: insertBranch.address,
      city: insertBranch.city,
      state: insertBranch.state,
      pincode: insertBranch.pincode,
      phone: insertBranch.phone || null,
      email: insertBranch.email || null,
      managerName: insertBranch.managerName || null,
      isActive: insertBranch.isActive ?? true,
      createdAt
    };
    
    this.branchesData.set(id, branch);
    return branch;
  }
  
  async getBranch(id: number): Promise<Branch | undefined> {
    return this.branchesData.get(id);
  }
  
  async getAllBranches(): Promise<Branch[]> {
    return Array.from(this.branchesData.values());
  }
  
  async updateBranch(id: number, branchData: Partial<Branch>): Promise<Branch | undefined> {
    const branch = await this.getBranch(id);
    if (!branch) return undefined;
    
    const updatedBranch = { ...branch, ...branchData };
    this.branchesData.set(id, updatedBranch);
    return updatedBranch;
  }
  
  // Investment operations
  async createInvestment(insertInvestment: InsertInvestment): Promise<Investment> {
    const id = this.investmentIdCounter++;
    const createdAt = new Date();
    const updatedAt = new Date();
    
    // Create a properly typed investment object with default values for optional fields
    const investment: Investment = {
      id,
      userId: insertInvestment.userId,
      branchId: insertInvestment.branchId,
      type: insertInvestment.type,
      amount: insertInvestment.amount,
      interestRate: insertInvestment.interestRate || null,
      startDate: insertInvestment.startDate,
      maturityDate: insertInvestment.maturityDate || null,
      term: insertInvestment.term || null,
      status: insertInvestment.status || "active",
      certificateNumber: insertInvestment.certificateNumber || null,
      remarks: insertInvestment.remarks || null,
      createdAt,
      updatedAt
    };
    
    this.investmentsData.set(id, investment);
    return investment;
  }
  
  async getInvestment(id: number): Promise<Investment | undefined> {
    return this.investmentsData.get(id);
  }
  
  async getUserInvestments(userId: number): Promise<Investment[]> {
    return Array.from(this.investmentsData.values()).filter(
      (investment) => investment.userId === userId
    );
  }
  
  async getBranchInvestments(branchId: number): Promise<Investment[]> {
    return Array.from(this.investmentsData.values()).filter(
      (investment) => investment.branchId === branchId
    );
  }
  
  async updateInvestment(id: number, investmentData: Partial<Investment>): Promise<Investment | undefined> {
    const investment = await this.getInvestment(id);
    if (!investment) return undefined;
    
    const updatedInvestment = { 
      ...investment, 
      ...investmentData,
      updatedAt: new Date() 
    };
    
    this.investmentsData.set(id, updatedInvestment);
    return updatedInvestment;
  }
}

// Import additional dependencies
import { initializePostgres } from './init-postgresql';

// Create a storage instance based on environment
let storage: IStorage;

// Try Prisma with PostgreSQL first, then fallback to direct PostgreSQL, then in-memory storage
async function initializeStorage() {
  try {
    // Try Prisma with PostgreSQL
    if (process.env.DATABASE_URL) {
      try {
        console.log('Using Prisma ORM with PostgreSQL storage');
        storage = new PrismaStorage();
        console.log('Prisma ORM initialized successfully');
        return;
      } catch (prismaError) {
        console.error('Error initializing Prisma:', prismaError);
        
        // Fallback to direct PostgreSQL
        console.log('Falling back to direct PostgreSQL storage...');
        const isPostgresReady = await initializePostgres();
        if (isPostgresReady) {
          console.log('Using PostgreSQL storage (without Prisma)');
          storage = new DatabaseStorage();
          return;
        }
      }
    }
    
    // If both Prisma and PostgreSQL fail, use in-memory storage
    console.log('Database connection failed, falling back to in-memory storage');
    storage = new MemStorage();
  } catch (error) {
    console.error('Error initializing storage:', error);
    console.log('Using in-memory storage as fallback');
    storage = new MemStorage();
  }
}

// Initialize with PrismaStorage since we already confirmed the database connection works
try {
  storage = new PrismaStorage();
  console.log('Initialized Prisma ORM with PostgreSQL storage successfully');
} catch (error) {
  console.error('Error initializing PrismaStorage:', error);
  console.log('Falling back to in-memory storage');
  storage = new MemStorage();
}

export { storage };
