import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { setupWebSocketServer } from "./websocket";
import { UserRole, type InsertBranch, type InsertInvestment } from "@shared/schema";
import { db } from "./db";
import multer from "multer";
import path from "path";
import fs from "fs";

// Create uploads directories if they don't exist
const uploadsDir = path.join(".", "uploads");
const aadharDir = path.join(uploadsDir, "aadhar");
const panDir = path.join(uploadsDir, "pan");

if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

if (!fs.existsSync(aadharDir)) {
  fs.mkdirSync(aadharDir, { recursive: true });
}

if (!fs.existsSync(panDir)) {
  fs.mkdirSync(panDir, { recursive: true });
}

// Middleware to check authentication
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  next();
};

// Middleware to check admin/moderator permissions
const isAdminOrModerator = (req: Request, res: Response, next: Function) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  if (![UserRole.ADMIN, UserRole.MODERATOR, UserRole.BRANCH_MANAGER].includes(req.user.role as UserRole)) {
    return res.status(403).json({ message: "Permission denied" });
  }
  next();
};

// Middleware to check only admin permissions
const isAdmin = (req: Request, res: Response, next: Function) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  if (req.user.role !== UserRole.ADMIN) {
    return res.status(403).json({ message: "Admin permission required" });
  }
  next();
};

// Configure multer for file uploads
const aadharStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './uploads/aadhar');
  },
  filename: function (req, file, cb) {
    // For user self-uploads via /api/users/kyc/aadhar
    if (req.path === '/api/users/kyc/aadhar') {
      const userId = req.user!.id;
      const extension = path.extname(file.originalname) || '.jpg';
      cb(null, `${userId}${extension}`);
    } 
    // For admin uploads via /api/users/:userId/aadhar
    else {
      const userId = req.params.userId;
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      const extension = path.extname(file.originalname);
      cb(null, `aadhar-${userId}-${uniqueSuffix}${extension}`);
    }
  }
});

const panStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './uploads/pan');
  },
  filename: function (req, file, cb) {
    // For user self-uploads via /api/users/kyc/pan
    if (req.path === '/api/users/kyc/pan') {
      const userId = req.user!.id;
      const extension = path.extname(file.originalname) || '.jpg';
      cb(null, `${userId}${extension}`);
    }
    // For admin uploads via /api/users/:userId/pan
    else {
      const userId = req.params.userId;
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      const extension = path.extname(file.originalname);
      cb(null, `pan-${userId}-${uniqueSuffix}${extension}`);
    }
  }
});

const uploadAadhar = multer({ 
  storage: aadharStorage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png' || file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only JPG, PNG, and PDF files are allowed'));
    }
  }
});

const uploadPan = multer({ 
  storage: panStorage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png' || file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only JPG, PNG, and PDF files are allowed'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  setupAuth(app);

  // Create HTTP server
  const httpServer = createServer(app);

  // Set up WebSocket server for chat
  setupWebSocketServer(httpServer);

  // API Routes
  
  // Users endpoints
  app.get("/api/users", isAuthenticated, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  // Admin user registration with investment
  app.post("/api/admin-register", isAdminOrModerator, async (req, res) => {
    try {
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(req.body.user.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // First create the user
      const { hashPassword } = await import('./auth');
      const hashedPassword = await hashPassword(req.body.user.password);
      
      const userData = {
        ...req.body.user,
        password: hashedPassword,
        role: req.body.user.role || UserRole.CUSTOMER,
      };
      
      const newUser = await storage.createUser(userData);
      
      // If investment details are provided, create an investment
      if (req.body.investment) {
        const investmentData = {
          userId: newUser.id,
          branchId: parseInt(req.body.investment.branchId),
          type: req.body.investment.type,
          amount: parseFloat(req.body.investment.amount),
          interestRate: req.body.investment.interestRate ? parseFloat(req.body.investment.interestRate) : null,
          dailyReturn: req.body.investment.dailyReturn ? parseFloat(req.body.investment.dailyReturn) : null,
          workingDays: req.body.investment.workingDays ? parseInt(req.body.investment.workingDays) : null,
          daysCompleted: 0,
          totalReturns: 0,
          referredById: req.body.investment.referredById ? parseInt(req.body.investment.referredById) : null,
          startDate: new Date(req.body.investment.startDate || new Date()),
          maturityDate: req.body.investment.maturityDate ? new Date(req.body.investment.maturityDate) : null,
          term: req.body.investment.term ? parseInt(req.body.investment.term) : null,
          status: 'active',
          certificateNumber: req.body.investment.certificateNumber || null,
          remarks: req.body.investment.remarks || 
                  (req.body.investment.transactionDetails ? 
                   `Payment method: ${req.body.investment.transactionDetails.paymentMethod}, 
                    Transaction ID: ${req.body.investment.transactionDetails.transactionId},
                    Date: ${req.body.investment.transactionDetails.date}` : null)
        };
        
        const newInvestment = await storage.createInvestment(investmentData);
        
        // Return both the user and investment
        return res.status(201).json({
          user: newUser,
          investment: newInvestment
        });
      }
      
      // If no investment data, just return the user
      return res.status(201).json({ user: newUser });
    } catch (error) {
      console.error('Admin registration error:', error);
      res.status(500).json({ message: "Failed to register user" });
    }
  });

  // Chat messages endpoints
  app.get("/api/messages", isAuthenticated, async (req, res) => {
    const currentUserId = req.user.id;
    const recipientId = parseInt(req.query.recipient as string);
    
    if (isNaN(recipientId)) {
      return res.status(400).json({ message: "Invalid recipient ID" });
    }
    
    try {
      const messages = await storage.getChatMessages(currentUserId, recipientId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Dashboard stats endpoint
  app.get("/api/dashboard/stats", isAuthenticated, async (req, res) => {
    try {
      // In a real implementation, these would come from the database
      const stats = {
        users: { count: 2340, change: { value: 12, isPositive: true } },
        investments: { count: "₹15.2M", change: { value: 8.1, isPositive: true } },
        activePlans: { count: 1854, change: { value: 5.4, isPositive: true } },
        chatRequests: { count: 24, change: { value: 3.2, isPositive: false } }
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Folders endpoints
  app.post("/api/folders", isAuthenticated, async (req, res) => {
    try {
      const newFolder = await storage.createFolder({
        name: req.body.name,
        ownerId: req.user.id
      });
      res.status(201).json(newFolder);
    } catch (error) {
      res.status(500).json({ message: "Failed to create folder" });
    }
  });

  app.get("/api/folders", isAuthenticated, async (req, res) => {
    try {
      const folders = await storage.getUserFolders(req.user.id);
      res.json(folders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch folders" });
    }
  });
  
  // Branches endpoints
  app.get("/api/branches", isAuthenticated, async (req, res) => {
    try {
      const branches = await storage.getAllBranches();
      res.json(branches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch branches" });
    }
  });
  
  app.get("/api/branches/:id", isAuthenticated, async (req, res) => {
    const branchId = parseInt(req.params.id);
    
    if (isNaN(branchId)) {
      return res.status(400).json({ message: "Invalid branch ID" });
    }
    
    try {
      const branch = await storage.getBranch(branchId);
      if (!branch) {
        return res.status(404).json({ message: "Branch not found" });
      }
      res.json(branch);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch branch" });
    }
  });
  
  app.post("/api/branches", isAdminOrModerator, async (req, res) => {
    try {
      const branchData: InsertBranch = {
        name: req.body.name,
        code: req.body.code,
        address: req.body.address,
        city: req.body.city,
        state: req.body.state,
        pincode: req.body.pincode,
        phone: req.body.phone || null,
        email: req.body.email || null,
        managerName: req.body.managerName || null,
        isActive: req.body.isActive ?? true
      };
      
      const newBranch = await storage.createBranch(branchData);
      res.status(201).json(newBranch);
    } catch (error) {
      res.status(500).json({ message: "Failed to create branch" });
    }
  });
  
  app.patch("/api/branches/:id", isAdminOrModerator, async (req, res) => {
    const branchId = parseInt(req.params.id);
    
    if (isNaN(branchId)) {
      return res.status(400).json({ message: "Invalid branch ID" });
    }
    
    try {
      const updatedBranch = await storage.updateBranch(branchId, req.body);
      if (!updatedBranch) {
        return res.status(404).json({ message: "Branch not found" });
      }
      res.json(updatedBranch);
    } catch (error) {
      res.status(500).json({ message: "Failed to update branch" });
    }
  });
  
  // Investments endpoints
  app.get("/api/investments", isAuthenticated, async (req, res) => {
    try {
      // Admin, moderators, and branch managers can see all investments, others only see their own
      if ([UserRole.ADMIN, UserRole.MODERATOR, UserRole.BRANCH_MANAGER].includes(req.user.role as UserRole)) {
        const investments = await db.query.investments.findMany();
        return res.json(investments);
      } else {
        const investments = await storage.getUserInvestments(req.user.id);
        return res.json(investments);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch investments" });
    }
  });
  
  app.get("/api/investments/user/:userId", isAuthenticated, async (req, res) => {
    const userId = parseInt(req.params.userId);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    // Only allow users to see their own investments unless admin/moderator/branch manager
    if (userId !== req.user.id && ![UserRole.ADMIN, UserRole.MODERATOR, UserRole.BRANCH_MANAGER].includes(req.user.role as UserRole)) {
      return res.status(403).json({ message: "Permission denied" });
    }
    
    try {
      const investments = await storage.getUserInvestments(userId);
      res.json(investments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user investments" });
    }
  });
  
  app.get("/api/investments/branch/:branchId", isAuthenticated, async (req, res) => {
    const branchId = parseInt(req.params.branchId);
    
    if (isNaN(branchId)) {
      return res.status(400).json({ message: "Invalid branch ID" });
    }
    
    // Only allow admin/moderator/branch manager to see branch investments
    if (![UserRole.ADMIN, UserRole.MODERATOR, UserRole.BRANCH_MANAGER].includes(req.user.role as UserRole)) {
      return res.status(403).json({ message: "Permission denied" });
    }
    
    try {
      const investments = await storage.getBranchInvestments(branchId);
      res.json(investments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch branch investments" });
    }
  });
  
  app.get("/api/investments/:id", isAuthenticated, async (req, res) => {
    const investmentId = parseInt(req.params.id);
    
    if (isNaN(investmentId)) {
      return res.status(400).json({ message: "Invalid investment ID" });
    }
    
    try {
      const investment = await storage.getInvestment(investmentId);
      
      if (!investment) {
        return res.status(404).json({ message: "Investment not found" });
      }
      
      // Only allow users to see their own investments unless admin/moderator/branch manager
      if (investment.userId !== req.user.id && 
          ![UserRole.ADMIN, UserRole.MODERATOR, UserRole.BRANCH_MANAGER].includes(req.user.role as UserRole)) {
        return res.status(403).json({ message: "Permission denied" });
      }
      
      res.json(investment);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch investment" });
    }
  });
  
  app.post("/api/investments", isAuthenticated, async (req, res) => {
    try {
      // Validate user ID - only admins/moderators/branch managers can create for other users
      const userId = parseInt(req.body.userId);
      if (userId !== req.user.id && 
          ![UserRole.ADMIN, UserRole.MODERATOR, UserRole.BRANCH_MANAGER].includes(req.user.role as UserRole)) {
        return res.status(403).json({ message: "Cannot create investment for another user" });
      }
      
      const investmentData: InsertInvestment = {
        userId: userId,
        branchId: parseInt(req.body.branchId),
        type: req.body.type,
        amount: parseFloat(req.body.amount),
        interestRate: req.body.interestRate ? parseFloat(req.body.interestRate) : null,
        dailyReturn: req.body.dailyReturn ? parseFloat(req.body.dailyReturn) : null,
        workingDays: req.body.workingDays ? parseInt(req.body.workingDays) : null,
        daysCompleted: req.body.daysCompleted ? parseInt(req.body.daysCompleted) : 0,
        totalReturns: req.body.totalReturns ? parseFloat(req.body.totalReturns) : 0,
        referredById: req.body.referredById ? parseInt(req.body.referredById) : null,
        startDate: new Date(req.body.startDate),
        maturityDate: req.body.maturityDate ? new Date(req.body.maturityDate) : null,
        term: req.body.term ? parseInt(req.body.term) : null,
        status: req.body.status || 'active',
        certificateNumber: req.body.certificateNumber || null,
        remarks: req.body.remarks || null
      };
      
      const newInvestment = await storage.createInvestment(investmentData);
      res.status(201).json(newInvestment);
    } catch (error) {
      console.error('Investment creation error:', error);
      res.status(500).json({ message: "Failed to create investment" });
    }
  });
  
  app.patch("/api/investments/:id", isAuthenticated, async (req, res) => {
    const investmentId = parseInt(req.params.id);
    
    if (isNaN(investmentId)) {
      return res.status(400).json({ message: "Invalid investment ID" });
    }
    
    try {
      const investment = await storage.getInvestment(investmentId);
      
      if (!investment) {
        return res.status(404).json({ message: "Investment not found" });
      }
      
      // Check permission to update this investment
      if (investment.userId !== req.user.id && 
          ![UserRole.ADMIN, UserRole.MODERATOR, UserRole.BRANCH_MANAGER].includes(req.user.role as UserRole)) {
        return res.status(403).json({ message: "Permission denied" });
      }
      
      // Handle data conversions
      if (req.body.startDate) {
        req.body.startDate = new Date(req.body.startDate);
      }
      
      if (req.body.maturityDate) {
        req.body.maturityDate = new Date(req.body.maturityDate);
      }
      
      // Handle numeric conversions
      if (req.body.amount) req.body.amount = parseFloat(req.body.amount);
      if (req.body.interestRate) req.body.interestRate = parseFloat(req.body.interestRate);
      if (req.body.dailyReturn) req.body.dailyReturn = parseFloat(req.body.dailyReturn);
      if (req.body.workingDays) req.body.workingDays = parseInt(req.body.workingDays);
      if (req.body.daysCompleted) req.body.daysCompleted = parseInt(req.body.daysCompleted);
      if (req.body.totalReturns) req.body.totalReturns = parseFloat(req.body.totalReturns);
      if (req.body.term) req.body.term = parseInt(req.body.term);
      
      const updatedInvestment = await storage.updateInvestment(investmentId, req.body);
      res.json(updatedInvestment);
    } catch (error) {
      res.status(500).json({ message: "Failed to update investment" });
    }
  });

  // KYC Document Upload Routes
  
  // User upload of their own KYC documents
  app.post('/api/users/kyc/aadhar', isAuthenticated, uploadAadhar.single('document'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      if (!req.body.number) {
        fs.unlinkSync(req.file.path);
        return res.status(400).json({ message: "Aadhar number is required" });
      }
      
      const userId = req.user!.id;
      
      // Rename the file to have a predictable name (userId.extension)
      const extension = path.extname(req.file.path);
      const newFilename = path.join('./uploads/aadhar', `${userId}${extension}`);
      
      // Delete existing file if it exists
      try {
        const files = fs.readdirSync('./uploads/aadhar');
        const existingFiles = files.filter(file => file.startsWith(`${userId}.`));
        existingFiles.forEach(file => {
          fs.unlinkSync(path.join('./uploads/aadhar', file));
        });
      } catch (error) {
        console.error("Error removing existing file:", error);
      }
      
      // Rename uploaded file
      fs.renameSync(req.file.path, newFilename);
      
      // Update user with Aadhar info
      const updatedUser = await storage.updateUser(userId, { 
        aadharNumber: req.body.number,
        aadharVerified: false // Will be verified by admin
      });
      
      res.status(200).json({
        message: "Aadhar card uploaded successfully for verification",
        user: updatedUser
      });
    } catch (error) {
      console.error("Aadhar upload error:", error);
      if (req.file) {
        try {
          fs.unlinkSync(req.file.path);
        } catch (unlinkError) {
          console.error("Error removing failed upload:", unlinkError);
        }
      }
      res.status(500).json({ message: "Failed to upload Aadhar card" });
    }
  });
  
  app.post('/api/users/kyc/pan', isAuthenticated, uploadPan.single('document'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      if (!req.body.number) {
        fs.unlinkSync(req.file.path);
        return res.status(400).json({ message: "PAN number is required" });
      }
      
      const userId = req.user!.id;
      
      // Rename the file to have a predictable name (userId.extension)
      const extension = path.extname(req.file.path);
      const newFilename = path.join('./uploads/pan', `${userId}${extension}`);
      
      // Delete existing file if it exists
      try {
        const files = fs.readdirSync('./uploads/pan');
        const existingFiles = files.filter(file => file.startsWith(`${userId}.`));
        existingFiles.forEach(file => {
          fs.unlinkSync(path.join('./uploads/pan', file));
        });
      } catch (error) {
        console.error("Error removing existing file:", error);
      }
      
      // Rename uploaded file
      fs.renameSync(req.file.path, newFilename);
      
      // Update user with PAN info
      const updatedUser = await storage.updateUser(userId, { 
        panNumber: req.body.number,
        panVerified: false // Will be verified by admin
      });
      
      res.status(200).json({
        message: "PAN card uploaded successfully for verification",
        user: updatedUser
      });
    } catch (error) {
      console.error("PAN upload error:", error);
      if (req.file) {
        try {
          fs.unlinkSync(req.file.path);
        } catch (unlinkError) {
          console.error("Error removing failed upload:", unlinkError);
        }
      }
      res.status(500).json({ message: "Failed to upload PAN card" });
    }
  });
  
  // Admin upload of user Aadhar card document
  app.post('/api/users/:userId/aadhar', isAdminOrModerator, uploadAadhar.single('aadharCard'), async (req, res) => {
    const userId = parseInt(req.params.userId);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        // Delete the uploaded file if user doesn't exist
        fs.unlinkSync(req.file.path);
        return res.status(404).json({ message: "User not found" });
      }

      // Update user with aadhar card path
      const updatedUser = await storage.updateUser(userId, { 
        aadharCardPath: req.file.path,
        aadharVerified: false // Admin will verify later
      });

      res.status(200).json({
        message: "Aadhar card uploaded successfully",
        filePath: req.file.path,
        user: updatedUser
      });
    } catch (error) {
      console.error("Aadhar upload error:", error);
      // Remove file if there was an error
      if (req.file) {
        try {
          fs.unlinkSync(req.file.path);
        } catch (unlinkError) {
          console.error("Error removing failed upload:", unlinkError);
        }
      }
      res.status(500).json({ message: "Failed to upload Aadhar card" });
    }
  });

  // Upload PAN card document
  app.post('/api/users/:userId/pan', isAdminOrModerator, uploadPan.single('panCard'), async (req, res) => {
    const userId = parseInt(req.params.userId);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        // Delete the uploaded file if user doesn't exist
        fs.unlinkSync(req.file.path);
        return res.status(404).json({ message: "User not found" });
      }

      // Update user with PAN card path
      const updatedUser = await storage.updateUser(userId, { 
        panCardPath: req.file.path,
        panVerified: false // Admin will verify later
      });

      res.status(200).json({
        message: "PAN card uploaded successfully",
        filePath: req.file.path,
        user: updatedUser
      });
    } catch (error) {
      console.error("PAN upload error:", error);
      // Remove file if there was an error
      if (req.file) {
        try {
          fs.unlinkSync(req.file.path);
        } catch (unlinkError) {
          console.error("Error removing failed upload:", unlinkError);
        }
      }
      res.status(500).json({ message: "Failed to upload PAN card" });
    }
  });

  // Verify KYC documents (admin/moderator only - no branch manager)
  app.post('/api/users/:userId/verify-aadhar', isAuthenticated, async (req, res) => {
    // Only actual admins and moderators can verify documents
    if (![UserRole.ADMIN, UserRole.MODERATOR].includes(req.user.role as UserRole)) {
      return res.status(403).json({ message: "Permission denied - Only Admins and Moderators can verify documents" });
    }
    const userId = parseInt(req.params.userId);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    try {
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (!user.aadharCardPath) {
        return res.status(400).json({ message: "User has no Aadhar card uploaded" });
      }

      // Update user with aadhar verification status
      const updatedUser = await storage.updateUser(userId, { 
        aadharVerified: true
      });

      res.status(200).json({
        message: "Aadhar card verified successfully",
        user: updatedUser
      });
    } catch (error) {
      console.error("Aadhar verification error:", error);
      res.status(500).json({ message: "Failed to verify Aadhar card" });
    }
  });

  app.post('/api/users/:userId/verify-pan', isAuthenticated, async (req, res) => {
    // Only actual admins and moderators can verify documents
    if (![UserRole.ADMIN, UserRole.MODERATOR].includes(req.user.role as UserRole)) {
      return res.status(403).json({ message: "Permission denied - Only Admins and Moderators can verify documents" });
    }
    const userId = parseInt(req.params.userId);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    try {
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (!user.panCardPath) {
        return res.status(400).json({ message: "User has no PAN card uploaded" });
      }

      // Update user with PAN verification status
      const updatedUser = await storage.updateUser(userId, { 
        panVerified: true
      });

      res.status(200).json({
        message: "PAN card verified successfully",
        user: updatedUser
      });
    } catch (error) {
      console.error("PAN verification error:", error);
      res.status(500).json({ message: "Failed to verify PAN card" });
    }
  });

  // Get user KYC status
  app.get('/api/users/:userId/kyc-status', isAuthenticated, async (req, res) => {
    const userId = parseInt(req.params.userId);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    // Only allow admins/moderators/branch managers or the user themselves to check KYC status
    if (userId !== req.user.id && 
        ![UserRole.ADMIN, UserRole.MODERATOR, UserRole.BRANCH_MANAGER].includes(req.user.role as UserRole)) {
      return res.status(403).json({ message: "Permission denied" });
    }

    try {
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.status(200).json({
        aadharStatus: {
          uploaded: !!user.aadharCardPath,
          verified: !!user.aadharVerified
        },
        panStatus: {
          uploaded: !!user.panCardPath,
          verified: !!user.panVerified
        }
      });
    } catch (error) {
      console.error("KYC status check error:", error);
      res.status(500).json({ message: "Failed to get KYC status" });
    }
  });
  
  // Referrals API
  app.get("/api/referrals", isAuthenticated, async (req, res) => {
    try {
      // In the future, this would likely query referrals from the database
      // For now, return a mock dataset for demonstration
      const mockReferrals = [
        {
          id: 1,
          investmentId: 1,
          referrerId: 1,
          referredId: 2,
          level: "LEVEL1",
          commissionRate: 10,
          status: "active",
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          id: 2,
          investmentId: 2,
          referrerId: 2,
          referredId: 3,
          level: "LEVEL2",
          commissionRate: 7,
          status: "active",
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          id: 3,
          investmentId: 3,
          referrerId: 1,
          referredId: 4,
          level: "LEVEL3",
          commissionRate: 5,
          status: "active",
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ];
      
      res.json(mockReferrals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch referrals" });
    }
  });

  return httpServer;
}
