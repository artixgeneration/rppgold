import { db } from './db';
import { branches } from '@shared/schema';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Seed sample branches into the database
async function seedBranches() {
  console.log('Seeding branches...');
  
  try {
    // Sample branch data
    const branchData = [
      {
        name: 'Mumbai Main',
        code: 'MUM001',
        address: '123 Financial Street, Bandra',
        city: 'Mumbai',
        state: 'Maharashtra',
        pincode: '400001',
        phone: '022-12345678',
        email: 'mumbai@rpgold.com',
        managerName: 'Rajesh Sharma',
        isActive: true
      },
      {
        name: 'Delhi Central',
        code: 'DEL001',
        address: '456 Business Avenue, Connaught Place',
        city: 'New Delhi',
        state: 'Delhi',
        pincode: '110001',
        phone: '011-23456789',
        email: 'delhi@rpgold.com',
        managerName: 'Priya Gupta',
        isActive: true
      },
      {
        name: 'Bangalore Tech',
        code: 'BLR001',
        address: '789 Technology Park, Whitefield',
        city: 'Bangalore',
        state: 'Karnataka',
        pincode: '560066',
        phone: '080-34567890',
        email: 'bangalore@rpgold.com',
        managerName: 'Suresh Kumar',
        isActive: true
      },
      {
        name: 'Chennai Coast',
        code: 'CHN001',
        address: '321 Marina Road, Mylapore',
        city: 'Chennai',
        state: 'Tamil Nadu',
        pincode: '600004',
        phone: '044-45678901',
        email: 'chennai@rpgold.com',
        managerName: 'Lakshmi Narayanan',
        isActive: true
      },
      {
        name: 'Kolkata Central',
        code: 'KOL001',
        address: '567 Park Street, Esplanade',
        city: 'Kolkata',
        state: 'West Bengal',
        pincode: '700016',
        phone: '033-56789012',
        email: 'kolkata@rpgold.com',
        managerName: 'Debashish Roy',
        isActive: true
      }
    ];
    
    // Insert branches
    for (const branch of branchData) {
      const existingBranch = await db.query.branches.findFirst({
        where: (b, { eq }) => eq(b.code, branch.code)
      });
      
      if (!existingBranch) {
        await db.insert(branches).values(branch);
        console.log(`Branch ${branch.name} created`);
      } else {
        console.log(`Branch ${branch.name} already exists`);
      }
    }
    
    console.log('Branches seeded successfully');
  } catch (error) {
    console.error('Error seeding branches:', error);
  }
}

// Run the seed function
seedBranches().catch(console.error);