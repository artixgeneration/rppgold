import { prisma } from './prisma';
import type { User, InsertUser, Message, InsertMessage, Folder, InsertFolder, Branch, InsertBranch, Investment, InsertInvestment, Referral, InsertReferral } from '@shared/schema';
import type { IStorage } from './storage-types';
import connectPg from 'connect-pg-simple';
import session from 'express-session';
import pg from 'pg';
const { Pool } = pg;

// Create a PostgreSQL session store for Express session
const PostgresSessionStore = connectPg(session);
const pool = new Pool({ 
  connectionString: process.env.DATABASE_URL
});

export class PrismaStorage implements IStorage {
  public sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      tableName: 'session',
      createTableIfMissing: true
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    try {
      const user = await prisma.user.findUnique({
        where: { id }
      });
      return user ? this.mapPrismaUserToUser(user) : undefined;
    } catch (error) {
      console.error('Error in getUser:', error);
      throw error;
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const user = await prisma.user.findFirst({
        where: { username }
      });
      return user ? this.mapPrismaUserToUser(user) : undefined;
    } catch (error) {
      console.error('Error in getUserByUsername:', error);
      throw error;
    }
  }

  async createUser(userData: InsertUser): Promise<User> {
    try {
      const user = await prisma.user.create({
        data: {
          username: userData.username,
          password: userData.password,
          email: userData.email || null,
          fullName: userData.fullName || null,
          role: userData.role,
          branch: userData.branch || null,
          phoneNumber: userData.phoneNumber || null,
          dateOfBirth: userData.dateOfBirth || null,
          address: userData.address || null,
          city: userData.city || null,
          state: userData.state || null,
          pincode: userData.pincode || null,
          aadharNumber: userData.aadharNumber || null,
          aadharCardPath: userData.aadharCardPath || null,
          aadharVerified: userData.aadharVerified || false,
          panNumber: userData.panNumber || null,
          panCardPath: userData.panCardPath || null,
          panVerified: userData.panVerified || false,
          nomineeName: userData.nomineeName || null,
          nomineeRelationship: userData.nomineeRelationship || null,
          nomineeContact: userData.nomineeContact || null,
          bankName: userData.bankName || null,
          accountNumber: userData.accountNumber || null,
          ifscCode: userData.ifscCode || null,
          isActive: userData.isActive ?? true
        }
      });
      return this.mapPrismaUserToUser(user);
    } catch (error) {
      console.error('Error in createUser:', error);
      throw error;
    }
  }

  async getAllUsers(): Promise<User[]> {
    try {
      const users = await prisma.user.findMany();
      return users.map(user => this.mapPrismaUserToUser(user));
    } catch (error) {
      console.error('Error in getAllUsers:', error);
      throw error;
    }
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    try {
      const user = await prisma.user.update({
        where: { id },
        data: userData
      });
      return this.mapPrismaUserToUser(user);
    } catch (error) {
      console.error('Error in updateUser:', error);
      if (error.code === 'P2025') { // Record not found
        return undefined;
      }
      throw error;
    }
  }

  // Message operations
  async createMessage(messageData: InsertMessage): Promise<Message> {
    try {
      const message = await prisma.message.create({
        data: {
          content: messageData.content,
          senderId: messageData.senderId,
          receiverId: messageData.receiverId,
          isRead: messageData.isRead ?? false
        }
      });
      return this.mapPrismaMessageToMessage(message);
    } catch (error) {
      console.error('Error in createMessage:', error);
      throw error;
    }
  }

  async getChatMessages(senderId: number, receiverId: number): Promise<Message[]> {
    try {
      const messages = await prisma.message.findMany({
        where: {
          OR: [
            { 
              AND: [
                { senderId },
                { receiverId }
              ]
            },
            {
              AND: [
                { senderId: receiverId },
                { receiverId: senderId }
              ]
            }
          ]
        },
        orderBy: {
          createdAt: 'asc'
        }
      });
      return messages.map(message => this.mapPrismaMessageToMessage(message));
    } catch (error) {
      console.error('Error in getChatMessages:', error);
      throw error;
    }
  }

  async markMessageAsRead(id: number): Promise<Message | undefined> {
    try {
      const message = await prisma.message.update({
        where: { id },
        data: { isRead: true }
      });
      return this.mapPrismaMessageToMessage(message);
    } catch (error) {
      console.error('Error in markMessageAsRead:', error);
      if (error.code === 'P2025') { // Record not found
        return undefined;
      }
      throw error;
    }
  }

  // Folder operations
  async createFolder(folderData: InsertFolder): Promise<Folder> {
    try {
      const folder = await prisma.folder.create({
        data: {
          name: folderData.name,
          ownerId: folderData.ownerId
        }
      });
      return this.mapPrismaFolderToFolder(folder);
    } catch (error) {
      console.error('Error in createFolder:', error);
      throw error;
    }
  }

  async getUserFolders(userId: number): Promise<Folder[]> {
    try {
      const folders = await prisma.folder.findMany({
        where: { ownerId: userId }
      });
      return folders.map(folder => this.mapPrismaFolderToFolder(folder));
    } catch (error) {
      console.error('Error in getUserFolders:', error);
      throw error;
    }
  }

  // Branch operations
  async createBranch(branchData: InsertBranch): Promise<Branch> {
    try {
      const branch = await prisma.branch.create({
        data: {
          name: branchData.name,
          code: branchData.code,
          address: branchData.address,
          city: branchData.city,
          state: branchData.state,
          pincode: branchData.pincode,
          phone: branchData.phone || null,
          email: branchData.email || null,
          managerName: branchData.managerName || null,
          isActive: branchData.isActive ?? true
        }
      });
      return this.mapPrismaBranchToBranch(branch);
    } catch (error) {
      console.error('Error in createBranch:', error);
      throw error;
    }
  }

  async getBranch(id: number): Promise<Branch | undefined> {
    try {
      const branch = await prisma.branch.findUnique({
        where: { id }
      });
      return branch ? this.mapPrismaBranchToBranch(branch) : undefined;
    } catch (error) {
      console.error('Error in getBranch:', error);
      throw error;
    }
  }

  async getAllBranches(): Promise<Branch[]> {
    try {
      const branches = await prisma.branch.findMany();
      return branches.map(branch => this.mapPrismaBranchToBranch(branch));
    } catch (error) {
      console.error('Error in getAllBranches:', error);
      throw error;
    }
  }

  async updateBranch(id: number, branchData: Partial<Branch>): Promise<Branch | undefined> {
    try {
      const branch = await prisma.branch.update({
        where: { id },
        data: branchData
      });
      return this.mapPrismaBranchToBranch(branch);
    } catch (error) {
      console.error('Error in updateBranch:', error);
      if (error.code === 'P2025') { // Record not found
        return undefined;
      }
      throw error;
    }
  }

  // Investment operations
  async createInvestment(investmentData: InsertInvestment): Promise<Investment> {
    try {
      const investment = await prisma.investment.create({
        data: {
          userId: investmentData.userId,
          branchId: investmentData.branchId,
          type: investmentData.type,
          amount: investmentData.amount,
          interestRate: investmentData.interestRate || null,
          dailyReturn: investmentData.dailyReturn || null,
          workingDays: investmentData.workingDays || null,
          daysCompleted: investmentData.daysCompleted || 0,
          startDate: investmentData.startDate,
          maturityDate: investmentData.maturityDate || null,
          term: investmentData.term || null,
          status: investmentData.status || 'active',
          certificateNumber: investmentData.certificateNumber || null,
          remarks: investmentData.remarks || null,
          referredById: investmentData.referredById || null,
          totalReturns: investmentData.totalReturns || 0
        }
      });
      return this.mapPrismaInvestmentToInvestment(investment);
    } catch (error) {
      console.error('Error in createInvestment:', error);
      throw error;
    }
  }

  async getInvestment(id: number): Promise<Investment | undefined> {
    try {
      const investment = await prisma.investment.findUnique({
        where: { id }
      });
      return investment ? this.mapPrismaInvestmentToInvestment(investment) : undefined;
    } catch (error) {
      console.error('Error in getInvestment:', error);
      throw error;
    }
  }

  async getUserInvestments(userId: number): Promise<Investment[]> {
    try {
      const investments = await prisma.investment.findMany({
        where: { userId }
      });
      return investments.map(investment => this.mapPrismaInvestmentToInvestment(investment));
    } catch (error) {
      console.error('Error in getUserInvestments:', error);
      throw error;
    }
  }

  async getBranchInvestments(branchId: number): Promise<Investment[]> {
    try {
      const investments = await prisma.investment.findMany({
        where: { branchId }
      });
      return investments.map(investment => this.mapPrismaInvestmentToInvestment(investment));
    } catch (error) {
      console.error('Error in getBranchInvestments:', error);
      throw error;
    }
  }

  async updateInvestment(id: number, investmentData: Partial<Investment>): Promise<Investment | undefined> {
    try {
      const investment = await prisma.investment.update({
        where: { id },
        data: investmentData
      });
      return this.mapPrismaInvestmentToInvestment(investment);
    } catch (error) {
      console.error('Error in updateInvestment:', error);
      if (error.code === 'P2025') { // Record not found
        return undefined;
      }
      throw error;
    }
  }

  // Mapper functions
  private mapPrismaUserToUser(prismaUser: any): User {
    return {
      id: prismaUser.id,
      username: prismaUser.username,
      password: prismaUser.password,
      email: prismaUser.email,
      fullName: prismaUser.fullName,
      role: prismaUser.role,
      branch: prismaUser.branch,
      phoneNumber: prismaUser.phoneNumber,
      dateOfBirth: prismaUser.dateOfBirth,
      address: prismaUser.address,
      city: prismaUser.city,
      state: prismaUser.state,
      pincode: prismaUser.pincode,
      aadharNumber: prismaUser.aadharNumber,
      aadharCardPath: prismaUser.aadharCardPath,
      aadharVerified: prismaUser.aadharVerified,
      panNumber: prismaUser.panNumber,
      panCardPath: prismaUser.panCardPath,
      panVerified: prismaUser.panVerified,
      nomineeName: prismaUser.nomineeName,
      nomineeRelationship: prismaUser.nomineeRelationship,
      nomineeContact: prismaUser.nomineeContact,
      bankName: prismaUser.bankName,
      accountNumber: prismaUser.accountNumber,
      ifscCode: prismaUser.ifscCode,
      isActive: prismaUser.isActive,
      createdAt: prismaUser.createdAt
    };
  }

  private mapPrismaMessageToMessage(prismaMessage: any): Message {
    return {
      id: prismaMessage.id,
      senderId: prismaMessage.senderId,
      receiverId: prismaMessage.receiverId,
      content: prismaMessage.content,
      isRead: prismaMessage.isRead,
      createdAt: prismaMessage.createdAt
    };
  }

  private mapPrismaFolderToFolder(prismaFolder: any): Folder {
    return {
      id: prismaFolder.id,
      name: prismaFolder.name,
      ownerId: prismaFolder.ownerId,
      createdAt: prismaFolder.createdAt
    };
  }

  private mapPrismaBranchToBranch(prismaBranch: any): Branch {
    return {
      id: prismaBranch.id,
      name: prismaBranch.name,
      code: prismaBranch.code,
      address: prismaBranch.address,
      city: prismaBranch.city,
      state: prismaBranch.state,
      pincode: prismaBranch.pincode,
      phone: prismaBranch.phone,
      email: prismaBranch.email,
      managerName: prismaBranch.managerName,
      isActive: prismaBranch.isActive,
      createdAt: prismaBranch.createdAt
    };
  }

  private mapPrismaInvestmentToInvestment(prismaInvestment: any): Investment {
    return {
      id: prismaInvestment.id,
      userId: prismaInvestment.userId,
      branchId: prismaInvestment.branchId,
      type: prismaInvestment.type,
      amount: String(prismaInvestment.amount),
      interestRate: prismaInvestment.interestRate ? String(prismaInvestment.interestRate) : null,
      dailyReturn: prismaInvestment.dailyReturn ? String(prismaInvestment.dailyReturn) : null,
      workingDays: prismaInvestment.workingDays,
      daysCompleted: prismaInvestment.daysCompleted,
      startDate: prismaInvestment.startDate.toISOString().split('T')[0],
      maturityDate: prismaInvestment.maturityDate 
        ? prismaInvestment.maturityDate.toISOString().split('T')[0] 
        : null,
      term: prismaInvestment.term,
      status: prismaInvestment.status,
      certificateNumber: prismaInvestment.certificateNumber,
      remarks: prismaInvestment.remarks,
      referredById: prismaInvestment.referredById,
      totalReturns: prismaInvestment.totalReturns ? String(prismaInvestment.totalReturns) : null,
      createdAt: prismaInvestment.createdAt,
      updatedAt: prismaInvestment.updatedAt
    };
  }
}