#!/usr/bin/env node

/**
 * This script initializes the Prisma client and sets up the database.
 * 
 * It performs these steps:
 * 1. Generates the Prisma client
 * 2. Pushes the schema to the database (creates tables if they don't exist)
 * 3. Seeds the database with initial data if needed
 */

const { exec } = require('child_process');
const { promisify } = require('util');
const execAsync = promisify(exec);
const path = require('path');
const fs = require('fs');

async function main() {
  try {
    console.log('🔄 Starting Prisma initialization process...');
    
    // 1. Generate Prisma Client
    console.log('📦 Generating Prisma client...');
    await execAsync('npx prisma generate');
    console.log('✅ Prisma client generated successfully');
    
    // 2. Push the schema to the database (create tables if they don't exist)
    console.log('🔄 Pushing schema to database...');
    await execAsync('npx prisma db push --accept-data-loss');
    console.log('✅ Schema pushed to database successfully');
    
    // 3. Seed the database with initial data if needed
    console.log('🌱 Checking if database needs seeding...');
    
    // Import PrismaClient
    const { PrismaClient } = require('@prisma/client');
    const prisma = new PrismaClient();
    
    // Check if we need to seed users (if no users exist)
    const userCount = await prisma.user.count();
    if (userCount === 0) {
      console.log('🌱 Seeding users...');
      // Create default admin user
      await prisma.user.create({
        data: {
          username: 'admin',
          password: '$2b$10$XFE0UPNrmZrufrvPCX/wz.7O9Q2AKj7z3JQhe0/P6UKl3wJM0PjAS', // 'password' hashed
          email: 'admin@example.com',
          fullName: 'System Administrator',
          role: 'admin',
          isActive: true
        }
      });
      console.log('✅ Created default admin user (username: admin, password: password)');
    } else {
      console.log('✅ Users already exist, skipping user seeding');
    }
    
    // Check if we need to seed branches
    const branchCount = await prisma.branch.count();
    if (branchCount === 0) {
      console.log('🌱 Seeding branches...');
      // Create default branch
      await prisma.branch.create({
        data: {
          name: 'Head Office',
          location: 'Mumbai',
          manager: 'Admin',
          contactInfo: '+91 9876543210',
          address: 'Main Street, Mumbai',
          isActive: true
        }
      });
      console.log('✅ Created default branch');
    } else {
      console.log('✅ Branches already exist, skipping branch seeding');
    }
    
    await prisma.$disconnect();
    console.log('🎉 Prisma initialization completed successfully!');
    
  } catch (error) {
    console.error('❌ Error initializing Prisma:', error);
    process.exit(1);
  }
}

main();