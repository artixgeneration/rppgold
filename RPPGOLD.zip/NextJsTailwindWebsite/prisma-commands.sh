#!/bin/bash

# This script provides a convenient way to run common Prisma commands
# Usage: ./prisma-commands.sh [command]

set -e

case "$1" in
  init)
    echo "Running Prisma initialization script..."
    node scripts/init-prisma.js
    ;;
  generate)
    echo "Generating Prisma client..."
    npx prisma generate
    ;;
  push)
    echo "Pushing schema to database..."
    npx prisma db push --accept-data-loss
    ;;
  studio)
    echo "Starting Prisma Studio..."
    npx prisma studio
    ;;
  help|*)
    echo "Usage: ./prisma-commands.sh [command]"
    echo ""
    echo "Available commands:"
    echo "  init      - Run the full initialization script (generate + push + seed)"
    echo "  generate  - Generate Prisma client from schema"
    echo "  push      - Push schema to database (create/update tables)"
    echo "  studio    - Start Prisma Studio (web-based database explorer)"
    ;;
esac