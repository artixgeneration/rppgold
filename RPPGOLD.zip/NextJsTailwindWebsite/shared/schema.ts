import { pgTable, text, serial, integer, boolean, timestamp, numeric, date, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User roles
export const UserRole = {
  ADMIN: 'admin',
  MODERATOR: 'moderator',
  BRANCH_MANAGER: 'branch_manager',
  DEVELOPER: 'developer',
  CUSTOMER: 'customer'
} as const;

export type UserRoleType = typeof UserRole[keyof typeof UserRole];

// Investment types
export const InvestmentType = {
  RPP_GOLD_TIER1: 'rpp_gold_tier1',   // ₹24,999-₹1,50,000 | 0.75% daily | 267 working days
  RPP_GOLD_TIER2: 'rpp_gold_tier2',   // ₹3,00,000-₹5,00,000 | 1% daily | 200 working days
  RPP_GOLD_TIER3: 'rpp_gold_tier3',   // ₹6,00,000+ | 1.5% daily | 132 working days
} as const;

export type InvestmentTypeValue = typeof InvestmentType[keyof typeof InvestmentType];

// Referral level commissions
export const ReferralLevel = {
  DIRECT: 'direct',     // 5% commission
  LEVEL1: 'level1',     // 10% commission
  LEVEL2: 'level2',     // 7% commission
  LEVEL3: 'level3',     // 5% commission
  LEVEL4: 'level4',     // 4% commission
  LEVEL5: 'level5',     // 3% commission
} as const;

export type ReferralLevelType = typeof ReferralLevel[keyof typeof ReferralLevel];

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  fullName: text("full_name"),
  role: text("role").notNull().default(UserRole.CUSTOMER),
  branch: text("branch"),
  phoneNumber: text("phone_number"),
  dateOfBirth: date("date_of_birth"),
  address: text("address"),
  city: text("city"),
  state: text("state"),
  pincode: text("pincode"),
  // KYC Details
  aadharNumber: text("aadhar_number"),
  aadharCardPath: text("aadhar_card_path"),
  aadharVerified: boolean("aadhar_verified").default(false),
  panNumber: text("pan_number"),
  panCardPath: text("pan_card_path"),
  panVerified: boolean("pan_verified").default(false),
  // Nominee Details
  nomineeName: text("nominee_name"),
  nomineeRelationship: text("nominee_relationship"),
  nomineeContact: text("nominee_contact"),
  // Bank details
  bankName: text("bank_name"),
  accountNumber: text("account_number"),
  ifscCode: text("ifsc_code"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Chat message schema
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull().references(() => users.id),
  receiverId: integer("receiver_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Folder schema
export const folders = pgTable("folders", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  ownerId: integer("owner_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Branch schema
export const branches = pgTable("branches", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  code: text("code").notNull().unique(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  pincode: text("pincode").notNull(),
  phone: text("phone"),
  email: text("email"),
  managerName: text("manager_name"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Investment schema
export const investments = pgTable("investments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  branchId: integer("branch_id").notNull().references(() => branches.id),
  type: text("type").notNull(),
  amount: numeric("amount").notNull(),
  interestRate: numeric("interest_rate"),
  dailyReturn: numeric("daily_return"), // Daily return percentage
  workingDays: integer("working_days"), // Total working days for the plan
  daysCompleted: integer("days_completed").default(0), // Number of working days completed
  referredById: integer("referred_by_id").references(() => users.id), // User who referred this investment
  startDate: date("start_date").notNull(),
  maturityDate: date("maturity_date"),
  term: integer("term"), // In working days
  status: text("status").notNull().default("active"),
  certificateNumber: text("certificate_number"),
  remarks: text("remarks"),
  totalReturns: numeric("total_returns").default(0), // Total returns earned so far
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
});

// User insert schema
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  fullName: true,
  role: true,
  branch: true,
  phoneNumber: true,
  dateOfBirth: true,
  address: true,
  city: true,
  state: true,
  pincode: true,
  // KYC Details
  aadharNumber: true,
  aadharCardPath: true,
  aadharVerified: true,
  panNumber: true,
  panCardPath: true,
  panVerified: true,
  // Nominee Details
  nomineeName: true,
  nomineeRelationship: true,
  nomineeContact: true,
  // Bank details
  bankName: true,
  accountNumber: true,
  ifscCode: true,
  isActive: true,
});

// Login schema
export const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

// Message insert schema
export const insertMessageSchema = createInsertSchema(messages).pick({
  senderId: true,
  receiverId: true,
  content: true,
  isRead: true,
});

// Folder insert schema
export const insertFolderSchema = createInsertSchema(folders).pick({
  name: true,
  ownerId: true,
});

// Branch insert schema
export const insertBranchSchema = createInsertSchema(branches).pick({
  name: true,
  code: true,
  address: true,
  city: true,
  state: true,
  pincode: true,
  phone: true,
  email: true,
  managerName: true,
  isActive: true,
});

// Investment insert schema
// Referral commissions schema
export const referrals = pgTable("referrals", {
  id: serial("id").primaryKey(),
  investmentId: integer("investment_id").notNull().references(() => investments.id),
  referrerId: integer("referrer_id").notNull().references(() => users.id),
  referredUserId: integer("referred_user_id").notNull().references(() => users.id),
  level: text("level").notNull(), // direct, level1, level2, etc.
  commissionRate: numeric("commission_rate").notNull(), // Commission percentage
  commissionAmount: numeric("commission_amount").notNull(), // Calculated commission amount
  status: text("status").notNull().default("pending"), // pending, paid, cancelled
  paidDate: date("paid_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertInvestmentSchema = createInsertSchema(investments).pick({
  userId: true,
  branchId: true,
  type: true,
  amount: true,
  interestRate: true,
  dailyReturn: true,
  workingDays: true,
  daysCompleted: true,
  totalReturns: true,
  referredById: true,
  startDate: true,
  maturityDate: true,
  term: true,
  status: true,
  certificateNumber: true,
  remarks: true,
});

export const insertReferralSchema = createInsertSchema(referrals).pick({
  investmentId: true,
  referrerId: true,
  referredUserId: true,
  level: true,
  commissionRate: true,
  commissionAmount: true,
  status: true,
  paidDate: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type LoginData = z.infer<typeof loginSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertFolder = z.infer<typeof insertFolderSchema>;
export type Folder = typeof folders.$inferSelect;
export type InsertBranch = z.infer<typeof insertBranchSchema>;
export type Branch = typeof branches.$inferSelect;
export type InsertInvestment = z.infer<typeof insertInvestmentSchema>;
export type Investment = typeof investments.$inferSelect;
export type InsertReferral = z.infer<typeof insertReferralSchema>;
export type Referral = typeof referrals.$inferSelect;

// WebSocket message types
export type WebSocketMessage = {
  type: 'chat' | 'notification' | 'system';
  data: any;
};

export type ChatMessage = {
  id?: number;
  senderId: number;
  receiverId: number;
  content: string;
  isRead: boolean;
  createdAt?: Date;
  senderName?: string;
};
